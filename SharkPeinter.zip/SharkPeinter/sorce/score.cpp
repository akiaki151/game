//=============================================================================
//
// �X�R�A���� [score.cpp]
//
//=============================================================================
//------------------------------------
//		�C���N���[�h
//------------------------------------
#include "score.h"
#include "number.h"
#include "texture.h"
#include "sprite.h"

//------------------------------------
//		�X�R�A�̕`�揈��
//------------------------------------
void Score_draw(float x, float y, int score, int fig, bool bLeft, bool bZero)
{
	//�J���X�g�p�̍ő�l�����
	int count_stop_score = 1;
	for (int i = 0; i < fig; i++)
	{
		count_stop_score *= 10;
	}

	if (score >= count_stop_score)
	{
		score = count_stop_score - 1;
	}

	if (bZero)
	{
		for (int i = 0; i < fig; i++)
		{
			//x + NUMBER_WIDTH * (fig - (i + 1)) = �E�[;
			int number = score % 10;
			score /= 10;
			Number_Draw(x + NUMBER_SIZE_W * (fig - (i + 1)), y, number);
		}
	}
}