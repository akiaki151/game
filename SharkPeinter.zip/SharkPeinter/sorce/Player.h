//=============================================================================
//
// �v���C���[���� [player.h]
//
//=============================================================================
#ifndef PLAYER_H_
#define PLAYER_H_
#include "collision.h"
//------------------------------------
//		�}�N��
//------------------------------------
#define PLAYER_MOVE_SPEED (0.005f)
//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Player_Initialize(void);
void Player_Update(void);
D3DXVECTOR3 Player_Pos(void);
void Player_Move_Func(void);
void Player_Gun_Funk(void);
void Player_Draw(void);
void Gun_Type(void);
D3DXVECTOR3 MTXR_FROANT(void);
bool Hude_Judge(void);
void Plyer_Dead(void);
void Player_Life(int damege);
const SphreCollision*Player_GetCircleCollision();//���ł̓����蔻��
#endif //PLAYER_H_