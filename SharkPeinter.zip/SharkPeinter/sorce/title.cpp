//=============================================================================
//
// �^�C�g���\������ [title.h]
//�G����������Ȃ�
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"scene.h"
#include"input.h"
#include"texture.h"
#include"sprite.h"
#include"fade.h"
#include"title.h"
#include"common.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static bool g_bEnd = false;
static int cnt = 0;
static int select_cnt = 0;
static int mode_select = 0;
static int mode_judge = 0;
static int buki_select[4];
static int buki_select_cnt = 0;
static int player_buki;
//------------------------------------
//		����������
//------------------------------------
void Title_Initialize(void)
{
	g_bEnd = false;
	cnt = 0;
	select_cnt = 0;
	mode_select = 0;
	mode_judge = 4;
	buki_select[4] = {0};
	buki_select_cnt = 0;
	player_buki = 0;
}

//------------------------------------
//		�I������
//------------------------------------
void Title_Finalize(void)
{

}

//------------------------------------
//		�X�V����
//------------------------------------
void Title_Update(void)
{
	if (!g_bEnd)
	{
		if (Keyboard_IsTrigger(DIK_SPACE) && select_cnt == 0)
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			select_cnt = 1;
			buki_select[3]=buki_select_cnt;
		}
		else if (Keyboard_IsTrigger(DIK_SPACE) && select_cnt == 1)
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			mode_judge = mode_select;
			select_cnt = 2;
			buki_select[2] = buki_select_cnt;
		}
		else if (Keyboard_IsTrigger(DIK_DOWN) && mode_select == 0)
		{
			mode_select = 1;
		}
		else if (Keyboard_IsTrigger(DIK_DOWN) && mode_select == 2)
		{
			mode_select = 0;
		}
		else if (Keyboard_IsTrigger(DIK_UP) && mode_select == 0)
		{
			mode_select = 2;
		}
		else if (Keyboard_IsTrigger(DIK_UP) && mode_select == 1)
		{
			mode_select = 0;
		}
		else if (Keyboard_IsTrigger(DIK_SPACE) && mode_judge == 0&& select_cnt==2)
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			buki_select[1] = buki_select_cnt;
			buki_select[0] = player_buki;
			g_bEnd = true;
		}
		if (Keyboard_IsTrigger(DIK_DOWN) && mode_judge == 0 && select_cnt == 2)
		{
			player_buki++;
		}

		if (mode_judge == 2)
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			buki_select[0] = 0;
			g_bEnd = true;
		}

	}
	else if (g_bEnd)
	{
		if (!Fade_IsFade())
		{
			Scene_Change(SCENE_INDEX_GAME);
		}
	}
	cnt++;
	buki_select_cnt++;
	if (3 < buki_select_cnt)
	{
		buki_select_cnt = 0;
	}
	if (3 < player_buki)
	{
		player_buki = 0;
	}
	if (cnt >= 60)
	{
		cnt = 0;
	}
}

//------------------------------------
//		�`�揈��
//------------------------------------
void Title_Draw(void)
{
	if (select_cnt == 0)
	{
		Sprite_Draw2(TITLE, 0, 0);
	}
	else if (select_cnt == 1)
	{
		Sprite_Draw2(TITLE_SELECT, 0, 0);
		if (mode_select == 0)
		{
			Sprite_Draw2(SHOOTER_TEX, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5*2);
			if (g_bEnd)
			{
				Sprite_Draw2(INK_RED, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5 * 2);
			}
		}
		else if (mode_select == 2)
		{
			Sprite_Draw2(SHOOTER_TEX, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5);
			if (g_bEnd)
			{
				Sprite_Draw2(INK_RED, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5);
			}
		}
		else if (mode_select == 1)
		{
			Sprite_Draw2(SHOOTER_TEX, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3*2);
			if (g_bEnd)
			{
				Sprite_Draw2(INK_RED, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 3 * 2);
			}
		}
	}
	else if (mode_judge == 0)
	{
		Sprite_Draw2(WEAPON_SELECT, 0, 0);
		if (player_buki == 0)
		{
			Sprite_Draw2(SHOOTER_TEX, SCREEN_WIDTH / 5*2, SCREEN_HEIGHT / 7 * 4-30);
			Sprite_Draw2(WEAPON1, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5 * 4);
		}
		else if (player_buki == 1)
		{
			Sprite_Draw2(SNIPER_TEX, SCREEN_WIDTH / 5*2, SCREEN_HEIGHT / 7 * 4-30);
			Sprite_Draw2(WEAPON2, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5 * 4);
		}
		else if (player_buki == 2)
		{
			Sprite_Draw2(HUDE_TEX, SCREEN_WIDTH / 5*2, SCREEN_HEIGHT / 7 * 4-30);
			Sprite_Draw2(WEAPON3, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5 * 4);
		}
		else if (player_buki == 3)
		{
			Sprite_Draw2(ROLA_TEX, SCREEN_WIDTH / 5*2, SCREEN_HEIGHT / 7 * 4-30);
			Sprite_Draw2(WEAPON4, SCREEN_WIDTH / 2, SCREEN_HEIGHT / 5 * 4);
		}
	}
	if (cnt >= 30)
	{
		if (mode_judge == 0)
			Sprite_Draw2(PRESS_SPACE, SCREEN_WIDTH / 7 * 5, SCREEN_HEIGHT / 2);
		else
		{
			Sprite_Draw2(PRESS_SPACE, SCREEN_WIDTH / 5 * 3, SCREEN_HEIGHT / 8);
		}
	}
}

int Title_Select(void)
{
	return mode_judge;
}

int Buki_Select(int index)
{
	return buki_select[index];
}