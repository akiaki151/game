//=============================================================================
//
// �v���C���[���� [player.cpp]
//
//=============================================================================
//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"mydirect.h"
#include"Blender.h"
#include<d3dx9.h>
#include"input.h"
#include"camera.h"
#include"debug_font.h"
#include"Player.h"
#include"bullet.h"
#include"Mesh_filed.h"
#include "collision.h"
#include"sprite.h"
#include"common.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static D3DXVECTOR3 g_PlayerSpeed;
static D3DXVECTOR3 g_PlayerPos;
static D3DXVECTOR3 p_front;
static D3DXVECTOR3 p_side;
static D3DXVECTOR3 p_height;
static D3DXMATRIX Trans;
static D3DXMATRIX mtxR;
static D3DXMATRIX Rot;
static D3DXMATRIX mtxR_Player;
SphreCollision player_collision;
static float rot;//�v���C���[�̉�]
static int Frame_Gun_Cnt;//�e�̊Ԋu�t���[��
static float P_ink;//�C���N�̎c��
static int P_Swim;//���������̑���
static bool hude_judge;
static int player_life;
//------------------------------------
//		����������
//------------------------------------
void Player_Initialize(void) {
	g_PlayerSpeed = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	g_PlayerPos = D3DXVECTOR3(0.0f, 0.0f, -20.0f);
	p_front = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	D3DXVec3Normalize(&p_front, &p_front);
	p_height = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXVec3Cross(&p_side, &p_height, &p_front);
	D3DXVec3Normalize(&p_side, &p_side);
	D3DXVec3Cross(&p_height, &p_front, &p_side);
	D3DXVec3Normalize(&p_height, &p_height);
	player_collision.position = g_PlayerPos;
	player_collision.radius = 0.5f;
	rot = 0.0f;
	Frame_Gun_Cnt = 0;
	P_ink = 100.0f;
	P_Swim = 1;
	hude_judge = false;
	player_life = 100;
}
//------------------------------------
//		�X�V����
//------------------------------------
void Player_Update(void) {
	D3DXMatrixIdentity(&Trans);
	D3DXMatrixIdentity(&mtxR_Player);
	D3DXMatrixIdentity(&Rot);
	Player_Move_Func();
	Player_Gun_Funk();
	Plyer_Dead();
}
void Player_Move_Func(void)
{
	if (Keyboard_IsPress(DIK_RIGHT))
	{
		rot += 1.0f;
		D3DXMatrixRotationAxis(&mtxR_Player, &p_height, D3DXToRadian(1));
		D3DXVec3TransformNormal(&p_front, &p_front, &mtxR_Player);
		D3DXVec3TransformNormal(&p_side, &p_side, &mtxR_Player);
	}
	if (Keyboard_IsPress(DIK_LEFT))
	{
		rot -= 1.0f;
		D3DXMatrixRotationAxis(&mtxR_Player, &-p_height, D3DXToRadian(1));
		D3DXVec3TransformNormal(&p_front, &p_front, &mtxR_Player);
		D3DXVec3TransformNormal(&p_side, &p_side, &mtxR_Player);
	}
	if (Keyboard_IsPress(DIK_D)) {
		D3DXVECTOR3 f(p_side);
		f.y = 0.0f;
		g_PlayerSpeed += f * PLAYER_MOVE_SPEED*P_Swim;
	}
	if (Keyboard_IsPress(DIK_A)) {
		D3DXVECTOR3 f(p_side);
		f.y = 0.0f;
		g_PlayerSpeed -= f * PLAYER_MOVE_SPEED*P_Swim;
	}
	if (Keyboard_IsPress(DIK_W)) {
		D3DXVECTOR3 f(p_front);
		f.y = 0.0f;
		g_PlayerSpeed += f * PLAYER_MOVE_SPEED*P_Swim;
	}
	if (Keyboard_IsPress(DIK_S)) {
		D3DXVECTOR3 f(p_front);
		f.y = 0.0f;
		g_PlayerSpeed -= f * PLAYER_MOVE_SPEED*P_Swim;
	}
	g_PlayerPos += g_PlayerSpeed;
	g_PlayerSpeed *= 0.90f;
	g_PlayerPos.x = max(g_PlayerPos.x, -MeshWall_X + 0.3f);
	g_PlayerPos.x = min(g_PlayerPos.x, MeshWall_X - 0.1f);
	g_PlayerPos.z = max(g_PlayerPos.z, -MeshWall_Z + 0.3f);
	g_PlayerPos.z = min(g_PlayerPos.z, MeshWall_Z - 0.3f);
	D3DXMatrixRotationY(&mtxR, D3DXToRadian(rot));
	player_collision.position = g_PlayerPos;
	D3DXMatrixTranslation(&Trans, g_PlayerPos.x, g_PlayerPos.y, g_PlayerPos.z);
}
void Player_Gun_Funk(void)
{
	Frame_Gun_Cnt++;
	if (Keyboard_IsPress(DIK_DOWN))
	{
		if (P_Swim == 3)
		{
			P_ink += 0.25f;
		}
		else
		{
			P_ink += 0.02f;
		}
		P_Swim = Color_Judge();
	}
	else
	{
		P_Swim = 1;
	}
	P_ink = min(P_ink, 100.0f);
	switch (GunType(0))
	{
	case SHOOTER:
		if (Frame_Gun_Cnt > 8)
		{
			Frame_Gun_Cnt = 0;
		}
		if (Keyboard_IsPress(DIK_SPACE) && Frame_Gun_Cnt == 0 && P_ink >= 2.0f && !Keyboard_IsPress(DIK_DOWN)) {
			Bullet_Create(g_PlayerPos.x, g_PlayerPos.y + 0.75f, g_PlayerPos.z,0);
			P_ink -= 2.0f;
		}
		break;
	case SNIPER:
		if (Frame_Gun_Cnt > 60)
		{
			Frame_Gun_Cnt = 0;
		}
		if (Keyboard_IsPress(DIK_SPACE) && Frame_Gun_Cnt == 0 && P_ink >= 10.0f && !Keyboard_IsPress(DIK_DOWN)) {
			for (int i = 0; i <= 2; i++)
			{
				for (int r = 0; r <= 2; r++)
				{
					Bullet_Create(g_PlayerPos.x - 0.5 + 0.5*i, g_PlayerPos.y + 0.75f, g_PlayerPos.z - 0.5f*r,0);
				}
			}
			P_ink -= 10.0f;
		}
		break;
	case HUDE:
		if (Frame_Gun_Cnt > 16)
		{
			Frame_Gun_Cnt = 0;
			if (hude_judge)
			{
				hude_judge = false;
			}
			else
			{
				hude_judge = true;
			}
		}
		if (Keyboard_IsPress(DIK_SPACE) && Frame_Gun_Cnt == 0 && P_ink >= 2.0f && !Keyboard_IsPress(DIK_DOWN)) {
			Bullet_Create(g_PlayerPos.x, g_PlayerPos.y + 0.75f, g_PlayerPos.z,0);
			Bullet_Create(g_PlayerPos.x + 0.5f, g_PlayerPos.y + 0.75f, g_PlayerPos.z - 0.5f,0);
			Bullet_Create(g_PlayerPos.x - 0.5f, g_PlayerPos.y + 0.75f, g_PlayerPos.z - 0.5f,0);
			P_ink -= 2.0f;
		}
		break;
	case ROLLER:
		if (Frame_Gun_Cnt > 8)
		{
			Frame_Gun_Cnt = 0;
		}
		if (Keyboard_IsPress(DIK_SPACE) && Frame_Gun_Cnt == 0 && P_ink >= 1.0f && !Keyboard_IsPress(DIK_DOWN)) {
			for (int i = 0; i <= 2; i++)
			{
				for (int r = 0; r <= 2; r++)
				{
					Bullet_Create(g_PlayerPos.x - 0.5 + 0.5*i, g_PlayerPos.y + 0.75f, g_PlayerPos.z - 0.5f*r,0);
				}
			}
			P_ink -= 1.0f;
		}
		break;
	default:
		break;
	}
}
void Player_Draw(void)
{
	Model_Assemble(Trans, mtxR,0);
	if (Keyboard_IsPress(DIK_DOWN))
	{
		if(P_Swim==3)
		Sprite_Draw(SPEED, 0, 0);
		Model_Assemble_Machine(0.0f, 0.0f, 0.0f, Trans, mtxR,Rot,SAME,0);
	}
	Gun_Type();
	Sprite_Draw(INK, 10+ SCREEN_WIDTH - SCREEN_WIDTH / 4, 10+ SCREEN_HEIGHT / 15,0,0,(SCREEN_WIDTH / 5 - 12)*P_ink/100, SCREEN_HEIGHT / 30);
	Sprite_Draw(INK_GAZE, SCREEN_WIDTH-SCREEN_WIDTH/4, SCREEN_HEIGHT/15);
}
void Gun_Type(void)
{
	switch (GunType(0))
	{
	case SHOOTER:
		if (Keyboard_IsPress(DIK_SPACE)&&!Keyboard_IsPress(DIK_DOWN)) {
			Model_Assemble_Machine(0.0f, 0.0f + 0.95, 0.9f, Trans, mtxR, Rot, SHOOTER_WEAPON,0);
		}
		break;
	case SNIPER:
		if (Keyboard_IsPress(DIK_SPACE) && !Keyboard_IsPress(DIK_DOWN)) {
			Model_Assemble_Machine(0.2f, 0.0f + 1.1, 0.5f, Trans, mtxR, Rot, CHAGER_WEAPON,0);
		}
		break;
	case HUDE:
		if (Keyboard_IsPress(DIK_SPACE) &&P_ink >= 1.0f && !Keyboard_IsPress(DIK_DOWN)) {
			if (hude_judge)
			{
				Model_Assemble_Machine(-0.3f, 0.0f + 1.15, 0.3f, Trans, mtxR, Rot, PABURO_WEAPON,0);
			}
			else
			{
				Model_Assemble_Machine(0.3f, 0.0f + 0.85, 0.3f, Trans, mtxR, Rot, PABURO_WEAPON,0);
			}
		}
		break;
	case ROLLER:
		if (Keyboard_IsPress(DIK_SPACE) && !Keyboard_IsPress(DIK_DOWN)) {
			Model_Assemble_Machine(0.0f, 0.0f + 0.25, 0.7f, Trans, mtxR, Rot, ROLLER_WEAPON,0);
		}
		break;
	default:
		break;
	}
}
D3DXVECTOR3 Player_Pos(void)
{
	return g_PlayerPos;
}
D3DXVECTOR3 MTXR_FROANT(void)
{
	return p_front;
}
void Plyer_Dead(void)
{
	if (player_life < 0)
	{
		g_PlayerPos = D3DXVECTOR3(0.0f, 0.0f, -20.0f);
		player_life = 100;
	}
}
bool Hude_Judge(void)
{
	return	hude_judge;
}
void Player_Life(int damege)
{
	player_life -= damege;
}
const SphreCollision*Player_GetCircleCollision()
{
	return &player_collision;
}