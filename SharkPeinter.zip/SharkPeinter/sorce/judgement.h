//=============================================================================
//
// �����蔻�菈�� [judgement.h]
//
//=============================================================================
#ifndef JUDGEMENT_H
#define JUDGEMENT_H

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void judgement_Initialize(void);
void Judgement_Update(void);
void Judgement_Draw(void);
int Time(void);
int End(void);
#endif	//JUDGEMENT_H