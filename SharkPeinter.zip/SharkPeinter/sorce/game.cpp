//=============================================================================
//
// �Q�[������ [game.cpp]
//
//=============================================================================
/*------------------------------------------------------------------------------
   �֐���`
------------------------------------------------------------------------------*/
#include"camera.h"
#include"Blender.h"
#include"light.h"
#include"Mesh_filed.h"
#include"Player.h"
#include"bullet.h"
#include"enemy.h"
#include"judgement.h"
#include"fade.h"
#include"sprite.h"
#include"billborad.h"
#include"effect.h"
#include"shadow.h"
#include"number.h"
#include"score.h"
#include"title.h"
#include"texture.h"
#include"common.h"
#include"input.h"
#include"scene.h"
typedef enum PHASE_INDEX
{
	PHASE_INDEX_FADE,
	PHASE_INDEX_PLAYER_IN,
	PHASE_INDEX_MAX
};

static PHASE_INDEX g_Phase;
// �Q�[���̏�����
void Game_Initialize(void)
{
	g_Phase = PHASE_INDEX_FADE;
	Camera_Initilize();
	Light_SetLight();
	Mesh_Field_Initialize(0.25f, MeshFiled_X, MeshFiled_Z);//�n��
	Mesh_Skydome_Initialize(10.0f, 250.0f, 20, 20);//�w�i
	Mesh_Cylinder_Initialize(10.0f, 100.0f, 3, 10);
	Mesh_Wall_Initialize1(0.25f, 0.25f, MeshFiled_X, 20);//����
	Mesh_Wall_Initialize2(0.25f, 0.25f, MeshFiled_X, 20);//��O��
	Mesh_Wall_Initialize3(0.25f, 0.25f, MeshFiled_X, 20);//�E��
	Mesh_Wall_Initialize4(0.25f, 0.25f, MeshFiled_X, 20);//����
	Player_Initialize();

	judgement_Initialize();
	for (int i = 1; i <= 3; i++)
	{
		Enemy_Initialize(i);
	}
	for (int i = 0; i < MODEL_MAX; i++)
	{
		for (int r = 0; r <= 3; r++)
			Model_XFile(i, r);
	}
	for (int i = 0; i <= 3; i++)
	{
		Bullet_Init(i);
	}
	Effect2_Initialize();
	Bilboard_Initialize();
	Shadow_Initialize();
}
// �Q�[���̏I������
void Game_Finalize(void)
{
	for (int i = 0; i < MODEL_MAX; i++)
	{
		Model_Finalize(i);
	}
	Bilboard_Finalize();
	Shadow_Finalize();
}
// �Q�[���̍X�V
void Game_Update(void)
{
	if (g_Phase == PHASE_INDEX_FADE)
	{
		switch (g_Phase)
		{
		case PHASE_INDEX_FADE:
			if (!Fade_IsFade())
			{

				g_Phase = PHASE_INDEX_PLAYER_IN;
				Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			}
			break;
		case PHASE_INDEX_PLAYER_IN:
			break;
		}
	}
	if (g_Phase == PHASE_INDEX_PLAYER_IN&& !End())
	{
		Camera_Updata();
		Player_Update();
		Effect2_Update();
		if (Title_Select() != 2)
		{
			for (int i = 1; i <= 3; i++)
			{
				Enemy_Update(i);
			}
			for (int i = 0; i <= 3; i++)
			{
				Model_Update(i);
				Bullet_Update(i);
			}
		}
		else if (Title_Select() == 2)
		{
			Model_Update(0);
			Bullet_Update(0);
			if (Keyboard_IsTrigger(DIK_B))
			{
				Scene_Change(SCENE_INDEX_TITLE);
			}
		}
		Bilboard_Update();
	}
	if (Title_Select() != 2)
	{
		Judgement_Update();
	}
}
// �Q�[���̕`��
void Game_Draw(void)
{
	Player_Draw();
	for (int i = 0; i < FILED_MAX-1; i++)
	{
		Mesh_Field_Draw(i+1);
	}
	Filed_Paint(0);
	Draw_Camera();
	Effect2_Draw();
	if (Title_Select() != 2)
	{
		for (int i = 1; i <= 3; i++)
		{
			Enemy_Draw(i);
		}
		for (int i = 0; i <= 3; i++)
		{
			Bullet_Draw(i);
		}
		Judgement_Draw();
		for (int i = 0; i <= 3; i++)
		{
			Shadow_Draw(i);
		}
	}
	else if (Title_Select() == 2)
	{
		Bullet_Draw(0);
		Sprite_Draw(TEACH1, 0, 0);
		Sprite_Draw(TEACH2, SCREEN_WIDTH / 3*2, SCREEN_HEIGHT/7*3);
		Sprite_Draw(TEACH3, SCREEN_WIDTH / 5 * 4, SCREEN_HEIGHT / 10);
		Shadow_Draw(0);
	}
}