//=============================================================================
//
// �v���C���[���� [Enemy.cpp]
//
//=============================================================================
//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"mydirect.h"
#include"Blender.h"
#include<d3dx9.h>
#include"input.h"
#include"camera.h"
#include"debug_font.h"
#include"enemy.h"
#include"bullet.h"
#include"Mesh_filed.h"
#include"collision.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static ENEMY enemy[ENEMY_MAX];
//------------------------------------
//		����������
//------------------------------------
void Enemy_Initialize(int charaindex) {
	enemy[charaindex].EnemySpeed = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	enemy[1].EnemyPos = D3DXVECTOR3(0.0f, 0.0f, 20.0f);
	enemy[2].EnemyPos = D3DXVECTOR3(-20.0f, 0.0f, 0.0f);
	enemy[3].EnemyPos = D3DXVECTOR3(20.0f, 0.0f, 0.0f);
	enemy[charaindex].front = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	D3DXVec3Normalize(&enemy[charaindex].front, &enemy[charaindex].front);
	enemy[charaindex].height = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXVec3Cross(&enemy[charaindex].side, &enemy[charaindex].height, &enemy[charaindex].front);
	D3DXVec3Normalize(&enemy[charaindex].side, &enemy[charaindex].side);
	D3DXVec3Cross(&enemy[charaindex].height, &enemy[charaindex].front, &enemy[charaindex].side);
	D3DXVec3Normalize(&enemy[charaindex].height, &enemy[charaindex].height);
	enemy[charaindex].Enemy_collision.position = enemy[charaindex].EnemyPos;
	enemy[charaindex].Enemy_collision.radius = 0.5f;
	enemy[charaindex].rot = 0.0f;
	enemy[charaindex].Frame_Gun_Cnt = 0;
	enemy[charaindex].ink = 100.0f;
	enemy[charaindex].Swim = 1;
	enemy[charaindex].hude_judge = false;
	enemy[charaindex].Press_button = 1;
	enemy[charaindex].shoot = true;
	enemy[charaindex].enemy_life=100;
}
//------------------------------------
//		�X�V����
//------------------------------------
void Enemy_Update(int charaindex) {
	D3DXMatrixIdentity(&enemy[charaindex].Trans);
	D3DXMatrixIdentity(&enemy[charaindex].mtxR_Enemy);
	D3DXMatrixIdentity(&enemy[charaindex].Rot);
	Enemy_Move_Func(charaindex);
	Enemy_Gun_Funk(charaindex);
	Enemy_Dead(charaindex);
}
void Enemy_Move_Func(int charaindex)
{
	if (Keyboard_IsPress(DIK_RIGHT))
	{
		enemy[charaindex].rot += 1.0f;
		D3DXMatrixRotationAxis(&enemy[charaindex].mtxR_Enemy, &enemy[charaindex].height, D3DXToRadian(1));
		D3DXVec3TransformNormal(&enemy[charaindex].front, &enemy[charaindex].front, &enemy[charaindex].mtxR_Enemy);
		D3DXVec3TransformNormal(&enemy[charaindex].side, &enemy[charaindex].side, &enemy[charaindex].mtxR_Enemy);
	}
	if (Keyboard_IsPress(DIK_LEFT))
	{
		enemy[charaindex].rot -= 1.0f;
		D3DXMatrixRotationAxis(&enemy[charaindex].mtxR_Enemy, &-enemy[charaindex].height, D3DXToRadian(1));
		D3DXVec3TransformNormal(&enemy[charaindex].front, &enemy[charaindex].front, &enemy[charaindex].mtxR_Enemy);
		D3DXVec3TransformNormal(&enemy[charaindex].side, &enemy[charaindex].side, &enemy[charaindex].mtxR_Enemy);
	}
	if (enemy[charaindex].Press_button ==Press_D) {
		D3DXVECTOR3 f(enemy[charaindex].side);
		f.y = 0.0f;
		enemy[charaindex].EnemySpeed += f * ENEMY_MOVE_SPEED*enemy[charaindex].Swim;
	}
	if (enemy[charaindex].Press_button == Press_A) {
		D3DXVECTOR3 f(enemy[charaindex].side);
		f.y = 0.0f;
		enemy[charaindex].EnemySpeed -= f * ENEMY_MOVE_SPEED*enemy[charaindex].Swim;
	}
	if (enemy[charaindex].Press_button == Press_W) {
		D3DXVECTOR3 f(enemy[charaindex].front);
		f.y = 0.0f;
		enemy[charaindex].EnemySpeed += f * ENEMY_MOVE_SPEED*enemy[charaindex].Swim;
	}
	if (enemy[charaindex].Press_button == Press_S) {
		D3DXVECTOR3 f(enemy[charaindex].front);
		f.y = 0.0f;
		enemy[charaindex].EnemySpeed -= f * ENEMY_MOVE_SPEED*enemy[charaindex].Swim;
	}
	enemy[charaindex].EnemyPos += enemy[charaindex].EnemySpeed;
	enemy[charaindex].EnemySpeed *= 0.90f;
	enemy[charaindex].EnemyPos.x = max(enemy[charaindex].EnemyPos.x, -MeshWall_X + 0.3f);
	enemy[charaindex].EnemyPos.x = min(enemy[charaindex].EnemyPos.x, MeshWall_X - 0.1f);
	enemy[charaindex].EnemyPos.z = max(enemy[charaindex].EnemyPos.z, -MeshWall_Z + 0.3f);
	enemy[charaindex].EnemyPos.z = min(enemy[charaindex].EnemyPos.z, MeshWall_Z - 0.3f);
	D3DXMatrixRotationY(&enemy[charaindex].mtxR, D3DXToRadian(enemy[charaindex].rot));
	enemy[charaindex].Enemy_collision.position = enemy[charaindex].EnemyPos;
	D3DXMatrixTranslation(&enemy[charaindex].Trans, enemy[charaindex].EnemyPos.x, enemy[charaindex].EnemyPos.y, enemy[charaindex].EnemyPos.z);
}
void Enemy_Gun_Funk(int charaindex)
{
	enemy[charaindex].Frame_Gun_Cnt++;
	if (enemy[charaindex].Press_button == Press_DOWN)
	{
		if (enemy[charaindex].Swim == 3)
		{
			enemy[charaindex].ink += 0.25f;
		}
		else
		{
			enemy[charaindex].ink += 0.02f;
		}
		enemy[charaindex].Swim = Color_Judge();
	}
	else
	{
		enemy[charaindex].Swim = 1;
	}
	enemy[charaindex].ink = min(enemy[charaindex].ink, 100.0f);
	switch (GunType(charaindex))
	{
	case SHOOTER:
		if (enemy[charaindex].Frame_Gun_Cnt > 8)
		{
			enemy[charaindex].Frame_Gun_Cnt = 0;
		}
		if (enemy[charaindex].shoot && enemy[charaindex].Frame_Gun_Cnt == 0 && enemy[charaindex].ink >= 2.0f && enemy[charaindex].Press_button != Press_DOWN) {
			Bullet_Create(enemy[charaindex].EnemyPos.x, enemy[charaindex].EnemyPos.y + 0.75f, enemy[charaindex].EnemyPos.z, charaindex);
			enemy[charaindex].ink -= 2.0f;
		}
		break;
	case SNIPER:
		if (enemy[charaindex].Frame_Gun_Cnt > 60)
		{
			enemy[charaindex].Frame_Gun_Cnt = 0;
		}
		if (enemy[charaindex].shoot && enemy[charaindex].Frame_Gun_Cnt == 0 && enemy[charaindex].ink >= 10.0f && enemy[charaindex].Press_button != Press_DOWN) {
			for (int i = 0; i <= 2; i++)
			{
				for (int r = 0; r <= 2; r++)
				{
					Bullet_Create(enemy[charaindex].EnemyPos.x - 0.5 + 0.5*i, enemy[charaindex].EnemyPos.y + 0.75f, enemy[charaindex].EnemyPos.z - 0.5f*r, charaindex);
				}
			}
			enemy[charaindex].ink -= 10.0f;
		}
		break;
	case HUDE:
		if (enemy[charaindex].Frame_Gun_Cnt > 16)
		{
			enemy[charaindex].Frame_Gun_Cnt = 0;
			if (enemy[charaindex].hude_judge)
			{
				enemy[charaindex].hude_judge = false;
			}
			else
			{
				enemy[charaindex].hude_judge = true;
			}
		}
		if (enemy[charaindex].shoot && enemy[charaindex].Frame_Gun_Cnt == 0 && enemy[charaindex].ink >= 2.0f && enemy[charaindex].Press_button != Press_DOWN) {
			Bullet_Create(enemy[charaindex].EnemyPos.x, enemy[charaindex].EnemyPos.y + 0.75f, enemy[charaindex].EnemyPos.z, charaindex);
			Bullet_Create(enemy[charaindex].EnemyPos.x + 0.5f, enemy[charaindex].EnemyPos.y + 0.75f, enemy[charaindex].EnemyPos.z - 0.5f, charaindex);
			Bullet_Create(enemy[charaindex].EnemyPos.x - 0.5f, enemy[charaindex].EnemyPos.y + 0.75f, enemy[charaindex].EnemyPos.z - 0.5f, charaindex);
			enemy[charaindex].ink -= 2.0f;
		}
		break;
	case ROLLER:
		if (enemy[charaindex].Frame_Gun_Cnt > 8)
		{
			enemy[charaindex].Frame_Gun_Cnt = 0;
		}
		if (enemy[charaindex].shoot && enemy[charaindex].Frame_Gun_Cnt == 0 && enemy[charaindex].ink >= 1.0f && enemy[charaindex].Press_button != Press_DOWN) {
			for (int i = 0; i <= 2; i++)
			{
				for (int r = 0; r <= 2; r++)
				{
					Bullet_Create(enemy[charaindex].EnemyPos.x - 0.5 + 0.5*i, enemy[charaindex].EnemyPos.y + 0.75f, enemy[charaindex].EnemyPos.z - 0.5f*r, charaindex);
				}
			}
			enemy[charaindex].ink -= 1.0f;
		}
		break;
	default:
		break;
	}
}
void Enemy_Draw(int charaindex)
{
	Model_Assemble(enemy[charaindex].Trans, enemy[charaindex].mtxR,charaindex);
	if (enemy[charaindex].Press_button == Press_DOWN)
	{
		Model_Assemble_Machine(0.0f, 0.0f, 0.0f, enemy[charaindex].Trans, enemy[charaindex].mtxR, enemy[charaindex].Rot, SAME, charaindex);
	}
	Gun_Type(charaindex);
}
void Gun_Type(int charaindex)
{
	switch (GunType(charaindex))
	{
	case SHOOTER:
		if (enemy[charaindex].shoot && enemy[charaindex].Press_button != Press_DOWN) {
			Model_Assemble_Machine(0.0f, 0.0f + 0.95, 0.9f, enemy[charaindex].Trans, enemy[charaindex].mtxR, enemy[charaindex].Rot, SHOOTER_WEAPON, charaindex);
		}
		break;
	case SNIPER:
		if (enemy[charaindex].shoot && enemy[charaindex].Press_button != Press_DOWN) {
			Model_Assemble_Machine(0.2f, 0.0f + 1.1, 0.5f, enemy[charaindex].Trans, enemy[charaindex].mtxR, enemy[charaindex].Rot, CHAGER_WEAPON, charaindex);
		}
		break;
	case HUDE:
		if (enemy[charaindex].shoot && enemy[charaindex].ink >= 1.0f && enemy[charaindex].Press_button != Press_DOWN) {
			if (enemy[charaindex].hude_judge)
			{
				Model_Assemble_Machine(-0.3f, 0.0f + 1.15, 0.3f, enemy[charaindex].Trans, enemy[charaindex].mtxR, enemy[charaindex].Rot, PABURO_WEAPON, charaindex);
			}
			else
			{
				Model_Assemble_Machine(0.3f, 0.0f + 0.85, 0.3f, enemy[charaindex].Trans, enemy[charaindex].mtxR, enemy[charaindex].Rot, PABURO_WEAPON, charaindex);
			}
		}
		break;
	case ROLLER:
		if (enemy[charaindex].shoot && enemy[charaindex].Press_button != Press_DOWN) {
			Model_Assemble_Machine(0.0f, 0.0f + 0.25, 0.7f, enemy[charaindex].Trans, enemy[charaindex].mtxR, enemy[charaindex].Rot, ROLLER_WEAPON, charaindex);
		}
		break;
	default:
		break;
	}
}
D3DXVECTOR3 Enemy_Pos(int charaindex)
{
	return enemy[charaindex].EnemyPos;
}
const SphreCollision*Enemy_GetCircleCollision(int charaindex)
{
	return &enemy[charaindex].Enemy_collision;
}
void Enemy_Dead(int charaindex)
{
	if (enemy[charaindex].enemy_life < 0)
	{
		if(charaindex==1)
		enemy[1].EnemyPos = D3DXVECTOR3(0.0f, 0.0f, 20.0f);
		else if (charaindex == 2)
			enemy[2].EnemyPos = D3DXVECTOR3(-20.0f, 0.0f, 0.0f);
		else if (charaindex == 3)
			enemy[3].EnemyPos = D3DXVECTOR3(20.0f, 0.0f, 0.0f);
		enemy[charaindex].enemy_life = 100;
	}
}
void Enemy_Life(int damege,int charaindex)
{
	enemy[charaindex].enemy_life -= damege;
}
int AI_command(int charaindex)
{
	return enemy[charaindex].Press_button;
}
bool AI_Shoot(int charaindex)
{
	return enemy[charaindex].shoot;
}
bool Hude_Judge2(int charaindex)
{
	return	enemy[charaindex].hude_judge;
}