//=============================================================================
//	�C���N���[�h�t�@�C��
//=============================================================================
#include <d3dx9.h>
#include "mydirect.h"
#include "common.h"
#include "Mesh_filed.h"
#include "texture.h"
#include "light.h"
#include "input.h"
#include "Player.h"
#include "bullet.h"
#include "debug_font.h"
#include "enemy.h"
#include "billborad.h"
#include"judgement.h"
//=============================================================================
//	�萔��`
//=============================================================================
#define MAX_MESH_FIELD (100000)
//=============================================================================
//	�O���[�o���錾
//=============================================================================
//3D�|���S�����_�@�\����
typedef struct
{
	D3DXVECTOR3 pos;	//	���Wx,y,z
	D3DXVECTOR3 normal;
	D3DCOLOR color;
	D3DXVECTOR2 texture;		//  �e�N�X�`��
}MeshFieldVertex;
#define FVF_MESH_FIELD_VERTEX  (D3DFVF_XYZ|D3DFVF_NORMAL|D3DFVF_DIFFUSE|D3DFVF_TEX1) // �QD�|���S�����_�t�H�[�}�b�g
static MeshFieldVertex g_Mfield[MAX_MESH_FIELD];
static MeshFieldVertex g_Mfield_Filed[MAX_MESH_FIELD];
static MeshFieldVertex p_Mfield_Filed[MAX_MESH_FIELD];
static LPDIRECT3DVERTEXBUFFER9 g_pVertexBuffer[7] = { NULL };
static LPDIRECT3DINDEXBUFFER9 g_pIndexBuffer[7] = { NULL };
static int g_VertexCount[7] = { 0 };
static int g_PrimitiveCount[7] = { 0 };
static int g_collision_num[BULLET_MAX];
static int g_collision_num2[BULLET_MAX];
static int p_collision_num;
static int p_collision_num2;
static int e_collision_num[3];
static int e_collision_num2[3];
static int color_count[4];
static int color[4];
static int color_judge;
static float rot = 0.0f;
static bool ink_count_judge;
//���ʕ`��
void Mesh_Field_Initialize(float meshW, int meshXnum, int meshZnum)
{
	int meshXX = meshXnum + 1;	//	�ő咸�_X
	int meshZZ = meshZnum + 1;	//	�ő咸�_Z
	g_VertexCount[0] = (meshXX) * (meshZZ);
	int IndexCount = (meshXnum + 2) * (meshZnum * 2) - 2;
	g_PrimitiveCount[0] = (meshXnum * 2 + 4) * meshZnum - 4;
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	// ���_�o�b�t�@�̊m��
	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[0], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[0], NULL);
	// �C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) * IndexCount, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &g_pIndexBuffer[0], NULL);
	for (int z = 0; z < meshZZ; z++)
	{
		for (int x = 0; x < meshXX; x++)
		{
			int n = x + meshXX * z;
			float x_size = ((float)meshXnum * 0.5f * -meshW) + (meshW * x);
			float z_size = ((float)meshZnum * 0.5 * meshW) + (-meshW * z);
			g_Mfield_Filed[n].pos = D3DXVECTOR3(x_size, 0, z_size);
			g_Mfield_Filed[n].normal = D3DXVECTOR3(0.0f, 0.5f, -1.0f);//��O
			g_Mfield_Filed[n].color = D3DCOLOR_RGBA(255, 255, 255, 255);
			g_Mfield_Filed[n].texture = D3DXVECTOR2(x_size, z_size);
		}
	}
	// ���z�A�h���X�@
	MeshFieldVertex *pv;
	// ���_�o�b�t�@�̃��b�N
	g_pVertexBuffer[0]->Lock(0, 0, (void**)&pv, 0);
	//memcpy(pv, g_Mfield, sizeof(g_Mfield[MAX_MESH_FIELD]));
	for (int i = 0; i < g_VertexCount[0]; i++)
	{
		pv[i] = g_Mfield_Filed[i];
	}
	g_pVertexBuffer[0]->Unlock();
	// ���z�A�h���X�@
	WORD *Ipv;
	// �C���f�b�N�X�o�b�t�@�̃��b�N
	g_pIndexBuffer[0]->Lock(0, 0, (void**)&Ipv, 0);

	for (int z = 0; z < meshZnum * 2 - 1; z++)
	{
		if (z < meshZnum)
		{
			for (int x = 0; x < meshXX * 2; x++)
			{
				if (x % 2 == 0)
				{
					Ipv[(meshXX + 1) * (2 * z) + x] = meshXX + (meshXX * z) + (x * 0.5);
				}
				else
				{
					Ipv[(meshXX + 1) * (2 * z) + x] = (meshXX * z) + ((x - 1) * 0.5);
				}
			}
		}
		else
		{
			Ipv[(meshXX * 2)*(z - meshZnum + 1) + (2 * (z - meshZnum))] = meshXX * (z - meshZnum + 1) - 1;
			Ipv[(meshXX * 2)*(z - meshZnum + 1) + (2 * (z - meshZnum)) + 1] = meshXX * (z - meshZnum + 2);
		}
	}
	g_pIndexBuffer[0]->Unlock();
	for (int i = 0; i <= 3; i++)
	{
		color_count[i] = { 0 };
		color[i] = { 0 };
	}
	color[0] = { 255 };
	color_judge = 1;
	p_collision_num=0;
	p_collision_num2=0;
	for (int i = 0; i <= 2; i++)
	{
		e_collision_num[i]= { 0 };;
		e_collision_num2[i]= { 0 };;
	}
	rot = 0;
	ink_count_judge=false;
}
//�V�����_�[
void Mesh_Cylinder_Initialize(float meshH, float radius, int meshXnum, int meshYnum)
{
	int VertexX = meshXnum + 1;	//	�ő咸�_X
	int VertexY = meshYnum + 1;	//	�ő咸�_Z

	g_VertexCount[1] = (VertexX)* (VertexY);
	int IndexCount = (meshXnum + 2) * (meshYnum * 2) - 2;
	g_PrimitiveCount[1] = (meshXnum * 2 + 4) * meshYnum - 4;


	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	// ���_�o�b�t�@�̊m��
	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[1], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[1], NULL);
	// �C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) * IndexCount, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &g_pIndexBuffer[1], NULL);



	for (int y = 0; y < VertexY; y++)
	{
		for (int x = 0; x < VertexX; x++)
		{
			int n = x + VertexX * y;
			float angle = 360 / meshXnum * x;
			g_Mfield[n].pos = D3DXVECTOR3(radius * sinf(D3DXToRadian(angle)), meshYnum * meshH - (y * meshH)-40.0f, radius * cosf(D3DXToRadian(angle)));
			g_Mfield[n].normal = D3DXVECTOR3(0.0f, 0.5f, -1.0f);//��O
			g_Mfield[n].color = D3DCOLOR_RGBA(255, 255, 255, 255);
			g_Mfield[n].texture = D3DXVECTOR2((VertexX - x)*(1.0f / VertexX), -((VertexY - y)* (1.0f / VertexY)));
		}
	}



	// ���z�A�h���X�@
	MeshFieldVertex *pv;
	// ���_�o�b�t�@�̃��b�N
	g_pVertexBuffer[1]->Lock(0, 0, (void**)&pv, 0);

	//memcpy(pv, g_Mfield, sizeof(g_Mfield[MAX_MESH_FIELD]));
	for (int i = 0; i < g_VertexCount[1]; i++)
	{
		pv[i] = g_Mfield[i];
	}
	g_pVertexBuffer[1]->Unlock();

	// ���z�A�h���X�@
	WORD *Ipv;
	// �C���f�b�N�X�o�b�t�@�̃��b�N
	g_pIndexBuffer[1]->Lock(0, 0, (void**)&Ipv, 0);

	for (int y = 0; y < meshYnum * 2 - 1; y++)
	{
		if (y < meshYnum)
		{
			for (int x = 0; x < VertexX * 2; x++)
			{
				if (x % 2 == 0)
				{
					Ipv[(VertexX + 1) * (2 * y) + x] = VertexX + (VertexX * y) + (x * 0.5);
				}
				else
				{
					Ipv[(VertexX + 1) * (2 * y) + x] = (VertexX * y) + ((x - 1) * 0.5);
				}
			}
		}
		else
		{
			Ipv[(VertexX * 2)*(y - meshYnum + 1) + (2 * (y - meshYnum))] = VertexX * (y - meshYnum + 1) - 1;
			Ipv[(VertexX * 2)*(y - meshYnum + 1) + (2 * (y - meshYnum)) + 1] = VertexX * (y - meshYnum + 2);
		}
	}

	g_pIndexBuffer[1]->Unlock();

}
//�X�J�C�h�[��
void Mesh_Skydome_Initialize(float meshH, float radius, int meshXnum, int meshYnum)
{
	int VertexX = meshXnum + 1;	//	�ő咸�_X
	int VertexY = meshYnum + 1;	//	�ő咸�_Z

	g_VertexCount[2] = (VertexX)* (VertexY);
	int IndexCount = (meshXnum + 2) * (meshYnum * 2) - 2;
	g_PrimitiveCount[2] = (meshXnum * 2 + 4) * meshYnum - 4;


	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	// ���_�o�b�t�@�̊m��
	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[2], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[2], NULL);
	// �C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) * IndexCount, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &g_pIndexBuffer[2], NULL);

	float Subtotal = 0;

	for (int y = 0; y <= VertexY; y++)
	{
		if (y == 0)
		{
			for (int x = 0; x < VertexX; x++)
			{
				int n = x + VertexX * y;
				g_Mfield[n].pos = D3DXVECTOR3(0, meshYnum * meshH - 100, 0);
				g_Mfield[n].normal = D3DXVECTOR3(0.0f, 0.5f, -1.0f);//��O
				g_Mfield[n].color = D3DCOLOR_RGBA(255, 255, 255, 255);
				g_Mfield[n].texture = D3DXVECTOR2((VertexX - x)*(1.0f / (VertexX + 1)), (VertexY - y)* (1.0f / (VertexY + 1)));
			}
		}
		else
		{

			Subtotal += (y * meshH / VertexY) * 2;
			for (int x = 0; x < VertexX; x++)
			{
				int n = x + VertexX * y;
				float angle = 360 / meshXnum * x;

				g_Mfield[n].pos = D3DXVECTOR3(radius / VertexY * y * sinf(D3DXToRadian(angle)), (meshYnum * meshH) - Subtotal - 100, radius / VertexY * y * cosf(D3DXToRadian(angle)));
				g_Mfield[n].normal = D3DXVECTOR3(0.0f, 0.5f, -1.0f);//��O
				g_Mfield[n].color = D3DCOLOR_RGBA(255, 255, 255, 255);
				g_Mfield[n].texture = D3DXVECTOR2((VertexX - x)*(1.0f / (VertexX + 1)), (VertexY - y)* (1.0f / (VertexY + 1)));
			}
		}

	}

	// ���z�A�h���X�@
	MeshFieldVertex *pv;
	// ���_�o�b�t�@�̃��b�N
	g_pVertexBuffer[2]->Lock(0, 0, (void**)&pv, 0);

	//memcpy(pv, g_Mfield, sizeof(g_Mfield[MAX_MESH_FIELD]));
	for (int i = 0; i < g_VertexCount[2]; i++)
	{
		pv[i] = g_Mfield[i];
	}
	g_pVertexBuffer[2]->Unlock();

	// ���z�A�h���X�@
	WORD *Ipv;
	// �C���f�b�N�X�o�b�t�@�̃��b�N
	g_pIndexBuffer[2]->Lock(0, 0, (void**)&Ipv, 0);

	for (int y = 0; y < meshYnum * 2 - 1; y++)
	{
		if (y < meshYnum)
		{
			for (int x = 0; x < VertexX * 2; x++)
			{
				if (x % 2 == 0)
				{
					Ipv[(VertexX + 1) * (2 * y) + x] = VertexX + (VertexX * y) + (x * 0.5);
				}
				else
				{
					Ipv[(VertexX + 1) * (2 * y) + x] = (VertexX * y) + ((x - 1) * 0.5);
				}
			}
		}
		else
		{
			Ipv[(VertexX * 2)*(y - meshYnum + 1) + (2 * (y - meshYnum))] = VertexX * (y - meshYnum + 1) - 1;
			Ipv[(VertexX * 2)*(y - meshYnum + 1) + (2 * (y - meshYnum)) + 1] = VertexX * (y - meshYnum + 2);
		}
	}


	g_pIndexBuffer[2]->Unlock();

}
//���̕�
void Mesh_Wall_Initialize1(float gridsizex, float gridsizez, int gridcntx, int gridcntz)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	float MeshIndex = 0;		//�C���f�b�N�X�̐�
	float bufferx = 0;		    //���S��^�񒆂ɂ��炷
	float bufferz = 0;
	int cnt = 0;
	g_VertexCount[3] = (gridcntx + 1)*(gridcntz + 1);			//���_�̐�
	g_PrimitiveCount[3] = (gridcntx * 2 + 4) * gridcntz - 4;
	MeshIndex = ((gridcntx * 2) + 2)*gridcntz + (gridcntz - 1) * 2;

	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[3], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[3], NULL);
	//�C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) *MeshIndex, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_pIndexBuffer[3], NULL);

	for (int i = 0; i < g_VertexCount[3]; i++)
	{
		bufferx = i % (gridcntx + 1)*gridsizex - (gridcntx*gridsizex) / 2;
		bufferz = i / (gridcntx + 1)*(-gridsizez) + ((gridcntz + 1)*gridsizez) / 2;
		g_Mfield[i].pos = D3DXVECTOR3(bufferx, bufferz + 2.35, MeshWall_Z);
		g_Mfield[i].normal = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
		g_Mfield[i].color = 0x99ffffff;
		g_Mfield[i].texture = D3DXVECTOR2(bufferx, bufferz);
	}

	MeshFieldVertex *pv;

	g_pVertexBuffer[3]->Lock(0, 0, (void**)&pv, 0);

	for (int i = 0; i < g_VertexCount[3]; i++)
	{
		pv[i] = g_Mfield[i];
	}

	g_pVertexBuffer[3]->Unlock();

	WORD *pMeshIndex;
	g_pIndexBuffer[3]->Lock(0, 0, (void**)&pMeshIndex, 0);
	for (int i = 0; i < MeshIndex; i += 2)
	{
		pMeshIndex[i] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1) + 1);
		pMeshIndex[i + 1] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1));
		if (cnt % (gridcntx + 1) == gridcntx)
		{
			i += 2;
			pMeshIndex[i] = pMeshIndex[i - 1];
			pMeshIndex[i + 1] = (cnt + 1) % (gridcntx + 1) + (gridcntx + 1)*((cnt + 1) / (gridcntx + 1) + 1);

		}
		cnt++;
	}
	g_pIndexBuffer[3]->Unlock();

	g_VertexCount[3] = gridcntx * gridcntz * 2 + (gridcntx + 1) * 4;
}
//��O�̕�
void Mesh_Wall_Initialize2(float gridsizex, float gridsizez, int gridcntx, int gridcntz)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	float MeshIndex = 0;		//�C���f�b�N�X�̐�
	float bufferx = 0;		    //���S��^�񒆂ɂ��炷
	float bufferz = 0;
	int cnt = 0;
	g_VertexCount[4] = (gridcntx + 1)*(gridcntz + 1);			//���_�̐�
	g_PrimitiveCount[4] = (gridcntx * 2 + 4) * gridcntz - 4;
	MeshIndex = ((gridcntx * 2) + 2)*gridcntz + (gridcntz - 1) * 2;

	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[4], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[4], NULL);
	//�C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) *MeshIndex, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_pIndexBuffer[4], NULL);

	for (int i = 0; i < g_VertexCount[4]; i++)
	{
		bufferx = -(i % (gridcntx + 1)*gridsizex - (gridcntx*gridsizex) / 2);
		bufferz = i / (gridcntx + 1)*(-gridsizez) + ((gridcntz + 1)*gridsizez) / 2;
		g_Mfield[i].pos = D3DXVECTOR3(bufferx, bufferz + 2.35, -MeshWall_Z);
		g_Mfield[i].normal = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
		g_Mfield[i].color = 0x99ffffff;
		g_Mfield[i].texture = D3DXVECTOR2(bufferx, bufferz);
	}

	MeshFieldVertex *pv;

	g_pVertexBuffer[4]->Lock(0, 0, (void**)&pv, 0);

	for (int i = 0; i < g_VertexCount[4]; i++)
	{
		pv[i] = g_Mfield[i];
	}

	g_pVertexBuffer[4]->Unlock();

	WORD *pMeshIndex;
	g_pIndexBuffer[4]->Lock(0, 0, (void**)&pMeshIndex, 0);
	for (int i = 0; i < MeshIndex; i += 2)
	{
		pMeshIndex[i] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1) + 1);
		pMeshIndex[i + 1] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1));
		if (cnt % (gridcntx + 1) == gridcntx)
		{
			i += 2;
			pMeshIndex[i] = pMeshIndex[i - 1];
			pMeshIndex[i + 1] = (cnt + 1) % (gridcntx + 1) + (gridcntx + 1)*((cnt + 1) / (gridcntx + 1) + 1);

		}
		cnt++;
	}
	g_pIndexBuffer[4]->Unlock();

	g_VertexCount[4] = gridcntx * gridcntz * 2 + (gridcntx + 1) * 4;
}
//�E�̕�
void Mesh_Wall_Initialize3(float gridsizex, float gridsizez, int gridcntx, int gridcntz)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	float MeshIndex = 0;		//�C���f�b�N�X�̐�
	float bufferx = 0;		    //���S��^�񒆂ɂ��炷
	float bufferz = 0;
	int cnt = 0;
	g_VertexCount[5] = (gridcntx + 1)*(gridcntz + 1);			//���_�̐�
	g_PrimitiveCount[5] = (gridcntx * 2 + 4) * gridcntz - 4;
	MeshIndex = ((gridcntx * 2) + 2)*gridcntz + (gridcntz - 1) * 2;

	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[5], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[5], NULL);
	//�C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) *MeshIndex, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_pIndexBuffer[5], NULL);

	for (int i = 0; i < g_VertexCount[5]; i++)
	{
		bufferx = -(i % (gridcntx + 1)*gridsizex - (gridcntx*gridsizex) / 2);
		bufferz = i / (gridcntx + 1)*(-gridsizez) + ((gridcntz + 1)*gridsizez) / 2;
		g_Mfield[i].pos = D3DXVECTOR3(MeshWall_X, bufferz + 2.35, bufferx);
		g_Mfield[i].normal = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
		g_Mfield[i].color = 0x99ffffff;
		g_Mfield[i].texture = D3DXVECTOR2(bufferx, bufferz);
	}

	MeshFieldVertex *pv;

	g_pVertexBuffer[5]->Lock(0, 0, (void**)&pv, 0);

	for (int i = 0; i < g_VertexCount[5]; i++)
	{
		pv[i] = g_Mfield[i];
	}

	g_pVertexBuffer[5]->Unlock();

	WORD *pMeshIndex;
	g_pIndexBuffer[5]->Lock(0, 0, (void**)&pMeshIndex, 0);
	for (int i = 0; i < MeshIndex; i += 2)
	{
		pMeshIndex[i] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1) + 1);
		pMeshIndex[i + 1] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1));
		if (cnt % (gridcntx + 1) == gridcntx)
		{
			i += 2;
			pMeshIndex[i] = pMeshIndex[i - 1];
			pMeshIndex[i + 1] = (cnt + 1) % (gridcntx + 1) + (gridcntx + 1)*((cnt + 1) / (gridcntx + 1) + 1);

		}
		cnt++;
	}
	g_pIndexBuffer[5]->Unlock();

	g_VertexCount[5] = gridcntx * gridcntz * 2 + (gridcntx + 1) * 4;
}
//���̕�
void Mesh_Wall_Initialize4(float gridsizex, float gridsizez, int gridcntx, int gridcntz)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	float MeshIndex = 0;		//�C���f�b�N�X�̐�
	float bufferx = 0;		    //���S��^�񒆂ɂ��炷
	float bufferz = 0;
	int cnt = 0;
	g_VertexCount[6] = (gridcntx + 1)*(gridcntz + 1);			//���_�̐�
	g_PrimitiveCount[6] = (gridcntx * 2 + 4) * gridcntz - 4;
	MeshIndex = ((gridcntx * 2) + 2)*gridcntz + (gridcntz - 1) * 2;

	pDevice->CreateVertexBuffer(sizeof(MeshFieldVertex) * g_VertexCount[6], D3DUSAGE_WRITEONLY, FVF_MESH_FIELD_VERTEX, D3DPOOL_MANAGED, &g_pVertexBuffer[6], NULL);
	//�C���f�b�N�X�o�b�t�@�̊m��
	pDevice->CreateIndexBuffer(sizeof(WORD) *MeshIndex, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_DEFAULT, &g_pIndexBuffer[6], NULL);

	for (int i = 0; i < g_VertexCount[6]; i++)
	{
		bufferx = (i % (gridcntx + 1)*gridsizex - (gridcntx*gridsizex) / 2);
		bufferz = i / (gridcntx + 1)*(-gridsizez) + ((gridcntz + 1)*gridsizez) / 2;
		g_Mfield[i].pos = D3DXVECTOR3(-MeshWall_X, bufferz + 2.35, bufferx);
		g_Mfield[i].normal = D3DXVECTOR3(0.0f, 0.0f, -1.0f);
		g_Mfield[i].color = 0x99ffffff;
		g_Mfield[i].texture = D3DXVECTOR2(bufferx, bufferz);
	}

	MeshFieldVertex *pv;

	g_pVertexBuffer[6]->Lock(0, 0, (void**)&pv, 0);

	for (int i = 0; i < g_VertexCount[6]; i++)
	{
		pv[i] = g_Mfield[i];
	}

	g_pVertexBuffer[6]->Unlock();

	WORD *pMeshIndex;
	g_pIndexBuffer[6]->Lock(0, 0, (void**)&pMeshIndex, 0);
	for (int i = 0; i < MeshIndex; i += 2)
	{
		pMeshIndex[i] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1) + 1);
		pMeshIndex[i + 1] = cnt % (gridcntx + 1) + (gridcntx + 1)*(cnt / (gridcntx + 1));
		if (cnt % (gridcntx + 1) == gridcntx)
		{
			i += 2;
			pMeshIndex[i] = pMeshIndex[i - 1];
			pMeshIndex[i + 1] = (cnt + 1) % (gridcntx + 1) + (gridcntx + 1)*((cnt + 1) / (gridcntx + 1) + 1);

		}
		cnt++;
	}
	g_pIndexBuffer[6]->Unlock();

	g_VertexCount[6] = gridcntx * gridcntz * 2 + (gridcntx + 1) * 4;
}
//�I������
void Mesh_Field_Finalize(void)
{
	for (int i = 0; i < 7; i++)
	{
		// �C���f�b�N�X�o�b�t�@�̉��
		if (g_pIndexBuffer[i] != NULL)
		{
			g_pIndexBuffer[i]->Release();
			g_pIndexBuffer[i] = NULL;
		}

		// ���_�o�b�t�@�̉��
		if (g_pVertexBuffer[i] != NULL)
		{
			g_pVertexBuffer[i]->Release();
			g_pVertexBuffer[i] = NULL;
		}
	}
}
//�`�揈��
void Mesh_Field_Draw(int index)
{
	D3DXMATRIX mtxWorld;
	D3DXMATRIX Rot;
	D3DXMatrixIdentity(&mtxWorld);
	D3DXMatrixIdentity(&Rot);
	//�f�o�C�X
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	pDevice->SetFVF(FVF_MESH_FIELD_VERTEX);
	pDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	rot+=0.01f;
	if (rot >= 360.0f)
	{
		rot = 0;
	}
	else if (index >= 1)
	{
		pDevice->SetTexture(0, Texture_GetTexture(CTLIN));
	}
	if (index == 2)
	{
		D3DXMatrixRotationY(&Rot, D3DXToRadian(rot));
		D3DXMatrixMultiply(&mtxWorld, &mtxWorld, &Rot);
		pDevice->SetTexture(0, Texture_GetTexture(SKYDOME));
	}
	else if (index >= 3)
	{
		pDevice->SetTexture(0, Texture_GetTexture(WALL));
	}
	pDevice->SetTransform(D3DTS_WORLD, &mtxWorld);
	pDevice->SetStreamSource(0, g_pVertexBuffer[index], 0, sizeof(MeshFieldVertex));
	pDevice->SetIndices(g_pIndexBuffer[index]);
	pDevice->DrawIndexedPrimitive(D3DPT_TRIANGLESTRIP, 0, 0, g_VertexCount[index], 0, g_PrimitiveCount[index]);

}
void Filed_Paint(int index)
{
	D3DXMATRIX mtxWorld;
	D3DXMatrixIdentity(&mtxWorld);
	//�f�o�C�X
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	pDevice->SetRenderState(D3DRS_LIGHTING, FALSE);
	pDevice->SetTransform(D3DTS_WORLD, &mtxWorld);
	pDevice->SetFVF(FVF_MESH_FIELD_VERTEX);

	pDevice->SetTexture(0, Texture_GetTexture(GRAND));

	p_collision_num2 = (Player_Pos().z * 4);
	p_collision_num = (Player_Pos().x * 4) + 19998 + (-201 * p_collision_num2);
	e_collision_num2[0] = (Enemy_Pos(1).z * 4);
	e_collision_num[0] = (Enemy_Pos(1).x * 4) + 19998 + (-201 * p_collision_num2);
	e_collision_num2[1] = (Enemy_Pos(2).z * 4);
	e_collision_num[1] = (Enemy_Pos(2).x * 4) + 19998 + (-201 * p_collision_num2);
	e_collision_num2[2] = (Enemy_Pos(3).z * 4);
	e_collision_num[2] = (Enemy_Pos(3).x * 4) + 19998 + (-201 * p_collision_num2);

	MeshFieldVertex *pv;
	// ���_�o�b�t�@�̃��b�N
	g_pVertexBuffer[0]->Lock(0, 0, (void**)&pv, 0);
	for (int i = 0; i < BULLET_MAX; i++)
	{
		if (g_collision_num[i] < 0)
		{
			g_collision_num[i] += 200;
		}
		if (Bullet_Pos(i, 0) != D3DXVECTOR3(0.0f, 0.0f, 0.0f))
		{
			color[0] = 255;
			color[1] = 0;
			color[2] = 0;
			g_collision_num2[i] = (Bullet_Pos(i, 0).z * 4);
			g_collision_num[i] = (Bullet_Pos(i, 0).x * 4) + 19998 + (-201 * g_collision_num2[i]);
			g_Mfield_Filed[g_collision_num[i]].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 2 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
		}
		if (Bullet_Pos(i, 1) != D3DXVECTOR3(0.0f, 0.0f, 0.0f))
		{
			color[0] = 0;
			color[1] = 255;
			color[2] = 0;
			g_collision_num2[i] = (Bullet_Pos(i, 1).z * 4);
			g_collision_num[i] = (Bullet_Pos(i, 1).x * 4) + 19998 + (-201 * g_collision_num2[i]);
			g_Mfield_Filed[g_collision_num[i]].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 2 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
		}
		if (Bullet_Pos(i, 2) != D3DXVECTOR3(0.0f, 0.0f, 0.0f))
		{
			color[0] = 0;
			color[1] = 0;
			color[2] = 255;
			g_collision_num2[i] = (Bullet_Pos(i, 2).z * 4);
			g_collision_num[i] = (Bullet_Pos(i, 2).x * 4) + 19998 + (-201 * g_collision_num2[i]);
			g_Mfield_Filed[g_collision_num[i]].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 2 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
		}
		if (Bullet_Pos(i, 3) != D3DXVECTOR3(0.0f, 0.0f, 0.0f))
		{
			color[0] = 255;
			color[1] = 255;
			color[2] = 0;
			g_collision_num2[i] = (Bullet_Pos(i, 3).z * 4);
			g_collision_num[i] = (Bullet_Pos(i, 3).x * 4) + 19998 + (-201 * g_collision_num2[i]);
			g_Mfield_Filed[g_collision_num[i]].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 1 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
			g_Mfield_Filed[g_collision_num[i] + 2 + MeshFiled_X].color = D3DCOLOR_RGBA(color[0], color[1], color[2], 255);
		}

	}
	for (int i = 0; i < g_VertexCount[0]; i++)
	{
		pv[i] = g_Mfield_Filed[i];
	}
	g_pVertexBuffer[0]->Unlock();

	//�n�ʂƃC���N����v���Ă��邩
	if (Keyboard_IsPress(DIK_DOWN))
	{
		if (g_Mfield_Filed[p_collision_num].color == D3DCOLOR_RGBA(255, 0, 0, 255))
		{
			color_judge = 3;
		}
		else
		{
			color_judge = 0;
		}
	}
	else if (AI_command(1) == Press_DOWN)
	{
		if (g_Mfield_Filed[p_collision_num].color == D3DCOLOR_RGBA(0, 255, 0, 255))
		{
			color_judge = 3;
		}
		else
		{
			color_judge = 0;
		}
	}
	else if (AI_command(2) == Press_DOWN)
	{
		if (g_Mfield_Filed[p_collision_num].color == D3DCOLOR_RGBA(0, 0, 255, 255))
		{
			color_judge = 3;
		}
		else
		{
			color_judge = 0;
		}
	}
	else if (AI_command(3) == Press_DOWN)
	{
		if (g_Mfield_Filed[p_collision_num].color == D3DCOLOR_RGBA(255, 255, 0, 255))
		{
			color_judge = 3;
		}
		else
		{
			color_judge = 0;
		}
	}
	//�I���Ɠ����ɃC���N�̏W�v������
	if (End()&& !ink_count_judge)
	{
		for (int i = 0; i < g_VertexCount[0]; i++)
		{
			if (g_Mfield_Filed[i].color == D3DCOLOR_RGBA(255, 0, 0, 255))
			{
				color_count[0]++;
			}
			if (g_Mfield_Filed[i].color == D3DCOLOR_RGBA(0, 255, 0, 255))
			{
				color_count[1]++;
			}
			if (g_Mfield_Filed[i].color == D3DCOLOR_RGBA(255, 255, 0, 255))
			{
				color_count[3]++;
			}
			if (g_Mfield_Filed[i].color == D3DCOLOR_RGBA(0, 0, 255, 255))
			{
				color_count[2]++;
			}
		}
		ink_count_judge = true;
	}
	pDevice->SetStreamSource(0, g_pVertexBuffer[index], 0, sizeof(MeshFieldVertex));
	pDevice->SetIndices(g_pIndexBuffer[index]);
	pDevice->DrawIndexedPrimitive(D3DPT_TRIANGLESTRIP, 0, 0, g_VertexCount[index], 0, g_PrimitiveCount[index]);
}
void Debug(void)
{
	//DebugFont_Draw(8, 80, "�ԁF%d", color_count[0]);
	//DebugFont_Draw(8, 100, "�΁F%d", color_count[1]);
	//DebugFont_Draw(8, 120, "�F%d", color_count[2]);
	//DebugFont_Draw(8, 140, "���F%d", color_count[3]);
}
int Color_Judge(void)
{
	return color_judge;
}
int Color_cnt(int index)
{
	return color_count[index];
}