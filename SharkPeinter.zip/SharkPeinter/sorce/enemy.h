//=============================================================================
//
// �v���C���[���� [enemy.h]
//
//=============================================================================
#ifndef ENEMY_H_
#define ENEMY_H_
#include "collision.h"
enum {
	Press_W,
	Press_S,
	Press_A,
	Press_D,
	Press_RIGHT,
	Press_LEFT,
	Press_DOWN,
	Press_MAX,
};
typedef struct enemy
{
	D3DXVECTOR3 EnemySpeed;
	D3DXVECTOR3 EnemyPos;
	D3DXVECTOR3 front;
	D3DXVECTOR3 side;
	D3DXVECTOR3 height;
	D3DXMATRIX Trans;
	D3DXMATRIX mtxR;
	D3DXMATRIX Rot;
	D3DXMATRIX mtxR_Enemy;
	SphreCollision Enemy_collision;
	int enemy_life;
	float rot;//�v���C���[�̉�]
	int Frame_Gun_Cnt;//�e�̊Ԋu�t���[��
	float ink;//�C���N�̎c��
	int Swim;//���������̑���
	bool hude_judge;
	int Press_button;
	bool shoot;
}ENEMY;
//------------------------------------
//		�}�N��
//------------------------------------
#define ENEMY_MOVE_SPEED (0.005f)
#define ENEMY_MAX (4)
//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Enemy_Initialize(int charaindex);
void Enemy_Update(int charaindex);
D3DXVECTOR3 Enemy_Pos(int charaindex);
void Enemy_Move_Func(int charaindex);
void Enemy_Gun_Funk(int charaindex);
void Enemy_Draw(int charaindex);
void Gun_Type(int charaindex);
const SphreCollision*Enemy_GetCircleCollision(int charaindex);
void Enemy_Life(int damege, int charaindex);
void Enemy_Dead(int charaindex);
int AI_command(int charaindex);
bool AI_Shoot(int charaindex);
bool Hude_Judge2(int charaindex);
#endif //Enemy_H_