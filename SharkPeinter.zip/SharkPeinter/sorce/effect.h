#ifndef EFFECT_H
#define EFFECT_H

#define EFFECT2_MAX (50)

#include <d3dx9.h>

void Effect2_Initialize(void);
void Effect2_Finalize(void);
void Effect2_Update(void);
void Effect2_Draw(void);
void Effect2_Create(D3DXVECTOR3 Position);
void Effect2_Destroy(int index);
bool Effect2(int index);



#endif
