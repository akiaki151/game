/*================================================================

�J�����֐�[camera.cpp]
Author : Akihiro Makino
Date   : 2018/10/03
------------------------------------------------------------------
================================================================*/
#include<d3dx9.h>
#include"mydirect.h"
#include"common.h"
#include"input.h"
#include"camera.h"
#include"debug_font.h"
#include"Player.h"
#include"judgement.h"
/*------------------------------------------------------------------------------
   �O���[�o���ϐ��錾
------------------------------------------------------------------------------*/
static D3DXVECTOR3 g_Camera_Eye;
static D3DXVECTOR3 g_Camera_Up;
static D3DXVECTOR3 g_Camera_At;
static D3DXVECTOR3 flont;
static D3DXVECTOR3 right;
static D3DXVECTOR3 up;
static D3DXMATRIX mtxView;
static D3DXMATRIX mtxProjection;
static float lenght;//at�܂ł̋���
// �Q�[���̏�����
void Camera_Initilize(void)
{
	g_Camera_Eye = D3DXVECTOR3(0.0f, 3.0f, -6.0f);//eye �J�������W
	g_Camera_Up = D3DXVECTOR3(0.0f, 1.0f, 0.0f);//up  �J�����̏�����x�N�g��
	g_Camera_At = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	flont = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	D3DXVec3Normalize(&flont, &flont);
	lenght = 6.0f;
	up = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXVec3Cross(&right, &up, &flont);
	D3DXVec3Normalize(&right, &right);
	D3DXVec3Cross(&up, &flont, &right);
	D3DXVec3Normalize(&up, &up);
}
// �Q�[���̍X�V
void Camera_Updata(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	g_Camera_At = (flont * lenght) + g_Camera_Eye;
	D3DXMatrixLookAtLH(&mtxView, &g_Camera_Eye, &g_Camera_At, &up);
	D3DXMatrixPerspectiveFovLH(&mtxProjection, D3DXToRadian(60), (float)SCREEN_WIDTH / SCREEN_HEIGHT, 0.1f, 300.0f);
	pDevice->SetTransform(D3DTS_VIEW, &mtxView);
	pDevice->SetTransform(D3DTS_PROJECTION, &mtxProjection);
	flont=MTXR_FROANT();
	g_Camera_Eye = Player_Pos() + D3DXVECTOR3(0.0f, 3.0f, 0.0f) - flont * lenght;
	if (End())
	{
		g_Camera_Eye = D3DXVECTOR3(0.0f, 10.0f, -45.0f);//eye �J�������W
		flont = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	}
}
void Draw_Camera(void)
{
}
D3DXMATRIX MtxView2(void)
{
	return mtxView;
}