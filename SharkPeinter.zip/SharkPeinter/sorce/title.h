//=============================================================================
//
// �^�C�g���\������ [title.h]
//
//=============================================================================
#ifndef TITLE_H_
#define TITLE_H_

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Title_Initialize(void);
void Title_Finalize(void);
void Title_Update(void);
void Title_Draw(void);
int Title_Select(void);
int Buki_Select(int index);
#endif //!TITLE_H_

