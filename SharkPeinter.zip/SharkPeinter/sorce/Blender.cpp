/*================================================================

���f��[blender.cpp]
Author : Akihiro Makino
------------------------------------------------------------------
================================================================*/
#include"mydirect.h"
#include"Blender.h"
#include<d3dx9.h>
#include"input.h"
#include"camera.h"
#include"debug_font.h"
#include"Player.h"
#include"bullet.h"
#include"enemy.h"
#define FRAME_X		(2)
#define FRAME_Y		(10)
#define FRAME_MAX	(19)
#define PARTS_ROT	(18)
#define LEG_ROT		(4.5)
//---------------------------------------------------------------------------
//		�O���[�o���ϐ�
//---------------------------------------------------------------------------
LPD3DXMESH pD3DXMesh[MATERIAL_INDEX_MAX];	//���b�V�����󂯎��ϐ�
DWORD n[MATERIAL_INDEX_MAX];//�}�e���A����
HRESULT hr;
LPDIRECT3DTEXTURE9 *g_pTexture[MATERIAL_INDEX_MAX];//�e�N�X�`��
D3DMATERIAL9 *g_pMaterials[4][MATERIAL_INDEX_MAX];//�}�e���A��
LPD3DXBUFFER MaterialBuffer[4][MATERIAL_INDEX_MAX];//�}�e���A�������󂯎��ϐ�
static float rot[4] = { 0 };
int Frame_Cnt[4] = { 0 };
int Frame[4] = { 0 };
int Frame2[4] = { 0 };
bool Judge[4] = { false };
// �ǂݍ��݃e�N�X�`�����
static const  ModelFile fileData[] = {
	{ "model/head_red.x" },				//HEAD,
	{ "model/body_red.x" },				// BODY		
	{ "model/rightleg1_red.x" },			//RIGHTLEG1
	{ "model/rightleg2_red.x" },			//RIGHTLEG2
	{ "model/rightleg3_red.x" },			//RIGHTLEG3
	{ "model/leftleg1_red.x" },			//LEFTLEG1
	{ "model/leftleg2_red.x" },			//LEFTLEG2
	{ "model/leftleg22_red.x" },			//LEFTLEG22
	{ "model/leftleg3_red.x" },			//LEFTLEG
	{ "model/lefthand1_red.x" },			//LEFTHAND1
	{ "model/lefthand2_red.x" },			//LEFTHAND2
	{ "model/lefthand3_red.x" },			//LEFTHAND3
	{ "model/righthand1_red.x" },		//RIGHTHAND 1
	{ "model/righthand2_red.x" },		//RIGHTHAND2
	{ "model/righthand3_red.x" },		//RIGHTHAND3
	{ "model/handcube1_red.x" },		//RIGHTHANDCUBE1
	{ "model/handcube2_red.x" },		//RIGHTHANDCUBE2
	{ "model/handcube3_red.x" },		//RIGHTHANDCUBE4
	{ "model/legcube1.x" },				 //LEGCUBE1
	{ "model/legcube2.x" },				 //LEGCUBE2
	{ "model/legcube3.x" },				 //LEGCUBE3
	{ "model/leg_kotei.x" },
	{ "model/hand_kotei.x" },
	{ "model/chagerhand.x" },
	{ "model/paburo_hand1.x" },
	{ "model/paburo_hand2.x" },
	{ "model/same.blend.x" },
	{ "model/bullet_gun.x" },
	{ "model/rolllerblend1.x" },
	{ "model/splattershot.blend1.x" },
	{ "model/siper.blend1.x" },
	{ "model/paburo.x" },
};
void Model_XFile(int index,int charaindex)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	//������������index��߂��֐��ɂ���
	hr = D3DXLoadMeshFromX
	(
		fileData[index].filename,
		D3DXMESH_MANAGED | D3DXMESH_32BIT,// | D3DXMESH_WRITEONLY
		pDevice,
		NULL,
		&MaterialBuffer[charaindex][index],
		NULL,
		&n[index],
		&pD3DXMesh[index]
	);
	g_pMaterials[charaindex][index] = new D3DMATERIAL9[/*�}�e���A����*/n[index]];//�����[�X���Adelet[�}�e���A����]
	g_pTexture[index] = new LPDIRECT3DTEXTURE9[/*�}�e���A����*/n[index]];
	//�}�e���A�����o�b�t�@�̃|�C���g�擾
	D3DXMATERIAL *Get_Materials = (D3DXMATERIAL*)MaterialBuffer[charaindex][index]->GetBufferPointer();
	//�e�}�e���A������ۑ�
	for (int i = 0; i < n[index]; i++)
	{
		if (index >= SAME&& index < ROLLER_WEAPON&&charaindex==0)
		{
			g_pMaterials[charaindex][index][i] = Get_Materials[i].MatD3D;
			g_pMaterials[charaindex][index][i].Ambient = D3DCOLORVALUE{ 255,1,1,100 };
		}
		else if(index < ROLLER_WEAPON&&charaindex == 1)
		{
			g_pMaterials[charaindex][index][i] = Get_Materials[i].MatD3D;
			g_pMaterials[charaindex][index][i].Ambient = D3DCOLORVALUE{ 1,255,1,100 };
		}
		else if (index < ROLLER_WEAPON&&charaindex == 2)
		{
			g_pMaterials[charaindex][index][i] = Get_Materials[i].MatD3D;
			g_pMaterials[charaindex][index][i].Ambient = D3DCOLORVALUE{ 1,1,255,100 };
		}
		else if (index < ROLLER_WEAPON&&charaindex == 3)
		{
			g_pMaterials[charaindex][index][i] = Get_Materials[i].MatD3D;
			g_pMaterials[charaindex][index][i].Ambient = D3DCOLORVALUE{ 255,255,0,100 };
		}
		else
		{
			g_pMaterials[charaindex][index][i] = Get_Materials[i].MatD3D;//x�t�@�C���̃}�e���A���̃J���[�̃R�s�[�A�}�e���A���̃f�B�t���[�Y��light.cpp�̃f�B�t���[�Y�͏�Z�����A�A���r�G���g������
			g_pMaterials[charaindex][index][i].Ambient = g_pMaterials[charaindex][index][i].Diffuse;
		}
		//�e�N�X�`���̓ǂݍ���
		if (Get_Materials[i].pTextureFilename == NULL)//�e�N�X�`�����Ȃ��}�e���A���̓t�@�C�����Ȃ�
			g_pTexture[index][i] = NULL;//�e�N�X�`���Ȃ�
		else
		{
			hr = D3DXCreateTextureFromFile
			(
				pDevice,
				Get_Materials[i].pTextureFilename,
				&g_pTexture[index][i]
			);
		}
		if (FAILED(hr))
		{
			g_pTexture[i] = NULL;//�e�N�X�`���Ȃ�
			MessageBox(NULL, "�}�e���A�����ǂݍ��܂�ĂȂ���", "�G���[", MB_OK);
		}
	}
	if (MaterialBuffer)
	{
		MaterialBuffer[charaindex][index]->Release();
	}
	for (int i = 0; i < 4; i++)
	{
		rot[i] = { 0 };
		Frame_Cnt[i] = { 0 };
		Frame[i] = { 0 };
		Frame2[i] = { 0 };
		Judge[i] = { false };
	}
}
void Model_Draw(int index, D3DXMATRIX Warld, int charaindex)
{
	//X�t�@�C���̕`��
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	pDevice->SetRenderState(D3DRS_LIGHTING, TRUE);
	pDevice->SetRenderState(D3DRS_DIFFUSEMATERIALSOURCE, D3DMCS_MATERIAL);
	pDevice->SetRenderState(D3DRS_AMBIENTMATERIALSOURCE, D3DMCS_MATERIAL);
	pDevice->SetTransform(D3DTS_WORLD, &Warld);
	//���[���h�ϊ��s��
	for (int i = 0; i < n[index]; i++)
	{
		pDevice->SetMaterial(&g_pMaterials[charaindex][index][i]);
		pDevice->SetTexture(0, g_pTexture[index][i]);
		pD3DXMesh[index]->DrawSubset(i);
	}
}
void Model_Update(int charaindex)
{

	if (Keyboard_IsPress(DIK_W)) {
		Frame_Cnt[charaindex]++;
	}
	else if (Keyboard_IsPress(DIK_D))
	{
		Frame_Cnt[charaindex]++;
	}
	else if (Keyboard_IsPress(DIK_A))
	{
		Frame_Cnt[charaindex]++;
	}
	else if (Keyboard_IsPress(DIK_S))
	{
		Frame_Cnt[charaindex]++;
	}
	else if (Keyboard_IsPress(DIK_SPACE))
	{
		Frame_Cnt[charaindex]++;
	}

	else {
		Frame_Cnt[charaindex] = 0;
	}


	if (Frame_Cnt[charaindex] > FRAME_MAX)
	{
		Frame_Cnt[charaindex] = 0;

		if (Judge)
		{
			Judge[charaindex] = false;
		}
		else if (!Judge)
		{
			Judge[charaindex] = true;
		}
	}

}
void Model_Finalize(int index)
{
	//���f���f�[�^�̉��
	delete[]g_pMaterials[0][index];
	delete[]g_pMaterials[1][index];
	delete[]g_pMaterials[2][index];
	delete[]g_pMaterials[3][index];
	delete[]g_pTexture[index];
	pD3DXMesh[index]->Release();

}
void Model_Assemble(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex)
{
	if (charaindex == 0)
	{
		Player_Move(P_Trans, P_Rot, charaindex);
	}
	else if (charaindex != 0)
	{
		Enemy_Move(P_Trans, P_Rot, charaindex);
	}
}
void Model_Assemble_Machine(float x, float y, float z, D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, D3DXMATRIX P_Rotation, int index,int charaindex)
{
	D3DXMATRIX Warld[4];
	D3DXMATRIX Trans[4];
	D3DXMATRIX rotation[4];

	D3DXMatrixIdentity(&Warld[charaindex]);
	D3DXMatrixIdentity(&Trans[charaindex]);
	D3DXMatrixIdentity(&rotation[charaindex]);

	D3DXMatrixRotationY(&rotation[charaindex], D3DXToRadian(180));
	D3DXMatrixMultiply(&Warld[charaindex], &Warld[charaindex], &rotation[charaindex]);
	D3DXMatrixTranslation(&Trans[charaindex], x, y, z);
	D3DXMatrixMultiply(&Warld[charaindex], &Warld[charaindex], &P_Rotation);
	D3DXMatrixMultiply(&Warld[charaindex], &Warld[charaindex], &Trans[charaindex]);
	D3DXMatrixMultiply(&Warld[charaindex], &Warld[charaindex], &P_Rot);
	D3DXMatrixMultiply(&Warld[charaindex], &Warld[charaindex], &P_Trans);
	Model_Draw(index, Warld[charaindex], charaindex);
}
void Walk_Hand(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, float x2,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX rot2[4];
	D3DXMATRIX trans3[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX trans4[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);


	//�E�茋����
	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE1, charaindex);

	//�E�茨
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90 - (PARTS_ROT* Frame[charaindex])));
	Model_Assemble_Machine(x, 0.96f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTHAND1, charaindex);			//�`��

	//������
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//���Ɠ�̘r�̌�����
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.25f, 0.0f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(260 - (PARTS_ROT * Frame[charaindex])));		//���̈ړ�
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	
	//������
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//�E���̘r
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.25f, 0.0f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(270 - (PARTS_ROT * Frame[charaindex])));		//��̘r�̈ړ���
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90));							//��̘r��90�ǉ�]
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);

	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND2,charaindex);		//�`��

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);


	//���Ǝ�̌�����
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.38f, 0.0f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(220 - (PARTS_ROT * Frame[charaindex])));		//��̘r�̈ړ���
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90));							//��̘r��90�x��]
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans4[charaindex]);

	//������
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//�E���
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.38f, 0.0f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(220 - (PARTS_ROT * Frame[charaindex])));		//��̘r�̈ړ���
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90));							//��̘r��90�x��]
	D3DXMatrixRotationZ(&trans4[charaindex], D3DXToRadian(90));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans4[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);

	Model_Assemble_Machine(x2, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND3, charaindex);
}
void Walk_Hand_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, float x2,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX rot2[4];
	D3DXMATRIX trans3[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX trans4[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//�E�茋����
	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE1, charaindex);

	//�E�茨
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(-90 + (PARTS_ROT* Frame[charaindex])));
	Model_Assemble_Machine(x, 0.96f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTHAND1, charaindex);			//�`��

																						//������
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//���Ɠ�̘r�̌�����
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.25f, -0.1f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-260 + (PARTS_ROT * Frame[charaindex])));		//���̈ړ�
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE2, charaindex);		//�`��

	//������
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//�E���̘r
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.25f, 0.0f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-270 + (PARTS_ROT * Frame[charaindex])));		//��̘r�̈ړ���
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90));							//��̘r��90�ǉ�]
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);

	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND2, charaindex);		//�`��

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//���Ǝ�̌�����
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.38f, 0.0f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-320 + (PARTS_ROT * Frame[charaindex])));		//��̘r�̈ړ���
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90));							//��̘r��90�x��]
																			//D3DXMatrixTranslation(&trans4, 0.0f, 0.4f, 0.2f);
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);
	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE3, charaindex);

	//������
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//�E���
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.38f, 0.3f);						//�������Ɉړ�
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-360 + (PARTS_ROT * Frame[charaindex])));		//��̘r�̈ړ���
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90));							//��̘r��90�x��]
	D3DXMatrixRotationZ(&trans4[charaindex], D3DXToRadian(90));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans4[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);

	Model_Assemble_Machine(x2, 1.0f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND3, charaindex);
}
void Walk_Leg(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x,int charaindex)
{

	D3DXMATRIX rot[4];
	D3DXMATRIX rot2[4];
	D3DXMATRIX trans3[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX trans4[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	//��������
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(-LEG_ROT * Frame[charaindex]));
	Model_Assemble_Machine(x, 0.6f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG1, charaindex);
	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);
	//�ӂƂ����ӂ���͂�������
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(90 - ((LEG_ROT + 5)* Frame[charaindex])));
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.0f, 0.1f);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	Model_Assemble_Machine(x, 0.45f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEGCUBE2, charaindex);

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);
	//�ӂ���͂�
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian(((LEG_ROT + 5)* Frame[charaindex])));
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.03f, 0.03f);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.4f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEFTLEG2, charaindex);

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&trans3[charaindex]);
	D3DXMatrixIdentity(&trans4[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);
	D3DXMatrixRotationX(&rot[charaindex], D3DXToRadian((LEG_ROT)* Frame[charaindex]));
	D3DXMatrixTranslation(&trans3[charaindex], 0.0f, 0.0f, 0.03f);
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(((LEG_ROT + 10)* Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &trans3[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.4f, -0.1f, P_Trans, P_Rot, mtx[charaindex], RIGHTLEG3, charaindex);
}
void Walk_Leg_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x,int charaindex)
{
	D3DXMATRIX mtx[4];
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationX(&mtx[charaindex], D3DXToRadian(-3 * Frame[charaindex]));

	//�E��
	Model_Assemble_Machine(x, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEG_KOTEI, charaindex);

}
void Walk_Leg_Side(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(rotation));
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(90 - (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	Model_Assemble_Machine(x, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEG_KOTEI, charaindex);							//�`��	
}
void Walk_Leg_Side_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(rotation));
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-90 + (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	Model_Assemble_Machine(x, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEG_KOTEI, charaindex);							//�`��	
}
void Walk_Hand_Side(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation, float z,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(rotation));
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(90 - (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	Model_Assemble_Machine(x, 0.98f, z, P_Trans, P_Rot, mtx[charaindex], HAND_KOTEI, charaindex);							//�`��	
}
void Walk_Hand_Side_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation, float z,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot[charaindex]);
	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(rotation));
	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-90 + (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot[charaindex]);
	Model_Assemble_Machine(x, 0.98f, z, P_Trans, P_Rot, mtx[charaindex], HAND_KOTEI, charaindex);							//�`��	
}
void Walk_Leg_Back_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x,int charaindex)
{
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-90 + (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEG_KOTEI, charaindex);							//�`��	
}
void Walk_Leg_Back_Back_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x,int charaindex)
{
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(90 - (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], LEG_KOTEI, charaindex);							//�`��	
}
void Walk_Hand_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x,int charaindex)
{
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(90 - (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], HAND_KOTEI, charaindex);							//�`��	
}
void Walk_Hand_Back_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x,int charaindex)
{
	D3DXMATRIX mtx[4];
	D3DXMATRIX rot2[4];

	D3DXMatrixIdentity(&rot2[charaindex]);
	D3DXMatrixIdentity(&mtx[charaindex]);

	D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-90 + (18 * Frame[charaindex])));
	D3DXMatrixMultiply(&mtx[charaindex], &mtx[charaindex], &rot2[charaindex]);
	Model_Assemble_Machine(x, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], HAND_KOTEI, charaindex);							//�`��	
}
void Weapon_Motion(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot ,int charaindex)
{
	D3DXMATRIX rot[4];
	D3DXMATRIX rot2[4];
	D3DXMATRIX trans3[4];
	D3DXMATRIX mtx[4];
	D3DXMATRIX trans4[4];

	switch (GunType(charaindex))
	{
	case SHOOTER:
		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);

		D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-75));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
		D3DXMatrixRotationZ(&trans3[charaindex], D3DXToRadian(-30));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
		Model_Assemble_Machine(0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], HAND_KOTEI, charaindex);

		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);

		//����`��
		D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-75));			//X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX
		D3DXMatrixRotationZ(&trans3[charaindex], D3DXToRadian(30));			//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
		Model_Assemble_Machine(-0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], HAND_KOTEI, charaindex);

		break;
	case SNIPER:
		//�E��`��
		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);

		D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-70));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
		//D3DXMatrixRotationY(&trans3, D3DXToRadian(90));	//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
		Model_Assemble_Machine(0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], CHAGER_HAND, charaindex);

		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);

		///����`��
		D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-90));			//X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX
		D3DXMatrixRotationY(&trans3[charaindex], D3DXToRadian(40));			//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
		Model_Assemble_Machine(-0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], HAND_KOTEI, charaindex);
		break;
	case HUDE:
		if (Hude_Judge2(charaindex)|| Hude_Judge())
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-50));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
			D3DXMatrixRotationY(&trans3[charaindex], D3DXToRadian(-40));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND1,charaindex);

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-10));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
			D3DXMatrixRotationZ(&trans3[charaindex], D3DXToRadian(60));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(0.1f, 0.98f, 0.25f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND2, charaindex);

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			///����`��
			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-30));			//X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX
			D3DXMatrixRotationY(&trans3[charaindex], D3DXToRadian(0));			//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(-0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND1, charaindex);

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-30));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
			//D3DXMatrixRotationY(&trans3, D3DXToRadian(-80));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(-0.28f, 0.88f, 0.3f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND2, charaindex);

		}
		else
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-30));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
			//D3DXMatrixRotationY(&trans3, D3DXToRadian(-40));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND1, charaindex);

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-30));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
			//D3DXMatrixRotationZ(&trans3, D3DXToRadian(60));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(0.28f, 0.88f, 0.3f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND2, charaindex);

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			//����`��
			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-50));			//X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX
			D3DXMatrixRotationY(&trans3[charaindex], D3DXToRadian(40));			//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(-0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND1, charaindex);

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);

			D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(10));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
			D3DXMatrixRotationY(&trans3[charaindex], D3DXToRadian(60));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
			D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
			Model_Assemble_Machine(-0.1f, 0.98f, 0.25f, P_Trans, P_Rot, rot[charaindex], PABURO_HAND2, charaindex);
		}
		break;
	case ROLLER:
		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);

		D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-35));		//�r��X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX(40~50����������)
		D3DXMatrixRotationZ(&trans3[charaindex], D3DXToRadian(-30));		//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
		Model_Assemble_Machine(0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], HAND_KOTEI, charaindex);

		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);

		//����`��
		D3DXMatrixRotationX(&rot2[charaindex], D3DXToRadian(-35));			//X�������̊p�x(�v���C���[�̘r�̏グ����)	�V���[�^�[�ɂ���ꍇ�����ύX
		D3DXMatrixRotationZ(&trans3[charaindex], D3DXToRadian(30));			//�r���v���C���[�̒��S�ɌX����(���킪���S�̏ꍇ�����̕ύX���Ȃ��Ă悫)
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &rot2[charaindex]);
		D3DXMatrixMultiply(&rot[charaindex], &rot[charaindex], &trans3[charaindex]);
		Model_Assemble_Machine(-0.28f, 0.98f, 0.0f, P_Trans, P_Rot, rot[charaindex], HAND_KOTEI, charaindex);
		break;
	default:
		break;
	}
}
void Player_Move(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex)
{
	if (!Keyboard_IsPress(DIK_DOWN))
	{
		D3DXMATRIX rot[4];
		D3DXMATRIX rot2[4];
		D3DXMATRIX trans3[4];
		D3DXMATRIX mtx[4];
		D3DXMATRIX trans4[4];
		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);
		Frame[charaindex] = (Frame_Cnt[charaindex] / FRAME_X) % FRAME_Y;
		///////////////////////////////////////////////////����///////////////////////////////////////////////////////////////////
		if (Keyboard_IsPress(DIK_W) && !Keyboard_IsPress(DIK_SPACE)) {
			//��
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);//�`��
			if (Judge[charaindex])
			{
				Walk_Hand(P_Trans, P_Rot, 0.28, 0.2, charaindex);
				Walk_Hand_Back(P_Trans, P_Rot, -0.28, -0.35, charaindex);
				Walk_Leg(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);
			}
			else if (!Judge[charaindex])
			{
				Walk_Hand_Back(P_Trans, P_Rot, 0.28, 0.2, charaindex);
				Walk_Hand(P_Trans, P_Rot, -0.28, -0.35, charaindex);
				Walk_Leg(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
			}
		}
		else if (Keyboard_IsPress(DIK_W) && Keyboard_IsPress(DIK_SPACE))
		{
			//��
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);//�`��
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge[charaindex])
			{
				Walk_Leg(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);

			}
			else if (!Judge[charaindex])
			{
				Walk_Leg(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
			}
		}
		///////////////////////////////////////////////////�E������///////////////////////////////////////////////////////////////////
		else if (Keyboard_IsPress(DIK_D) && !Keyboard_IsPress(DIK_SPACE)) {

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			if (Judge[charaindex])
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, 30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, -0.28, 30, 0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, 0.28, 30, -0.15f, charaindex);
			}
			else if (!Judge[charaindex])
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, 30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, 0.28, 30, -0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, -0.28, 30, 0.15f, charaindex);
			}
		}
		else if (Keyboard_IsPress(DIK_D) && Keyboard_IsPress(DIK_SPACE))
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, 30, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, 30, charaindex);
			}
		}
		///////////////////////////////////////////////////��������//////////////////////////////////////////////////////////////////
		else if (Keyboard_IsPress(DIK_A) && !Keyboard_IsPress(DIK_SPACE)) {

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(-30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			if (Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, -30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, -0.28, -30, -0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, 0.28, -30, 0.15f, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, -30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, 0.28, -30, 0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, -0.28, -30, -0.15f, charaindex);
			}
		}
		else if (Keyboard_IsPress(DIK_A) && Keyboard_IsPress(DIK_SPACE))
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(-30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, -30, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, -30, charaindex);
			}
		}
		///////////////////////////////////////////////////��둤//////////////////////////////////////////////////////////////////
		else if (Keyboard_IsPress(DIK_S) && !Keyboard_IsPress(DIK_SPACE)) {

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			if (Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Hand_Back(P_Trans, P_Rot, 0.28, charaindex);
				Walk_Hand_Back_Back(P_Trans, P_Rot, -0.28, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Hand_Back(P_Trans, P_Rot, -0.28, charaindex);
				Walk_Hand_Back_Back(P_Trans, P_Rot, 0.28, charaindex);
			}
		}
		else if (Keyboard_IsPress(DIK_S) && Keyboard_IsPress(DIK_SPACE)) {
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, -0.09, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, 0.09, charaindex);
			}
		}
		////////////////////////////////////�����~�܂�////////////////////////////////////////////////
		else if (!Keyboard_IsPress(DIK_SPACE))
		{
			//��
			//Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, HEAD);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��																							//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��																		//�E��
			Model_Assemble_Machine(0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG1, charaindex);
			Model_Assemble_Machine(0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG2, charaindex);
			Model_Assemble_Machine(0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG3, charaindex);
			//����
			Model_Assemble_Machine(-0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG1, charaindex);
			Model_Assemble_Machine(-0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], LEFTLEG3, charaindex);
			//����������
			Model_Assemble_Machine(0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);
			//����������
			Model_Assemble_Machine(-0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(-0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);
			//�E��
			Model_Assemble_Machine(0.28, 0.96f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTHAND1, charaindex);			//�`��
			Model_Assemble_Machine(0.28, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE1, charaindex);		//�`��
			Model_Assemble_Machine(0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND2, charaindex);
			Model_Assemble_Machine(0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE3, charaindex);
			Model_Assemble_Machine(0.28, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND3, charaindex);

			Model_Assemble_Machine(-0.28, 0.96f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTHAND1, charaindex);			//�`��
			Model_Assemble_Machine(-0.28, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE1, charaindex);		//�`��
			Model_Assemble_Machine(-0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND2, charaindex);
			Model_Assemble_Machine(-0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE3, charaindex);
			Model_Assemble_Machine(-0.28, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND3, charaindex);
		}
		else if (Keyboard_IsPress(DIK_SPACE))
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);			//�`��

																										//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);						//�`��

																										//�E��
			Model_Assemble_Machine(0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG1, charaindex);
			Model_Assemble_Machine(0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG2, charaindex);
			Model_Assemble_Machine(0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG3, charaindex);

			//����
			Model_Assemble_Machine(-0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG1, charaindex);
			Model_Assemble_Machine(-0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], LEFTLEG3, charaindex);

			//����������
			Model_Assemble_Machine(0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);

			//����������
			Model_Assemble_Machine(-0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(-0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);
			Weapon_Motion(P_Trans, P_Rot, charaindex);
		}
	}
}
void Enemy_Move(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex)
{
	if (AI_command(charaindex)!=Press_DOWN)
	{
		D3DXMATRIX rot[4];
		D3DXMATRIX rot2[4];
		D3DXMATRIX trans3[4];
		D3DXMATRIX mtx[4];
		D3DXMATRIX trans4[4];
		D3DXMatrixIdentity(&rot[charaindex]);
		D3DXMatrixIdentity(&rot2[charaindex]);
		D3DXMatrixIdentity(&trans3[charaindex]);
		D3DXMatrixIdentity(&trans4[charaindex]);
		D3DXMatrixIdentity(&mtx[charaindex]);
		Frame[charaindex] = (Frame_Cnt[charaindex] / FRAME_X) % FRAME_Y;
		///////////////////////////////////////////////////����///////////////////////////////////////////////////////////////////
		if (AI_command(charaindex)==Press_W && !AI_Shoot(charaindex)) {
			//��
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);//�`��
			if (Judge[charaindex])
			{
				Walk_Hand(P_Trans, P_Rot, 0.28, 0.2, charaindex);
				Walk_Hand_Back(P_Trans, P_Rot, -0.28, -0.35, charaindex);
				Walk_Leg(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);
			}
			else if (!Judge[charaindex])
			{
				Walk_Hand_Back(P_Trans, P_Rot, 0.28, 0.2, charaindex);
				Walk_Hand(P_Trans, P_Rot, -0.28, -0.35, charaindex);
				Walk_Leg(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
			}
		}
		else if (AI_command(charaindex) == Press_W && AI_Shoot(charaindex))
		{
			//��
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);//�`��
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge[charaindex])
			{
				Walk_Leg(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);

			}
			else if (!Judge[charaindex])
			{
				Walk_Leg(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
			}
		}
		///////////////////////////////////////////////////�E������///////////////////////////////////////////////////////////////////
		else if (AI_command(charaindex) == Press_D && !AI_Shoot(charaindex)) {

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			if (Judge[charaindex])
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, 30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, -0.28, 30, 0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, 0.28, 30, -0.15f, charaindex);
			}
			else if (!Judge[charaindex])
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, 30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, 0.28, 30, -0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, -0.28, 30, 0.15f, charaindex);
			}
		}
		else if (AI_command(charaindex) == Press_D&& AI_Shoot(charaindex))
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, 30, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, 30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, 30, charaindex);
			}
		}
		///////////////////////////////////////////////////��������//////////////////////////////////////////////////////////////////
		else if (AI_command(charaindex) == Press_A && !AI_Shoot(charaindex)) {

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(-30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			if (Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, -30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, -0.28, -30, -0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, 0.28, -30, 0.15f, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, -30, charaindex);
				Walk_Hand_Side(P_Trans, P_Rot, 0.28, -30, 0.15f, charaindex);
				Walk_Hand_Side_Back(P_Trans, P_Rot, -0.28, -30, -0.15f, charaindex);
			}
		}
		else if (AI_command(charaindex) == Press_A && AI_Shoot(charaindex))
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			D3DXMatrixRotationY(&rot[charaindex], D3DXToRadian(-30));
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, 0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, -0.09, -30, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Side(P_Trans, P_Rot, -0.09, -30, charaindex);
				Walk_Leg_Side_Back(P_Trans, P_Rot, 0.09, -30, charaindex);
			}
		}
		///////////////////////////////////////////////////��둤//////////////////////////////////////////////////////////////////
		else if (AI_command(charaindex) == Press_S && !AI_Shoot(charaindex)) {

			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			if (Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Hand_Back(P_Trans, P_Rot, 0.28, charaindex);
				Walk_Hand_Back_Back(P_Trans, P_Rot, -0.28, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Hand_Back(P_Trans, P_Rot, -0.28, charaindex);
				Walk_Hand_Back_Back(P_Trans, P_Rot, 0.28, charaindex);
			}
		}
		else if (AI_command(charaindex) == Press_S && AI_Shoot(charaindex)) {
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��
			//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��
			Weapon_Motion(P_Trans, P_Rot, charaindex);
			if (Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, 0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, -0.09, charaindex);
			}
			else if (!Judge)
			{
				Walk_Leg_Back(P_Trans, P_Rot, -0.09, charaindex);
				Walk_Leg_Back_Back(P_Trans, P_Rot, 0.09, charaindex);
			}
		}
		////////////////////////////////////�����~�܂�////////////////////////////////////////////////
		else if (!AI_Shoot(charaindex))
		{
			//��
			//Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, HEAD);
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);						//�`��																							//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);							//�`��																		//�E��
			Model_Assemble_Machine(0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG1, charaindex);
			Model_Assemble_Machine(0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG2, charaindex);
			Model_Assemble_Machine(0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG3, charaindex);
			//����
			Model_Assemble_Machine(-0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG1, charaindex);
			Model_Assemble_Machine(-0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], LEFTLEG3, charaindex);
			//����������
			Model_Assemble_Machine(0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);
			//����������
			Model_Assemble_Machine(-0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(-0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);
			//�E��
			Model_Assemble_Machine(0.28, 0.96f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTHAND1, charaindex);			//�`��
			Model_Assemble_Machine(0.28, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE1, charaindex);		//�`��
			Model_Assemble_Machine(0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND2, charaindex);
			Model_Assemble_Machine(0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE3, charaindex);
			Model_Assemble_Machine(0.28, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND3, charaindex);

			Model_Assemble_Machine(-0.28, 0.96f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTHAND1, charaindex);			//�`��
			Model_Assemble_Machine(-0.28, 0.98f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE1, charaindex);		//�`��
			Model_Assemble_Machine(-0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND2, charaindex);
			Model_Assemble_Machine(-0.28, 0.7f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHANDCUBE3, charaindex);
			Model_Assemble_Machine(-0.28, 0.5f, 0.0f, P_Trans, P_Rot, mtx[charaindex], RIGHTHAND3, charaindex);
		}
		else if (AI_Shoot(charaindex))
		{
			D3DXMatrixIdentity(&rot[charaindex]);
			D3DXMatrixIdentity(&rot2[charaindex]);
			D3DXMatrixIdentity(&trans3[charaindex]);
			D3DXMatrixIdentity(&trans4[charaindex]);
			D3DXMatrixIdentity(&mtx[charaindex]);
			//��
			Model_Assemble_Machine(0.0f, 1.1f, 0.0f, P_Trans, P_Rot, rot[charaindex], HEAD, charaindex);			//�`��

																										//��
			Model_Assemble_Machine(0.0f, 0.8f, 0.0f, P_Trans, P_Rot, rot[charaindex], BODY, charaindex);						//�`��

																										//�E��
			Model_Assemble_Machine(0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG1, charaindex);
			Model_Assemble_Machine(0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG2, charaindex);
			Model_Assemble_Machine(0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], RIGHTLEG3, charaindex);

			//����
			Model_Assemble_Machine(-0.09f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG1, charaindex);
			Model_Assemble_Machine(-0.09f, 0.3f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEFTLEG2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.2f, -0.1f, P_Trans, P_Rot, rot[charaindex], LEFTLEG3, charaindex);

			//����������
			Model_Assemble_Machine(0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);

			//����������
			Model_Assemble_Machine(-0.08f, 0.5f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE1, charaindex);
			Model_Assemble_Machine(-0.097f, 0.25f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE2, charaindex);
			Model_Assemble_Machine(-0.09f, 0.15f, 0.0f, P_Trans, P_Rot, rot[charaindex], LEGCUBE3, charaindex);
			Weapon_Motion(P_Trans, P_Rot, charaindex);
		}
	}
}