/*================================================================
�J����[camera.h]
------------------------------------------------------------------
================================================================*/
#ifndef CAMERA_H_
#define CAMERA_H_
#include<d3dx9.h>
void Camera_Initilize(void);
void Camera_Updata(void);
void Draw_Camera(void);
D3DXMATRIX MtxView2(void);
#endif // !CAMERA_H_

