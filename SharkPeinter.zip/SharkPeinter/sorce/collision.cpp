#include <d3dx9.h>
#include "collision.h"

bool HitSphereCollision(const SphreCollision *pA, const SphreCollision *pB)//�����Ƒ���̋�
{
	return (pA->radius + pB->radius)*(pA->radius + pB->radius) > D3DXVec3LengthSq(&(pA->position - pB->position));
}

