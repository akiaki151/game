//=============================================================================
//
// �����蔻�菈�� [judgement.h]
//
//=============================================================================
/*------------------------------------
//	�C���N���[�h�t�@�C��
------------------------------------*/
#include"judgement.h"
#include"collision.h"
#include"player.h"
#include"enemy.h"
#include"bullet.h"
#include"debug_font.h"
#include<time.h>
#include"fade.h"
#include"scene.h"
#include"effect.h"
#include"number.h"
#include"score.h"
#include"common.h"
#include"texture.h"
#include"sprite.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
const int time_a = 90;//�^�C���̏����l
int time_start;
int time_1 = 0;
static bool g_bEnd = false;
static bool end = false;

//------------------------------------
//	�X�R�A������
//------------------------------------
void judgement_Initialize(void)
{
	time_start = clock() / 1000;
	g_bEnd = false;
	end = false;
}

//------------------------------------
//	�����蔻�菈��
//------------------------------------
void Judgement_Update(void)
{
	int time_rap = clock() / 1000;
	time_1 = time_a - (time_rap - time_start);
	for (int j = 1; j < ENEMY_MAX; j++)
	{
		for (int i = 0; i < BULLET_MAX; i++)
		{
			//�����̒e�̃R���W�����ƃG�l�~�[�̃R���W����
			if (Bullet_IsEneble(i,0) && HitSphereCollision(Player_Bullet_GetCircleCollision(i,0), Enemy_GetCircleCollision(j)))
			{
				Enemy_Life(10, j);
				Bullet_Destroy(i,0);
			}
		}
	}
	for (int j = 2; j < ENEMY_MAX; j++)
	{
		for (int i = 0; i < BULLET_MAX; i++)
		{
			//�����̒e�̃R���W�����ƃG�l�~�[�̃R���W����
			if (Bullet_IsEneble(i, 1) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 1), Player_GetCircleCollision()))
			{
				Bullet_Destroy(i, 1);
				Player_Life(10);
			}
			if (Bullet_IsEneble(i, 1) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 1), Enemy_GetCircleCollision(j)))
			{
				Enemy_Life(10, j);
				Bullet_Destroy(i, 1);
			}
		}
	}

	for (int i = 0; i < BULLET_MAX; i++)
	{
		//�����̒e�̃R���W�����ƃG�l�~�[�̃R���W����
		if (Bullet_IsEneble(i, 2) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 2), Player_GetCircleCollision()))
		{
			Player_Life(10);
			Bullet_Destroy(i, 2);
		}
		if (Bullet_IsEneble(i, 2) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 2), Enemy_GetCircleCollision(1)))
		{
			Enemy_Life(10, 1);
			Bullet_Destroy(i, 2);
		}
		if (Bullet_IsEneble(i, 2) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 2), Enemy_GetCircleCollision(3)))
		{
			Enemy_Life(10, 3);
			Bullet_Destroy(i, 2);
		}
	}
	for (int j = 1; j < 3; j++)
	{
		for (int i = 0; i < BULLET_MAX; i++)
		{
			if (Bullet_IsEneble(i, 3) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 3), Player_GetCircleCollision()))
			{
				Player_Life(10);
				Bullet_Destroy(i, 3);
			}
			//�����̒e�̃R���W�����ƃG�l�~�[�̃R���W����
			if (Bullet_IsEneble(i, 3) && HitSphereCollision(Player_Bullet_GetCircleCollision(i, 3), Enemy_GetCircleCollision(j)))
			{
				Enemy_Life(10, j);
				Bullet_Destroy(i, 3);
			}
		}
	}
	if (!g_bEnd)
	{
		if (time_1 < 1)
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			g_bEnd = true;
			end = true;
		}
	}
	if (g_bEnd)
	{
		if (!Fade_IsFade())
		{
			Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			Scene_Change(SCENE_INDEX_RESULT);
		}
	}
}

void Judgement_Draw(void)
{
	Score_draw(SCREEN_WIDTH/7*3, SCREEN_HEIGHT/15, time_1, 3, false, true);
	Sprite_Draw(TIMEFRAME, SCREEN_WIDTH /5*2, SCREEN_HEIGHT /30);
}
	
int Time(void)
{
	return time_1;
}

int End(void)
{
	return end;
}



