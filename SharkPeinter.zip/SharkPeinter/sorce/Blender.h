/*================================================================
���f���ǂݍ���[blender.h]
------------------------------------------------------------------
================================================================*/
#ifndef BLENDER_H_
#define BLENDER_H_
#include<d3dx9.h>
#define MATERIAL_INDEX_MAX (64)
typedef struct ModelFile_tag
{
	char filename[MATERIAL_INDEX_MAX]; // �e�N�X�`���t�@�C����
} ModelFile;
enum
{
	HEAD,
	BODY,
	RIGHTLEG1,
	RIGHTLEG2,
	RIGHTLEG3,
	LEFTLEG1,
	LEFTLEG2,
	LEFTLEG22,
	LEFTLEG3,
	LEFTHAND1,
	LEFTHAND2,
	LEFTHAND3,
	RIGHTHAND1,
	RIGHTHAND2,
	RIGHTHAND3,
	RIGHTHANDCUBE1,
	RIGHTHANDCUBE2,
	RIGHTHANDCUBE3,
	LEGCUBE1,
	LEGCUBE2,
	LEGCUBE3,
	LEG_KOTEI,
	HAND_KOTEI,
	CHAGER_HAND,
	PABURO_HAND1,
	PABURO_HAND2,
	SAME,
	BULLET_GUN,
	ROLLER_WEAPON,
	SHOOTER_WEAPON,
	CHAGER_WEAPON,
	PABURO_WEAPON,
	MODEL_MAX,
};
void Model_XFile(int index, int charaindex);
void Model_Draw(int index, D3DXMATRIX Warld, int charaindex);
void Model_Finalize(int index);
void Model_Update(int charaindex);
void Model_Assemble(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex);
void Model_Assemble_Machine(float x, float y, float z, D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, D3DXMATRIX P_Rotation, int index, int charaindex);
void Walk_Hand(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, float x2, int charaindex);
void Walk_Hand_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, float x2, int charaindex);
void Walk_Leg(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int charaindex);
void Walk_Leg_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int charaindex);
void Walk_Leg_Side(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation, int charaindex);
void Walk_Leg_Side_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation, int charaindex);
void Walk_Hand_Side(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation, float z, int charaindex);
void Walk_Hand_Side_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int rotation, float z, int charaindex);
void Walk_Leg_Back_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int charaindex);
void Walk_Leg_Back_Back_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int charaindex); 
void Walk_Hand_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int charaindex);
void Walk_Hand_Back_Back(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, float x, int charaindex);
void Weapon_Motion(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex);
void Player_Move(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex);
void Enemy_Move(D3DXMATRIX P_Trans, D3DXMATRIX P_Rot, int charaindex);
#endif // !BLENDER_H_