//=============================================================================
//
// ���U���g�\������ [result.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"result.h"
#include"common.h"
#include"scene.h"
#include"input.h"
#include"texture.h"
#include"sprite.h"
#include"fade.h"
#include"judgement.h"
#include "Mesh_filed.h"
#include"camera.h"
#include"score.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static bool g_bEnd = false;
static float ink_cnt[4];
static float ink_total;
static float ink_avarage[4];
static bool keisan;
static int cnt = 0;
//------------------------------------
//		����������
//------------------------------------
void Result_Initialize(void)
{
	g_bEnd = false;
	ink_cnt[4] = { 0 };
	ink_total = 0;
	ink_avarage[4] = { 0 };
	keisan = false;
	cnt = 0;
}

//------------------------------------
//		�I������
//------------------------------------
void Result_Finalize(void)
{
	Mesh_Field_Finalize();
}

//------------------------------------
//		�X�V����
//------------------------------------
void Result_Update(void)
{
	Camera_Updata();
	if (ink_total == 0)
	{
		for (int i = 0; i <= 3; i++)
		{
			ink_cnt[i] = Color_cnt(i);
			ink_total += ink_cnt[i];
		}
	}
	if (!keisan)
	{
		for (int i = 0; i <= 3; i++)
		{
			if (ink_cnt[i] == 0)
			{
				ink_avarage[i] = 0;
			}
			else
			{
				ink_avarage[i] = ink_cnt[i]/ ink_total* 100;
			}
		}
		keisan = true;
	}
	else
	{



		if (!g_bEnd)
		{

			//��
			if (Keyboard_IsTrigger(DIK_SPACE))
			{
				Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
				g_bEnd = true;
			}

		}
		if (g_bEnd)
		{
			if (!Fade_IsFade())
			{
				Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
				Scene_Change(SCENE_INDEX_TITLE);
			}
		}
	}
	if (cnt >= 60)
	{
		cnt = 0;
	}
	cnt++;
}

//------------------------------------
//		�`�揈��
//------------------------------------
void Result_Draw(void)
{
	for (int i = 0; i < FILED_MAX - 1; i++)
	{
		Mesh_Field_Draw(i + 1);
	}
	Filed_Paint(0);
	Sprite_Draw(RESULT_TEX, SCREEN_WIDTH / 7*2+10, SCREEN_HEIGHT / 15);
	if (cnt >= 30)
	{
		Sprite_Draw(PRESS_SPACE, SCREEN_WIDTH / 5 * 3, SCREEN_HEIGHT / 3*2);
	}
	for (int i = 0; i <= 3; i++)
	{
		Score_draw(SCREEN_WIDTH / 7 * 3, SCREEN_HEIGHT / 15+1*i*SCREEN_HEIGHT / 15+30*i, ink_avarage[i], 3, false, true);
	}
}