//=============================================================================
//
// �e���� [bullet.cpp]
//
//=============================================================================
//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"common.h"
#include"sprite.h"
#include"texture.h"
#include"bullet.h"
#include"input.h"
#include"Blender.h"
#include"Player.h"
#include"debug_font.h"
#include"collision.h"
#include"enemy.h"
#include"billborad.h"
#include"effect.h"
#include"title.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static BULLET bullet[4][BULLET_MAX];//�v���C���[
static int Gun_type[4];
//------------------------------------
//		����������
//------------------------------------
void Bullet_Init(int charaindex)
{
	for (int i = 0; i <= BULLET_MAX - 1; i++)
	{
		bullet[charaindex][i].g_bBulletEnable = false;
		bullet[charaindex][i].bullet_pos = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		bullet[charaindex][i].b_front = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		D3DXVec3Normalize(&bullet[charaindex][i].b_front, &bullet[charaindex][i].b_front);
		bullet[charaindex][i].b_height = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
		D3DXVec3Normalize(&bullet[charaindex][i].b_height, &bullet[charaindex][i].b_height);
		bullet[charaindex][i].bullet_collision.position = bullet[charaindex][i].bullet_pos;
		bullet[charaindex][i].bullet_collision.radius = 0.5f;

	}
	Gun_type[charaindex] = Buki_Select(charaindex);
	//Gun_type[0] = 2;
}
//------------------------------------
//		�X�V
//------------------------------------
void Bullet_Update(int charaindex)
{
	D3DXMATRIX Trans[4][BULLET_MAX];
	for (int i = 0; i <= BULLET_MAX - 1; i++)
	{
		D3DXMatrixIdentity(&Trans[charaindex][i]);
		D3DXMatrixIdentity(&bullet[charaindex][i].Warld_Gun);
		if (bullet[charaindex][i].g_bBulletEnable)
		{
			switch (Gun_type[charaindex])
			{
			case SHOOTER:
				bullet[charaindex][i].bullet_pos += bullet[charaindex][i].b_front * BULLET_SHOOTER_SPEED_Z;
				break;
			case SNIPER:
				bullet[charaindex][i].bullet_pos += bullet[charaindex][i].b_front * BULLE_SNIPER_SPEED_Z;
				break;
			case HUDE:
				bullet[charaindex][i].bullet_pos += bullet[charaindex][i].b_front * BULLE_HUDE_SPEED_Z;
				break;
			case ROLLER:
				bullet[charaindex][i].bullet_pos += bullet[charaindex][i].b_front * BULLE_ROLLER_SPEED_Z;
				break;
			default:
				break;
			}
			bullet[charaindex][i].bullet_pos.y -= BULLET_SPEED_Y;
			D3DXMatrixTranslation(&Trans[charaindex][i], bullet[charaindex][i].bullet_pos.x, bullet[charaindex][i].bullet_pos.y, bullet[charaindex][i].bullet_pos.z);
			bullet[charaindex][i].bullet_collision.position = bullet[charaindex][i].bullet_pos;
			D3DXMatrixMultiply(&bullet[charaindex][i].Warld_Gun, &bullet[charaindex][i].Warld_Gun, &Trans[charaindex][i]);
		}
		//�n�ʂɐڂ����Ȃ�:�ǂɓ���������
		if (bullet[charaindex][i].bullet_pos.y <= 0|| bullet[charaindex][i].bullet_pos.z <= -25.0f|| bullet[charaindex][i].bullet_pos.z >= 24.7f|| bullet[charaindex][i].bullet_pos.x <= -24.7f|| bullet[charaindex][i].bullet_pos.x >=24.9f)
		{
			Bullet_Destroy(i, charaindex);
		}
	}
}
//------------------------------------
//		�e����
//------------------------------------
void Bullet_Create(float px, float py, float pz ,int charaindex)//�v���C���[����l�������Ă���
{
	for (int i = 0; i <= BULLET_MAX - 1; i++)
	{
		//�e���L���łȂ��Ȃ�
		if (!bullet[charaindex][i].g_bBulletEnable)
		{
			bullet[charaindex][i].b_front = MTXR_FROANT();
			bullet[charaindex][i].bullet_pos.x = px;
			bullet[charaindex][i].bullet_pos.y = py;
			bullet[charaindex][i].bullet_pos.z = pz;
			bullet[charaindex][i].g_bBulletEnable = true;//�e��L���ɂ���
			break;
		}
	}
}
//------------------------------------
//		�`��
//------------------------------------
void Bullet_Draw(int charaindex)
{
	for (int i = 0; i <= BULLET_MAX - 1; i++)
	{
		if (bullet[charaindex][i].g_bBulletEnable)
		{
			Bilboard_Draw(INK_RED, bullet[charaindex][i].bullet_pos,charaindex);
		}
	}
}
//------------------------------------
//	�폜����
//------------------------------------
void Bullet_Destroy(int index, int charaindex)
{
	//Effect2_Create(bullet[0][index].bullet_pos);
	bullet[charaindex][index].g_bBulletEnable = false;
}
//------------------------------------
//	�L����������
//------------------------------------
bool Bullet_IsEneble(int index, int charaindex)
{
	return bullet[charaindex][index].g_bBulletEnable;
}
//------------------------------------
//		�I��
//------------------------------------
void  Bullet_Uninit(void)
{

}
//------------------------------------
//	�n�ʂɐF��h�锻��
//------------------------------------
D3DXVECTOR3 Bullet_Pos(int i, int charaindex)
{
	if (bullet[charaindex][i].g_bBulletEnable)
	{
		return bullet[charaindex][i].bullet_pos;
	}
	else
	{
		return D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	}
}
int GunType(int charaindex)
{
	switch (charaindex)
	{
	case 0:
		return Gun_type[0];
		break;
	case 1:
		return Gun_type[1];
		break;
	case 2:
		return Gun_type[2];
		break;
	case 3:
		return Gun_type[3];
		break;
	default:
		break;
	}
}
//------------------------------------
//	�����蔻��
//------------------------------------
const SphreCollision*Player_Bullet_GetCircleCollision(int index,int charaindex)
{
	return &bullet[charaindex][index].bullet_collision;
}