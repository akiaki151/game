
//========================================================================================
//
//                          �C���N���[�h
//
//----------------------------------------------------------------------------------------
#include"effect.h"
#include"bullet.h"
#include"texture.h"
#include"texani.h"
#include"billborad.h"

//�}�N��
#define WAIT2_FRAME (4)
#define PTTERN2_TW (40)
#define PTTERN2_TH (40)
#define MAX2_PTTERN (8)

//�O���[�o���ϐ�
typedef struct
{
	bool Effect2_flag = false;
	D3DXVECTOR3 Effect_Position;
	float texcutX2;
	float texcutY2;
	int frame_counter2;
}EFFECT2;


int animation2;
static int EffectCreateFrame2;
static int PtternEffect2;


EFFECT2 effect[EFFECT2_MAX];

void Effect2_Initialize(void)
{
	for (int i = 0; i < EFFECT2_MAX; i++)
	{
		effect[i].Effect2_flag = false;
		effect[i].Effect_Position = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		effect[i].texcutX2 = 0;
		effect[i].texcutY2 = 0;
		effect[i].frame_counter2 = 0;
	}

	animation2 = 0;
	EffectCreateFrame2 = 0;
	PtternEffect2 = 0;

}
void Effect2_Finalize(void)
{

}
void Effect2_Update(void)
{
	for (int i = 0; i < EFFECT2_MAX; i++)
	{
		if (effect[i].Effect2_flag == true)
		{
			effect[i].frame_counter2++;
		}
		//�p�^�[���̐؂���
		animation2 = texanimations(effect[i].frame_counter2, WAIT2_FRAME);
		effect[i].texcutX2 = texcutx(PTTERN2_TW, animation2, 5);
		effect[i].texcutY2 = texcuty(PTTERN2_TH, animation2, 2);


		if (effect[i].Effect2_flag == true)
		{
			if (animation2 > MAX2_PTTERN)
			{
				effect[i].Effect2_flag = false;
				effect[i].frame_counter2 = 0;
			}
		}
	}
}
void Effect2_Draw(void)
{
	for (int i = 0; i < EFFECT2_MAX; i++)
	{
		if (effect[i].Effect2_flag == true)
		{
			Bilboard_Draw_cut(INK_ANIME, effect[i].Effect_Position, effect[i].texcutX2, effect[i].texcutY2, PTTERN2_TW, PTTERN2_TH);
		}
	}
}
void Effect2_Create(D3DXVECTOR3 Position)
{
	for (int i = 0; i < EFFECT2_MAX; i++)
	{
		if (effect[i].Effect2_flag == false)
		{
			effect[i].Effect_Position = Position;

			effect[i].Effect2_flag = true;
			break;
		}
	}
}
void Effect2_Destroy(int index)
{
	effect[index].Effect2_flag = false;
}

bool Effect2(int index)
{
	return effect[index].Effect2_flag;
}