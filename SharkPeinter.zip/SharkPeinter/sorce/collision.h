//=============================================================================
//
// �e���� [collision.h]
//
//=============================================================================
#ifndef COLLISION_H_
#define COLLISION_H_
#include <d3dx9.h>
typedef struct SphereCollision_tag
{
	D3DXVECTOR3 position;
	float radius;
}SphreCollision;

bool HitSphereCollision(const SphreCollision *pA, const SphreCollision *pB);
#endif //!COLLISION_H_