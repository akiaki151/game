#include "tension.h"
#include "sprite.h"
#include "texture.h"

static const float maxPoint = 200;

void Tension_Init()
{
	
}
void Tension_Update()
{

}
void Tension_Draw(float currentPoint)
{
	Sprite_Draw(HPBACK, 0, 60);
	Sprite_Draw(TENSION, 0, 60, 0, 0, 1000 * (currentPoint / maxPoint), 50);
}
void Tension_Uninit()
{

}