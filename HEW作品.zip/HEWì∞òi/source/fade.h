#ifndef _FADE_H_
#define _FADE_H_

#include <d3d9.h>

void Fade_Initialize(void);
void Fade_Update(void);
void Fade_Draw(void);
void Fade_Finalize(void);
void Fade_Start(bool bOut, int frame);
bool Fade_IsEnable(void);
void Fade_Set(SCENE_INDEX scene, int key, int frame);

#endif //_FADE_H_