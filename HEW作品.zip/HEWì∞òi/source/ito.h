/*==============================================================================

�O���b�h�`�惂�W���[�� [cube.h]

==============================================================================*/
#ifndef _ITO_H_
#define _ITO_H_

void Ito_Initialize(void);
void Ito_Finalize(void);
void Ito_Draw(void);
void Ito_Update(void);

#endif //_ITO_H_