#ifndef MINIMAP_H_
#define MINIMAP_H_

void Minimap_Initialize();
void Minimap_Finalize();
void Minimap_Update();
void Minimap_Draw();

#endif // !MINIMAP_H_
