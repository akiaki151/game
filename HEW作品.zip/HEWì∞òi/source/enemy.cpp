//=============================================================================
//
// �v���C���[���� [enemy.cpp]
//
//=============================================================================
#include"mydirect.h"
#include"model.h"
#include<d3dx9.h>
#include"input.h"
#include"camera.h"
#include"debug_font.h"
#include"enemy.h"
#include"Mesh_filed.h"
#include"collision.h"
#include"player.h"
#include"sprite.h"
#include"scene.h"
#include "HpBar.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static ENEMY enemy[ENEMY_MAX];
static int frame;
static int frame_cnt;
static float sakana_move_x;
static bool sakana_judge_x;
static float sakana_move_rot;
static int sakana_hp[3];
static int score=0;
void Enemy_Initialize(void)
{
	for (int j = 0; j < ENEMY_MAX; j++)
	{
		enemy[j].EnemySpeed = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		enemy[j].front = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
		D3DXVec3Normalize(&enemy[j].front, &enemy[j].front);
		enemy[j].height = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
		D3DXVec3Cross(&enemy[j].side, &enemy[j].height, &enemy[j].front);
		D3DXVec3Normalize(&enemy[j].side, &enemy[j].side);
		D3DXVec3Cross(&enemy[j].height, &enemy[j].front, &enemy[j].side);
		D3DXVec3Normalize(&enemy[j].height, &enemy[j].height);
		enemy[j].Enemy_collision.position = enemy[j].EnemyPos;
		enemy[j].Enemy_collision.radius = 1.0f;
	}
	//�}�O�����W
	enemy[0].EnemyPos = D3DXVECTOR3(100.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�
	enemy[1].EnemyPos = D3DXVECTOR3(80.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�
	enemy[2].EnemyPos = D3DXVECTOR3(-120.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�
	enemy[3].EnemyPos = D3DXVECTOR3(-100.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�
	enemy[4].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, 120.0f);//�����ɋ��̏������W�����Ă�
	enemy[5].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, 100.0f);//�����ɋ��̏������W�����Ă�
	enemy[6].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, -100.0f);//�����ɋ��̏������W�����Ă�
	enemy[7].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, -80.0f);//�����ɋ��̏������W�����Ă�

	//����W
	enemy[8].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�


	//�}���^���W
	enemy[9].EnemyPos = D3DXVECTOR3(-60.0f, 0.5f, 60.0f);//�����ɋ��̏������W�����Ă�
	enemy[10].EnemyPos = D3DXVECTOR3(-60.0f, 0.5f, -60.0f);//�����ɋ��̏������W�����Ă�
	enemy[11].EnemyPos = D3DXVECTOR3(60.0f, 0.5f, 60.0f);//�����ɋ��̏������W�����Ă�
	enemy[12].EnemyPos = D3DXVECTOR3(60.0f, 0.5f, -60.0f);//�����ɋ��̏������W�����Ă�

	frame = 0;
	frame_cnt = 0;
}

void Enemy_Initialize2(void)
{
	for (int j = 0; j < ENEMY_MAX; j++)
	{
		enemy[j].EnemySpeed = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
		enemy[j].front = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
		D3DXVec3Normalize(&enemy[j].front, &enemy[j].front);
		enemy[j].height = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
		D3DXVec3Cross(&enemy[j].side, &enemy[j].height, &enemy[j].front);
		D3DXVec3Normalize(&enemy[j].side, &enemy[j].side);
		D3DXVec3Cross(&enemy[j].height, &enemy[j].front, &enemy[j].side);
		D3DXVec3Normalize(&enemy[j].height, &enemy[j].height);
		enemy[j].Enemy_collision.position = enemy[j].EnemyPos;
		enemy[j].Enemy_collision.radius = 1.0f;
	}
	//�}�O�����W
	enemy[0].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�
	

	//����W
	enemy[8].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�


	//�}���^���W
	enemy[12].EnemyPos = D3DXVECTOR3(0.0f, 0.5f, 0.0f);//�����ɋ��̏������W�����Ă�

	frame = 0;
	frame_cnt = 0;
	sakana_move_x = 0.0f;
	sakana_judge_x = false;
	sakana_move_rot=0.0f;

	switch (Sakana_Get())
	{
	case 0:
		sakana_hp[0] = 500;//�}�O��
		HpBar_Init(sakana_hp[0]);
		break;
	case 1:
		sakana_hp[2] = 2000;//�T��
		HpBar_Init(sakana_hp[2]);
		break;
	case 2:
		sakana_hp[1] = 1000;//�}���^
		HpBar_Init(sakana_hp[1]);
		break;
	default:
		break;
	}
}

void Enemy_Updata(void)
{
	//�����̓T��
	for (int j = SAKANA_SAME; j < SAKANA_MANTA; j++)
	{
		D3DXMatrixIdentity(&enemy[j].Rot);
		D3DXMatrixIdentity(&enemy[j].WARLD);
		D3DXMatrixIdentity(&enemy[j].Trans);
		D3DXMatrixTranslation(&enemy[j].Trans, enemy[j].EnemyPos.x, enemy[j].EnemyPos.y, enemy[j].EnemyPos.z);
		enemy[j].Enemy_collision.position = enemy[j].EnemyPos;
		D3DXMatrixRotationX(&enemy[j].mtxR, D3DXToRadian(90));
		enemy[j].WARLD = enemy[j].mtxR * enemy[j].Trans;
	}

	//��������}�O��
	for (int j = 0; j < SAKANA_SAME; j++)
	{
		D3DXMatrixIdentity(&enemy[j].Rot);
		D3DXMatrixIdentity(&enemy[j].WARLD);
		D3DXMatrixIdentity(&enemy[j].Trans);
		D3DXMatrixTranslation(&enemy[j].Trans, enemy[j].EnemyPos.x, enemy[j].EnemyPos.y, enemy[j].EnemyPos.z);
		enemy[j].Enemy_collision.position = enemy[j].EnemyPos;
		D3DXMatrixRotationX(&enemy[j].mtxR, D3DXToRadian(90));
		enemy[j].WARLD = enemy[j].mtxR * enemy[j].Trans;
	}

	//��������}���^
	for (int j = SAKANA_MANTA; j < ENEMY_MAX; j++)
	{
		D3DXMatrixIdentity(&enemy[j].Rot);
		D3DXMatrixIdentity(&enemy[j].WARLD);
		D3DXMatrixIdentity(&enemy[j].Trans);
		D3DXMatrixTranslation(&enemy[j].Trans, enemy[j].EnemyPos.x, enemy[j].EnemyPos.y-1.5f, enemy[j].EnemyPos.z);
		enemy[j].Enemy_collision.position = enemy[j].EnemyPos;
		D3DXMatrixRotationX(&enemy[j].mtxR, D3DXToRadian(270));
		enemy[j].WARLD = enemy[j].mtxR * enemy[j].Trans;
	}

	if (frame_cnt >= 1000)
	{
		frame_cnt = 0;
	}
	frame_cnt++;
	frame = (frame_cnt / 8) % 10;
}

void Enemy_Updata2(void)
{
	HpBar_Update();
	if (sakana_move_x >= 10.0f)
	{
		sakana_judge_x = true;
	}
	else if (sakana_move_x <= -10.0f)
	{
		sakana_judge_x = false;
	}

	if (!sakana_judge_x)
	{
		sakana_move_x += 0.05f;
		sakana_move_rot = -90.0f;
	}
	else
	{
		sakana_move_rot = 90.0f;
		sakana_move_x -= 0.05f;
	}

	switch (Sakana_Get())
	{
	case 0:
		//��������}�O��
		if (!Turi_Batlle())
		{
			if (!Turi_State())
			{
				D3DXMatrixIdentity(&enemy[0].Rot);
				D3DXMatrixIdentity(&enemy[0].WARLD);
				D3DXMatrixIdentity(&enemy[0].Trans);
				D3DXMatrixTranslation(&enemy[0].Trans, enemy[0].EnemyPos.x + sakana_move_x, enemy[0].EnemyPos.y, enemy[0].EnemyPos.z);
				enemy[0].Enemy_collision.position = enemy[0].EnemyPos;
				D3DXMatrixRotationX(&enemy[0].mtxR, D3DXToRadian(90));
				D3DXMatrixRotationY(&enemy[0].mtxR2, D3DXToRadian(sakana_move_rot));
				enemy[0].WARLD = enemy[0].mtxR *enemy[0].mtxR2* enemy[0].Trans;
			}
			else
			{
				D3DXMatrixIdentity(&enemy[0].Rot);
				D3DXMatrixIdentity(&enemy[0].WARLD);
				D3DXMatrixIdentity(&enemy[0].Trans);
				D3DXMatrixTranslation(&enemy[0].Trans, enemy[0].EnemyPos.x + sakana_move_x, enemy[0].EnemyPos.y - 3.0f, enemy[0].EnemyPos.z);
				enemy[0].Enemy_collision.position = enemy[0].EnemyPos;
				D3DXMatrixRotationX(&enemy[0].mtxR, D3DXToRadian(90));
				D3DXMatrixRotationY(&enemy[0].mtxR2, D3DXToRadian(sakana_move_rot));
				enemy[0].WARLD = enemy[0].mtxR *enemy[0].mtxR2* enemy[0].Trans;
			}
		}
		else if (Turi_Batlle())
		{
			sakana_hp[0] -= Damage();
			D3DXMatrixIdentity(&enemy[0].Rot);
			D3DXMatrixIdentity(&enemy[0].WARLD);
			D3DXMatrixIdentity(&enemy[0].Trans);
			enemy[0].Enemy_collision.position = enemy[0].EnemyPos;
			D3DXMatrixRotationX(&enemy[0].mtxR, D3DXToRadian(90));
			D3DXMatrixRotationY(&enemy[0].mtxR2, D3DXToRadian(sakana_move_rot));
			enemy[0].WARLD = enemy[0].mtxR *enemy[0].mtxR2* Uki_pos();
			if (sakana_hp[0] <= 0)
			{
				score = 1000;
				Scene_Change(SCENE_INDEX_RESULT);
			}
		}

		break;
	case 1:
		//�����̓T��
		if (!Turi_Batlle())
		{
			if (!Turi_State())
			{
				D3DXMatrixIdentity(&enemy[8].Rot);
				D3DXMatrixIdentity(&enemy[8].WARLD);
				D3DXMatrixIdentity(&enemy[8].Trans);
				D3DXMatrixTranslation(&enemy[8].Trans, enemy[8].EnemyPos.x + sakana_move_x, enemy[8].EnemyPos.y, enemy[8].EnemyPos.z);
				enemy[8].Enemy_collision.position = enemy[8].EnemyPos;
				D3DXMatrixRotationX(&enemy[8].mtxR, D3DXToRadian(90));
				D3DXMatrixRotationY(&enemy[8].mtxR2, D3DXToRadian(sakana_move_rot));
				enemy[8].WARLD = enemy[8].mtxR *enemy[8].mtxR2* enemy[8].Trans;
			}
			else
			{
				D3DXMatrixIdentity(&enemy[8].Rot);
				D3DXMatrixIdentity(&enemy[8].WARLD);
				D3DXMatrixIdentity(&enemy[8].Trans);
				D3DXMatrixTranslation(&enemy[8].Trans, enemy[8].EnemyPos.x + sakana_move_x, enemy[8].EnemyPos.y - 3.0f, enemy[8].EnemyPos.z);
				enemy[8].Enemy_collision.position = enemy[8].EnemyPos;
				D3DXMatrixRotationX(&enemy[8].mtxR, D3DXToRadian(90));
				D3DXMatrixRotationY(&enemy[8].mtxR2, D3DXToRadian(sakana_move_rot));
				enemy[8].WARLD = enemy[8].mtxR *enemy[8].mtxR2* enemy[8].Trans;
			}
		}
		else if (Turi_Batlle())
		{
			sakana_hp[2] -= Damage();
			D3DXMatrixIdentity(&enemy[8].Rot);
			D3DXMatrixIdentity(&enemy[8].WARLD);
			D3DXMatrixIdentity(&enemy[8].Trans);
			enemy[8].Enemy_collision.position = enemy[8].EnemyPos;
			D3DXMatrixRotationX(&enemy[8].mtxR, D3DXToRadian(90));
			D3DXMatrixRotationY(&enemy[8].mtxR2, D3DXToRadian(sakana_move_rot));
			enemy[8].WARLD = enemy[8].mtxR *enemy[8].mtxR2* Uki_pos();
			if (sakana_hp[2] <= 0)
			{
				score = 5000;
				Scene_Change(SCENE_INDEX_RESULT);

			}
		}
		break;
	case 2:
		//��������}���^
		if (!Turi_Batlle())
		{
			if (!Turi_State())
			{
				D3DXMatrixIdentity(&enemy[12].Rot);
				D3DXMatrixIdentity(&enemy[12].WARLD);
				D3DXMatrixIdentity(&enemy[12].Trans);
				D3DXMatrixTranslation(&enemy[12].Trans, enemy[12].EnemyPos.x + sakana_move_x, enemy[12].EnemyPos.y - 1.5f, enemy[12].EnemyPos.z);
				enemy[12].Enemy_collision.position = enemy[12].EnemyPos;
				D3DXMatrixRotationX(&enemy[12].mtxR, D3DXToRadian(270));
				D3DXMatrixRotationY(&enemy[12].mtxR2, D3DXToRadian(sakana_move_rot));
				enemy[12].WARLD = enemy[12].mtxR *enemy[12].mtxR2* enemy[12].Trans;
			}
			else
			{
				D3DXMatrixIdentity(&enemy[12].Rot);
				D3DXMatrixIdentity(&enemy[12].WARLD);
				D3DXMatrixIdentity(&enemy[12].Trans);
				D3DXMatrixTranslation(&enemy[12].Trans, enemy[12].EnemyPos.x + sakana_move_x, enemy[12].EnemyPos.y - 4.5f, enemy[12].EnemyPos.z);
				enemy[12].Enemy_collision.position = enemy[12].EnemyPos;
				D3DXMatrixRotationX(&enemy[12].mtxR, D3DXToRadian(270));
				D3DXMatrixRotationY(&enemy[12].mtxR2, D3DXToRadian(sakana_move_rot));
				enemy[12].WARLD = enemy[12].mtxR *enemy[12].mtxR2* enemy[12].Trans;
			}
		}
		else if (Turi_Batlle())
		{
			sakana_hp[1] -= Damage();
			D3DXMatrixIdentity(&enemy[12].Rot);
			D3DXMatrixIdentity(&enemy[12].WARLD);
			enemy[12].Enemy_collision.position = enemy[12].EnemyPos;
			D3DXMatrixRotationX(&enemy[12].mtxR, D3DXToRadian(270));
			D3DXMatrixRotationY(&enemy[12].mtxR2, D3DXToRadian(sakana_move_rot));
			enemy[12].WARLD = enemy[12].mtxR *enemy[12].mtxR2* Uki_pos();
			if (sakana_hp[1] <= 0)
			{
				score = 3000;
				Scene_Change(SCENE_INDEX_RESULT);
			}
		}
		break;
	default:
		break;
	}

	if (frame_cnt >= 1000)
	{
		frame_cnt = 0;
	}
	frame_cnt++;
	frame = (frame_cnt / 8) % 10;
}

void Enemy_Draw(void)
{

	Same_Anime();
	Maguro_Anime();
	Manta_Anime();
}

void Enemy_Draw2(void)
{
	switch (Sakana_Get())
	{
	case 0:
		Maguro_Anime2();
		HpBar_Draw(sakana_hp[0]);
		break;
	case 1:
		Same_Anime2();
		HpBar_Draw(sakana_hp[2]);
		break;
	case 2:
		Manta_Anime2();
		HpBar_Draw(sakana_hp[1]);
		break;
	default:
		break;
	}
	//Sprite_Draw(BREAK,0,0);
}

void Maguro_Anime(void)
{
	for (int j = 0; j < SAKANA_SAME; j++)
	{
		switch (frame)
		{
		case 0:
			Model_Draw(MAGURO1, enemy[j].WARLD);
			break;
		case 1:
			Model_Draw(MAGURO2, enemy[j].WARLD);
			break;
		case 2:
			Model_Draw(MAGURO3, enemy[j].WARLD);
			break;
		case 3:
			Model_Draw(MAGURO4, enemy[j].WARLD);
			break;
		case 4:
			Model_Draw(MAGURO5, enemy[j].WARLD);
			break;
		case 5:
			Model_Draw(MAGURO6, enemy[j].WARLD);
			break;
		case 6:
			Model_Draw(MAGURO5, enemy[j].WARLD);
			break;
		case 7:
			Model_Draw(MAGURO4, enemy[j].WARLD);
			break;
		case 8:
			Model_Draw(MAGURO3, enemy[j].WARLD);
			break;
		case 9:
			Model_Draw(MAGURO2, enemy[j].WARLD);
		break;	default:
			break;
		}
	}
}

void Same_Anime(void)
{
	for (int j = SAKANA_SAME; j < SAKANA_MANTA; j++)
	{
		switch (frame)
		{
		case 0:
			Model_Draw(SAME_1, enemy[j].WARLD);
			break;
		case 1:
			Model_Draw(SAME_2, enemy[j].WARLD);
			break;
		case 2:
			Model_Draw(SAME_3, enemy[j].WARLD);
			break;
		case 3:
			Model_Draw(SAME_4, enemy[j].WARLD);
			break;
		case 4:
			Model_Draw(SAME_5, enemy[j].WARLD);
			break;
		case 5:
			Model_Draw(SAME_6, enemy[j].WARLD);
			break;
		case 6:
			Model_Draw(SAME_5, enemy[j].WARLD);
			break;
		case 7:
			Model_Draw(SAME_4, enemy[j].WARLD);
			break;
		case 8:
			Model_Draw(SAME_3, enemy[j].WARLD);
			break;
		case 9:
			Model_Draw(SAME_2, enemy[j].WARLD);
		break;	default:
			break;
		}
	}
}

void Manta_Anime(void)
{
	for (int j = SAKANA_MANTA; j < ENEMY_MAX; j++)
	{
		switch (frame)
		{
		case 0:
			Model_Draw(MANTA_1, enemy[j].WARLD);
			break;
		case 1:
			Model_Draw(MANTA_2, enemy[j].WARLD);
			break;
		case 2:
			Model_Draw(MANTA_3, enemy[j].WARLD);
			break;
		case 3:
			Model_Draw(MANTA_4, enemy[j].WARLD);
			break;
		case 4:
			Model_Draw(MANTA_5, enemy[j].WARLD);
			break;
		case 5:
			Model_Draw(MANTA_6, enemy[j].WARLD);
			break;
		case 6:
			Model_Draw(MANTA_5, enemy[j].WARLD);
			break;
		case 7:
			Model_Draw(MANTA_4, enemy[j].WARLD);
			break;
		case 8:
			Model_Draw(MANTA_3, enemy[j].WARLD);
			break;
		case 9:
			Model_Draw(MANTA_2, enemy[j].WARLD);
		break;	default:
			break;
		}
	}
}

void Maguro_Anime2(void)
{
	switch (frame)
	{
	case 0:
		Model_Draw(MAGURO1, enemy[0].WARLD);
		break;
	case 1:
		Model_Draw(MAGURO2, enemy[0].WARLD);
		break;
	case 2:
		Model_Draw(MAGURO3, enemy[0].WARLD);
		break;
	case 3:
		Model_Draw(MAGURO4, enemy[0].WARLD);
		break;
	case 4:
		Model_Draw(MAGURO5, enemy[0].WARLD);
		break;
	case 5:
		Model_Draw(MAGURO6, enemy[0].WARLD);
		break;
	case 6:
		Model_Draw(MAGURO5, enemy[0].WARLD);
		break;
	case 7:
		Model_Draw(MAGURO4, enemy[0].WARLD);
		break;
	case 8:
		Model_Draw(MAGURO3, enemy[0].WARLD);
		break;
	case 9:
		Model_Draw(MAGURO2, enemy[0].WARLD);
	break;	default:
		break;
	}

}

void Same_Anime2(void)
{

	switch (frame)
	{
	case 0:
		Model_Draw(SAME_1, enemy[8].WARLD);
		break;
	case 1:
		Model_Draw(SAME_2, enemy[8].WARLD);
		break;
	case 2:
		Model_Draw(SAME_3, enemy[8].WARLD);
		break;
	case 3:
		Model_Draw(SAME_4, enemy[8].WARLD);
		break;
	case 4:
		Model_Draw(SAME_5, enemy[8].WARLD);
		break;
	case 5:
		Model_Draw(SAME_6, enemy[8].WARLD);
		break;
	case 6:
		Model_Draw(SAME_5, enemy[8].WARLD);
		break;
	case 7:
		Model_Draw(SAME_4, enemy[8].WARLD);
		break;
	case 8:
		Model_Draw(SAME_3, enemy[8].WARLD);
		break;
	case 9:
		Model_Draw(SAME_2, enemy[8].WARLD);
	break;	default:
		break;
	}

}

void Manta_Anime2(void)
{

	switch (frame)
	{
	case 0:
		Model_Draw(MANTA_1, enemy[12].WARLD);
		break;
	case 1:
		Model_Draw(MANTA_2, enemy[12].WARLD);
		break;
	case 2:
		Model_Draw(MANTA_3, enemy[12].WARLD);
		break;
	case 3:
		Model_Draw(MANTA_4, enemy[12].WARLD);
		break;
	case 4:
		Model_Draw(MANTA_5, enemy[12].WARLD);
		break;
	case 5:
		Model_Draw(MANTA_6, enemy[12].WARLD);
		break;
	case 6:
		Model_Draw(MANTA_5, enemy[12].WARLD);
		break;
	case 7:
		Model_Draw(MANTA_4, enemy[12].WARLD);
		break;
	case 8:
		Model_Draw(MANTA_3, enemy[12].WARLD);
		break;
	case 9:
		Model_Draw(MANTA_2, enemy[12].WARLD);
	break;	default:
		break;
	}

}

const SphreCollision*Enemy_GetCircleCollision(int index)
{
	return &enemy[index].Enemy_collision;
}

ENEMY* Enemy_GetData()
{
	return enemy;
}

void Enemy_GetNum()
{
	
}

int Get_Score2(void)
{
	return score;
}