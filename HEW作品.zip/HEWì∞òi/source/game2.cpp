//=============================================================================
//
// �Q�[������ [game.cpp]
//
//=============================================================================
/*------------------------------------------------------------------------------
   �֐���`
------------------------------------------------------------------------------*/
#include"camera.h"
#include"model.h"
#include"light.h"
#include"Mesh_filed.h"
#include"billborad.h"
#include"Player.h"
#include"wave2.h"
#include"MiniMap.h"
#include"enemy.h"
#include"scene.h"
Wave2 *wave;

// �Q�[���̏�����
void Game2_Initialize(void)
{
	Camera_Initilize();
	Light_SetLight();
	Player_Initialize();
	Enemy_Initialize2();
	Mesh_Skydome_Initialize(10.0f, 350.0f, 20, 20);
	Mesh_Cylinder_Initialize(10.0f, 200.0f, 5, 2);
	Mesh_Field_Initialize(50.0f, MeshFiled_X, MeshFiled_Z);
	wave = new Wave2(100, 100);
	wave->Water_Begin2(-10, 0, 0.006, 1);
	for (int i = 0; i < MODEL_MAX; i++)
	{
		Model_XFile(i);
	}
	Bilboard_Initialize();
}
// �Q�[���̏I������
void Game2_Finalize(void)
{
	Mesh_Field_Finalize();
	for (int i = 0; i < MODEL_MAX; i++)
	{
		Model_Finalize(i);
	}
	Bilboard_Finalize();
}
// �Q�[���̍X�V
void Game2_Update(void)
{
	Enemy_Updata2();
	Player_Update2();
	Camera_Updata();
	wave->Water_Update2();
	Bilboard_Update();
}
// �Q�[���̕`��
void Game2_Draw(void)
{
	Mesh_Field_Draw(0);
	Mesh_Field_Draw(1);
	Mesh_Field_Draw(2);
	wave->Water_Draw2();
	Draw_Camera();
	Player_Draw2();
	Enemy_Draw2();
}