#include "HpBar.h"
#include "sprite.h"
#include "texture.h"

int g_startPoint;

void HpBar_Init(float startPoint)
{
	g_startPoint = startPoint;
}

void HpBar_Update()
{
}

void HpBar_Draw(float currentPoint)
{
	Sprite_Draw(HPBACK, 0, 0);
	Sprite_Draw(HPBAR,0,0,0,0,1000 * (currentPoint / g_startPoint),50);
}

void HpBar_Uninit()
{

}
