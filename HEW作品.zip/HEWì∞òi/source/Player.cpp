//=============================================================================
//
// �v���C���[���� [player.cpp]
//
//=============================================================================
//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"mydirect.h"
#include"model.h"
#include<d3dx9.h>
#include"input.h"
#include"camera.h"
#include"debug_font.h"
#include"Player.h"
#include"Mesh_filed.h"
#include"collision.h"
#include"enemy.h"
#include"scene.h"
#include"sprite.h"
#include"tension.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static D3DXVECTOR3 g_PlayerSpeed;
static D3DXVECTOR3 g_PlayerPos;
static D3DXVECTOR3 p_front;
static D3DXVECTOR3 p_side;
static D3DXVECTOR3 p_height;
static D3DXMATRIX Trans;
static D3DXMATRIX mtxR;
static D3DXMATRIX Rot;
static D3DXMATRIX WARLD;
static D3DXMATRIX WARLD2;
static D3DXMATRIX WARLD3;
static D3DXMATRIX WARLD4;
static D3DXMATRIX Trans2;
static D3DXMATRIX mtxR2;
static D3DXMATRIX Trans3;
static D3DXMATRIX mtxR3;
static D3DXMATRIX Trans4;
static D3DXMATRIX mtxR4;
static D3DXMATRIX mtxR5;
static D3DXMATRIX mtxR_Player;
SphreCollision player_collision;
static float rot;
static float wave_y;//�g��Y�����ɐU������
static bool wave_judge;//�g�̔��菈��
static int sakana_judge=0;
static float sao_rot;
static bool sao_nage;
static float sao_rot2;
static float uki_pos;
static bool turi_state;
static float uki_sizumi;
static bool  uki_sizumi_judge;
static int   uki_sizumi_num;
static bool turi_buttle;
static int turi_rot;
static int turi_buttle_cnt = 0;
static int sao_hp;
static float damage;
static float uki_move;
static bool orient;
static int muki_cnt;
static float uki_move_y;
static bool uki_y;
//------------------------------------
//		����������
//------------------------------------
void Player_Initialize(void) {
	g_PlayerSpeed = D3DXVECTOR3(0.0f, 0.0f, 0.0f);
	g_PlayerPos = D3DXVECTOR3(0.0f, 0.5f, -20.0f);
	p_front = D3DXVECTOR3(0.0f, 0.0f, 1.0f);
	D3DXVec3Normalize(&p_front, &p_front);
	p_height = D3DXVECTOR3(0.0f, 1.0f, 0.0f);
	D3DXVec3Cross(&p_side, &p_height, &p_front);
	D3DXVec3Normalize(&p_side, &p_side);
	D3DXVec3Cross(&p_height, &p_front, &p_side);
	D3DXVec3Normalize(&p_height, &p_height);
	player_collision.position = g_PlayerPos;
	player_collision.radius = 3.0f;
	rot = 0.0f;
	wave_y = 0.0f;
	wave_judge = false;
	sao_rot = 0;
	sao_rot2 = 0;
	sao_nage = false;
	uki_pos=0.0f;
	turi_state = false;
	uki_sizumi=0.0f;
	uki_sizumi_judge=false;
	uki_sizumi_num=0;
	turi_buttle = false;
	turi_rot = 0;
	turi_buttle_cnt = 0;
	uki_move=0.0f;
	sao_hp = 0;
	orient=false;
	muki_cnt = 0;
	damage=0;
	uki_move_y=0.0f;
	uki_y=false;
}
//------------------------------------
//		�X�V����
//------------------------------------
void Player_Update(void) 
{
	D3DXMatrixIdentity(&Rot);
	D3DXMatrixIdentity(&WARLD);
	Player_Move();
	Player_Wave_Y();
}
void Player_Update2(void)
{
	if (Keyboard_IsPress(DIK_UP))
	{
		if (sao_rot >= 100.0f)
		{
			sao_nage = true;
		}
		if(!sao_nage)
		sao_rot += 0.5f;
	}
	if(sao_nage)
	{
		sao_rot = 0.0f;
		if (uki_pos <= 30.0f)
		{
			sao_rot2 += 20.0f;
			uki_pos += 0.5f;
		}
		else
		{
			turi_state = true;
		}
	}

	if (uki_sizumi_num < 3)
	{
		if (turi_state)
		{
			if (uki_sizumi_judge)
				uki_sizumi += 0.01f;
			else
				uki_sizumi -= 0.01f;

			if (uki_sizumi >= 0.3f)
			{
				uki_sizumi_judge = false;
				uki_sizumi_num += 1;
			}
			if (uki_sizumi <= -0.3f)
			{
				uki_sizumi_judge = true;
			}
		}
	}
	if (uki_sizumi_num >= 3)
	{
		if (uki_sizumi >= -1.0f)
		{
			uki_sizumi -= 0.05f;
		}
		if (Keyboard_IsTrigger(DIK_SPACE)) {
			turi_buttle = true;
		}
	}

	if (turi_buttle)
	{
		if (turi_buttle_cnt <= 60)
			turi_buttle_cnt++;

		if (!orient)
		{
			uki_move += 0.05f;
		}
		if (orient)
		{
			uki_move -= 0.05f;
		}

		if (Keyboard_IsPress(DIK_LEFT)) {
			turi_rot = -30;
			if (Keyboard_IsPress(DIK_DOWN)) {
				sao_rot2 -= 10.0f;
				if (!orient)
				{
					muki_cnt += 1;
					sao_hp += 1;
					damage += 0.05;
					if(!uki_y)
					uki_move_y += 0.05f;
					else
						uki_move_y -= 0.05f;
				}
				else
				{
					sao_hp += 2;
					damage += 0.05;
				}
			}
		}
		if (Keyboard_IsPress(DIK_RIGHT))
		{
			turi_rot = 30;
			if (Keyboard_IsPress(DIK_DOWN)) {
				sao_rot2 -= 10.0f;
				if (orient)
				{
					muki_cnt += 1;
					sao_hp += 1;
					damage += 0.05;
					if (!uki_y)
						uki_move_y += 0.05f;
					else
						uki_move_y -= 0.05f;
				}
				else
				{
					sao_hp += 2;
					damage += 0.05;
				}
			}

		}
		
		if (!Keyboard_IsPress(DIK_DOWN)) {
			damage = 0;
			sao_hp -= 1;
		}

		if (sao_hp <= 0)
		{
			sao_hp = 0;
		}

		if (muki_cnt >= 30)
		{
			if (!orient)
			{
				orient = true;
				muki_cnt = 0;
			}
			else if (orient)
			{
				orient = false;
				muki_cnt = 0;
			}
		}
	}

	if (uki_move_y >= 0.1f)
	{
		uki_y = true;
	}
	else if (uki_move_y <= -0.1f)
	{
		uki_y = false;
	}

	if (sao_hp>= 200|| uki_move<=-20.0f|| uki_move >= 20.0f)
	{
		Scene_Change(SCENE_INDEX_RESULT);
	}
	D3DXMatrixIdentity(&WARLD2);
}
void Player_Move(void)
{
	if (Keyboard_IsPress(DIK_D)) {
		if (Keyboard_IsPress(DIK_S))
		{
			D3DXMatrixRotationAxis(&mtxR_Player, &-p_height, D3DXToRadian(0.1f));
			rot -= 0.1f;
		}
		else
		{//�o�b�N���p
			D3DXMatrixRotationAxis(&mtxR_Player, &p_height, D3DXToRadian(0.1f));
			rot += 0.1f;
		}
		D3DXMatrixRotationAxis(&mtxR_Player, &p_height, D3DXToRadian(0.1f));
		D3DXVec3TransformNormal(&p_front, &p_front, &mtxR_Player);
		D3DXVec3TransformNormal(&p_side, &p_side, &mtxR_Player);
		//rot += 0.1f;
	}
	if (Keyboard_IsPress(DIK_A)) {
		if (Keyboard_IsPress(DIK_S))
		{
			D3DXMatrixRotationAxis(&mtxR_Player, &p_height, D3DXToRadian(0.1f));
			rot += 0.1f;
		}
		else
		{//�o�b�N���p
			D3DXMatrixRotationAxis(&mtxR_Player, &-p_height, D3DXToRadian(0.1f));
			rot -= 0.1f;
		}
		D3DXMatrixRotationAxis(&mtxR_Player, &-p_height, D3DXToRadian(0.1f));
		D3DXVec3TransformNormal(&p_front, &p_front, &mtxR_Player);
		D3DXVec3TransformNormal(&p_side, &p_side, &mtxR_Player);
		//rot -= 0.1f;
	}
	if (Keyboard_IsPress(DIK_W)) {
		D3DXVECTOR3 f(p_front);
		f.y = 0.0f;
		g_PlayerSpeed += f * PLAYER_FRONT_SPEED;
	}
	if (Keyboard_IsPress(DIK_S)) {
		D3DXVECTOR3 f(p_front);
		f.y = 0.0f;
		g_PlayerSpeed -= f * PLAYER_BACK_SPEED;
	}

	g_PlayerPos += g_PlayerSpeed;
	g_PlayerSpeed *= 0.99f;
	g_PlayerPos.x = max(g_PlayerPos.x, -MeshWall_X + 0.3f);
	g_PlayerPos.x = min(g_PlayerPos.x, MeshWall_X - 0.1f);
	g_PlayerPos.z = max(g_PlayerPos.z, -MeshWall_Z + 0.3f);
	g_PlayerPos.z = min(g_PlayerPos.z, MeshWall_Z - 0.3f);
	D3DXMatrixTranslation(&Trans, g_PlayerPos.x, g_PlayerPos.y, g_PlayerPos.z);
	D3DXMatrixRotationY(&mtxR, D3DXToRadian(rot));
	WARLD = mtxR*Trans;
	player_collision.position = g_PlayerPos;

}
void Player_Wave_Y(void)
{
	g_PlayerPos.y += wave_y;
	if(!wave_judge)
	wave_y += 0.001f;
	else if (wave_judge)
		wave_y -= 0.001f;

	if (wave_y >= 0.02f)
		wave_judge = true;
	else if (wave_y <= -0.02f)
		wave_judge = false;
}
void Player_Draw(void)
{
	Model_Draw(HUNE, WARLD);
	for (int j = 0; j < ENEMY_MAX; j++)
	{
		if (HitSphereCollision(Player_GetCircleCollision(), Enemy_GetCircleCollision(j)))
		{
			if (0 <= j && j <= 7)
			{
				sakana_judge = 0;//�}�O��
			}
			else if (8 ==j)
			{
				sakana_judge = 1;//�T��
			}
			else if (9 <= j)
			{
				sakana_judge = 2;//�}���^
			}
			Scene_Change(SCENE_INDEX_GAME2);
		}
	}
}
void Player_Draw2(void)
{
	D3DXMatrixTranslation(&Trans, 0.0f, 0.5f, -21.0);
	D3DXMatrixRotationY(&mtxR, D3DXToRadian(90));
	WARLD = mtxR * Trans;
	Model_Draw(HUNE, WARLD);

	D3DXMatrixTranslation(&Trans2, 0.0f, 1.5f, -20.0);
	D3DXMatrixRotationX(&mtxR2, D3DXToRadian(-20- sao_rot));
	D3DXMatrixRotationY(&mtxR5, D3DXToRadian(turi_rot));
	WARLD2 = mtxR2 * mtxR5* Trans2;

	D3DXMatrixTranslation(&Trans3, 0.0f, 1.5f, -17.8);
	D3DXMatrixRotationX(&mtxR3, D3DXToRadian(-20 - sao_rot2));
	WARLD3 = mtxR3 * Trans3;

	D3DXMatrixTranslation(&Trans4, 1.0f+ uki_move, 1.5f+ uki_sizumi+ uki_move_y, -17.8+ uki_pos/3);
	D3DXMatrixRotationX(&mtxR4, D3DXToRadian(0));
	WARLD4 = mtxR4 * Trans4;

	Model_Draw(SAO, WARLD2);
	if(!sao_nage)
	Model_Draw(SAO_REAL, WARLD2);
	if (sao_nage)
	Model_Draw(SAO_REAL2, WARLD3);

	Model_Draw(UKI, WARLD4);

	if (turi_buttle&& turi_buttle_cnt <= 60)
	{
		Sprite_Draw(HIT, 0, 0);
	}
	Tension_Draw(sao_hp);
	if(sao_hp>=160)
	Sprite_Draw(BREAK,0,0);
}
D3DXVECTOR3 Player_Pos(void)
{
	return g_PlayerPos;
}
D3DXMATRIX Player_Rot(void)
{
	return mtxR_Player;
}

D3DXVECTOR3 MTXR_FROANT(void)
{
	return p_front;
}

float Player_rot(void)
{
	return rot;
}
float Player_2DRot(void)
{
	return rot;
}
D3DXMATRIX Model_Rot(void)
{
	return mtxR;
}

const SphreCollision*Player_GetCircleCollision()
{
	return &player_collision;
}

int Sakana_Get(void)
{
	return sakana_judge;
}

bool Turi_State(void)
{
	return turi_state;
}

bool Turi_Batlle(void)
{
	return turi_buttle;
}

D3DXMATRIX Uki_pos(void)
{
	return Trans4;
}

int Damage(void)
{
	return damage;
}