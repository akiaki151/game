#include <d3dx9.h>
#include "common.h"
#include "mydirect.h"
#include "sprite.h"
#include "scene.h"
#include "input.h"

//static D3DXCOLOR g_FadeColor(0.0f, 0.0f, 0.0f, 1.0f);

static int g_r = 0;
static int g_g = 0;
static int g_b = 0;
static int g_Alpha = 1.0f;
static int g_AddAlpha = 0.0f;
static bool g_bOut = false;
static bool g_bIsFade = false;
static bool g_bFadeEnd = false;

void Fade_Initialize(void)
{
	g_r = 0;
	g_g = 0;
	g_b = 0;
	g_bIsFade = false;
	g_bFadeEnd = false;
	g_Alpha = 0.0f;
}

void Fade_Update(void)
{
	if (!g_bIsFade)
	{
		return;
	}

	g_Alpha += g_AddAlpha;

	if (g_bOut)
	{
		if (g_Alpha >= 255)
		{
			g_Alpha = 255;
			g_bIsFade = false;
		}
	}
	else
	{
		if (g_Alpha<=0)
		{
			g_Alpha = 0;
			g_bIsFade = false;
		}
	}
}

void Fade_Draw(void)
{
	if (g_Alpha<=0)
	{
		return;
	}
	//g_FadeColor.a = g_Alpha;
	//D3DCOLOR c = g_FadeColor;

	Sprite_Draw(D3DCOLOR_RGBA(g_r, g_g, g_b, g_Alpha),0.0f,0.0f);

}

void Fade_Finalize(void)
{
}

void Fade_Start(bool bOut,int frame)
{
	g_bOut = bOut;
	g_AddAlpha = frame;
	//g_FadeColor = color;
	g_bIsFade = true;

	if (g_bOut)
	{
		g_Alpha = 0;
	}
	else
	{
		g_Alpha = 255;
		g_AddAlpha = -g_AddAlpha;
	}
}

bool Fade_IsEnable(void)
{
	return g_bIsFade;
}

void Fade_Set(SCENE_INDEX scene,int key, int frame)
{

	if (!g_bFadeEnd)
	{
		if (!Fade_IsEnable())
		{
			if (Keyboard_IsTrigger(key))
			{
				Fade_Start(true, frame);
				g_bFadeEnd = true;
			}
		}
	}
	else
	{
		if (!Fade_IsEnable())
		{
			Fade_Start(false, frame);
			Scene_Change(scene);
		}
	}
}