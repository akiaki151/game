#ifndef CAMERA_H_
#define CAMERA_H_

#include<d3dx9.h>
#include"texture.h"

void Camera_Initilize(void);
void Camera_Updata(void);
D3DXMATRIX MtxView(void);
D3DXMATRIX MtxProjection(void);
void Draw_Camera(void);
#endif // !CAMERA_H_

