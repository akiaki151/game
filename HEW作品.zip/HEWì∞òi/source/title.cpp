//=============================================================================
//
// �^�C�g���\������ [title.h]
//�G����������Ȃ�
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"scene.h"
#include"title.h"
#include"Sprite.h"
#include"input.h"
#include"sound.h"
#include "fade.h"

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
float awa_y;
float awa_x;
float awa_y2;
float awa_x2;
float awa_y3;
float awa_x3;
float awa_y4;
float awa_x4;
float awa_y5;
float awa_x5;
float awa_y6;
float awa_x6;
float awa_y7;
float awa_x7;
float awa_y8;
float awa_x8;
int flame;

bool init;

//------------------------------------
//		����������
//------------------------------------
void Title_Initialize(void)
{
	awa_y = 1000;
	awa_x = 0;
	awa_y2 = 1200;
	awa_x2 = 800;
	awa_y3 = 1200;
	awa_x3 = 900;
	awa_y4 = 1200;
	awa_x4 = 300;
	awa_y5 = 1200;
	awa_x5 = 500;
	awa_y6 = 1200;
	awa_x6 = 1000;
	awa_y7 = 1200;
	awa_x7 = 1200;
	awa_y8 = 1200;
	awa_x8 = 1500;
	flame = 0;
}

//------------------------------------
//		�I������
//------------------------------------
void Title_Finalize(void)
{

}

//------------------------------------
//		�X�V����
//------------------------------------
void Title_Update(void)
{
	flame += 1;

	awa_y -= 1.0f;
	awa_y2 -= 1.5f;
	awa_y3 -= 1.1f;
	awa_y4 -= 1.8f;
	awa_y5 -= 1.2f;
	awa_y6 -= 2.0f;
	awa_y7 -= 1.0f;
	awa_y8 -= 1.5f;

	if (awa_y < -400.0f) {
		awa_y = 1000.0f;
	}
	if (awa_y2 < -400.0f) {
		awa_y2 = 1000.0f;
	}
	if (awa_y3 < -400.0f) {
		awa_y3 = 1000.0f;
	}
	if (awa_y4 < -400.0f) {
		awa_y4 = 1000.0f;
	}
	if (awa_y5 < -400.0f) {
		awa_y5 = 1000.0f;
	}
	if (awa_y6 < -400.0f) {
		awa_y6 = 1000.0f;
	}
	if (awa_y7 < -400.0f) {
		awa_y7 = 1000.0f;
	}
	if (awa_y8 < -400.0f) {
		awa_y8 = 1000.0f;
	}


	if (init == false)
	{
		StopSound();
		PlaySound(BGM_TITLE);
		init = true;
	}


	Fade_Set(SCENE_INDEX_GAME, DIK_SPACE, 15);

}

//------------------------------------
//		�`�揈��
//------------------------------------
void Title_Draw(void)
{
	Sprite_Draw(TITLE_HAIKEI, 0, 0);
	Sprite_Draw(TITLE_LOGO, 240, 0);
	Sprite_Draw(TITLE_SAKANA1, 460, 370);
	if (flame % 100 == 15) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 16) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 17) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 18) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 19) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 20) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 21) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 == 19) {
		Sprite_Draw(TITLE_SAKANA2, 460, 370);
	}
	if (flame % 100 < 80) {
		Sprite_Draw(PRESS_START, 520, 700);
	}
	Sprite_Draw(AWA, awa_x, awa_y);
	Sprite_Draw(AWA, awa_x2, awa_y2);
	Sprite_Draw(AWA, awa_x3, awa_y3);
	Sprite_Draw(AWA, awa_x4, awa_y4);
	Sprite_Draw(AWA, awa_x5, awa_y5);
	Sprite_Draw(AWA, awa_x6, awa_y6);
	Sprite_Draw(AWA, awa_x7, awa_y7);
	Sprite_Draw(AWA, awa_x8, awa_y8);

}

void AllInitialize()
{

}
