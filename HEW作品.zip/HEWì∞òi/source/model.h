/*================================================================

�|���S��[blender.h]
Author : Akihiro Makino
Date   : 2018/10/19
------------------------------------------------------------------
================================================================*/
#ifndef BLENDER_H_
#define BLENDER_H_
#include<d3dx9.h>
#define MATERIAL_INDEX_MAX (64)

enum
{
	HUNE,
	MAGURO1,
	MAGURO2,
	MAGURO3,
	MAGURO4,
	MAGURO5,
	MAGURO6,
	MANTA_1,
	MANTA_2,
	MANTA_3,
	MANTA_4,
	MANTA_5,
	MANTA_6,
	TITLE_MODEL,
	SAME_1,
	SAME_2,
	SAME_3,
	SAME_4,
	SAME_5,
	SAME_6,
	SAO,
	SAO_REAL,
	SAO_REAL2,
	UKI,
	MODEL_MAX,
};

typedef struct ModelFile_tag
{
	char filename[MATERIAL_INDEX_MAX]; // �e�N�X�`���t�@�C����
} ModelFile;


void Model_XFile(int index);
void Model_Finalize(int index);
void Model_Draw(int index, D3DXMATRIX Warld);


#endif // !BLENDER_H_