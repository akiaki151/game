#include"wave2.h"
#define FVF_MESHFIELD_VERTEX3D (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)	//	�\���̂̂������ɏ���

LPDIRECT3DVERTEXBUFFER9 g_vb2 = NULL;
LPDIRECT3DINDEXBUFFER9 pD3DIBuffer2;
DWORD *pIndex2;

int index_number2[20000];

Wave2::Wave2(int TATE, int YOKO) {

	wave_channel = 0;
	//1���
	for (int i = 0; i < YOKO; i++) {
		index_number2[i * 2] = YOKO + i;
	}
	for (int i = 0; i < YOKO; i++) {
		index_number2[i * 2 + 1] = i;
	}
	index_number2[YOKO * 2] = YOKO - 1;

	//�Q��ڈȍ~
	for (int i = 0; i < TATE; i++) {
		index_number2[YOKO * 2 * (i + 1) + 1 + i * 2] = YOKO * (2 + i);
		for (int j = 0; j < YOKO; j++) {
			index_number2[j * 2 + YOKO * 2 * (1 + i) + 2 * (1 + i)] = YOKO * (i + 2) + j;
		}
		index_number2[YOKO * (4 + 2 * i) + 2 * (1 + i)] = YOKO * (2 + i) - 1;
	}

	for (int i = 0; i < TATE - 1; i++) {
		for (int j = 0; j < YOKO; j++) {
			index_number2[j * 2 + YOKO * 2 * (1 + i) + 3 + (2 * i)] = YOKO * (1 + i) + j;
		}
	}

	//�f�o�C�X
	LPDIRECT3DDEVICE9 g_pD3DDevice = MyDirect3D_GetDevice();
	//���_�o�b�t�@
	g_pD3DDevice->CreateVertexBuffer(
		30000 * sizeof(MeshfieldVertex3D2),
		D3DUSAGE_WRITEONLY,
		FVF_MESHFIELD_VERTEX3D,
		D3DPOOL_MANAGED,
		&g_vb2,
		NULL);

	g_vb2->Lock(0, 0, (void**)&v, 0);

	for (int i = 0; i <= TATE; i++) {
		for (int j = 0; j <= YOKO; j++) {
			v[i*TATE + j].pos = D3DXVECTOR3(j - (YOKO * 0.5f), 0, -i + 45.0f) * 3.0f;
			if (i % 3 == 0) {
				v[i*TATE + j].color = 0x0000ffff;
			}
			if (i % 3 == 1) {
				v[i*TATE + j].color = 0x1090ffff;
			}
			if (i % 3 == 2) {
				v[i*TATE + j].color = 0x10ffffff;
			}
		}
	}
	g_TATE = TATE;
	g_YOKO = YOKO;
	g_vb2->Unlock();
	g_pD3DDevice->SetStreamSource(0, g_vb2, 0, sizeof(MeshfieldVertex3D2));

	WORD *pIndex;
	g_pD3DDevice->CreateIndexBuffer(
		30000 * sizeof(WORD),
		D3DUSAGE_WRITEONLY,
		D3DFMT_INDEX16,
		D3DPOOL_MANAGED,
		&pD3DIBuffer2,
		NULL);

	pD3DIBuffer2->Lock(0, 0, (LPVOID*)&pIndex, 0);
	for (int i = 0; i < 30000; i++)
	{
		pIndex[i] = index_number2[i];
	}
	pD3DIBuffer2->Unlock();
}

Wave2::~Wave2() {
	g_vb2->Release();
	g_vb2 = NULL;
	pD3DIBuffer2->Release();
	pD3DIBuffer2 = NULL;
}

void Wave2::Water_Update2(void) {
	//���_�o�b�t�@
	g_vb2->Lock(0, 0, (void**)&v, 0);
	for (int i = 0; i <= g_TATE; i++) {
		for (int j = 0; j <= g_YOKO; j++) {
			for (int k = 0; k < MAX_WAVE2; k++) {
				v[i*g_TATE + j].WaveDelay[k] -= 0.06f;
				if (v[i*g_TATE + j].WaveDelay[k] <= 0) {
					//v[i*g_TATE + j].pos.y = WaveSize*v[i*g_TATE + j].WaveDecay*sin(v[i*g_TATE + j].WaveDelay);
					v[i*g_TATE + j].WaveHeight[k] = WaveSize[k] * v[i*g_TATE + j].WaveDecay[k] * cos(v[i*g_TATE + j].WaveDelay[k]);
				}
				if (WaveSize[k] == 0.0f) {
					if (v[i*g_TATE + j].pos.y > 0.00001f) {
						v[i*g_TATE + j].pos.y -= 0.00001f;
					}
					if (v[i*g_TATE + j].pos.y < 0.00001f) {
						v[i*g_TATE + j].pos.y += 0.00001f;
					}
				}
			}
		}
	}
	for (int i = 0; i <= g_TATE; i++) {
		for (int j = 0; j <= g_YOKO; j++) {
			for (int k = 0; k < MAX_WAVE2; k++) {
				v[i*g_TATE + j].pos.y += v[i*g_TATE + j].WaveHeight[k];
			}
		}
	}
	g_vb2->Unlock();
	for (int k = 0; k < MAX_WAVE2; k++) {
		if (WaveSize[k] > 0) {
			if (g_Infinite[k] == 0) {
				WaveSize[k] -= 0.00001f;
			}
		}
		else if (WaveSize[k] < 0) {
			WaveSize[k] = 0.0f;
		}
	}
}

void Wave2::Water_Draw2(void) {	/* ���C�g�̐ݒ� */
	LPDIRECT3DDEVICE9 g_pD3DDevice = MyDirect3D_GetDevice();
	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);

	D3DXMATRIX mtxWorld_Mesh[MAX_MESH];		// 4*4�s��@d3dx9.h�K�v

	for (int i = 0; i < MAX_MESH; i++)
	{
		D3DXMatrixIdentity(&mtxWorld_Mesh[i]);
	}
	//	���[���h�ϊ��s��ݒ�
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &mtxWorld_Mesh[0]);

	g_pD3DDevice->SetStreamSource(0, g_vb2, 0, sizeof(MeshfieldVertex3D2));
	g_pD3DDevice->SetIndices(pD3DIBuffer2);
	g_pD3DDevice->SetFVF(FVF_MESHFIELD_VERTEX3D);		//	FVF���f�o�C�X�ɐݒ�
	g_pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLESTRIP, 0, 0, 40000, 0, 18000);
}

void Wave2::Water_Begin2(int x, int z, float wavesize, int infinite) {
	if (wave_channel < MAX_WAVE2) {
		wave_channel += 1;
	}
	if (g_Infinite[wave_channel] == 1) {
		wave_channel += 1;
	}
	if (wave_channel == MAX_WAVE2) {
		wave_channel = 0;
	}
	WaveSize[wave_channel] = wavesize;
	g_vb2->Lock(0, 0, (void**)&v, 0);
	for (int i = 0; i <= g_TATE; i++) {
		for (int j = 0; j <= g_YOKO; j++) {
			v[i*g_TATE + j].WaveDelay[wave_channel] = sqrt((v[i*g_TATE + j].pos.x - x)*(v[i*g_TATE + j].pos.x - x) + (v[i*g_TATE + j].pos.z - z)*(v[i*g_TATE + j].pos.z - z));
			v[i*g_TATE + j].WaveDecay[wave_channel] = 8.0f - v[i*g_TATE + j].WaveDelay[wave_channel] * 0.03;
			if (v[i*g_TATE + j].WaveDecay[wave_channel] <= 0.0f) {
				v[i*g_TATE + j].WaveDecay[wave_channel] = 0.0f;
			}
		}
	}
	g_vb2->Unlock();
}