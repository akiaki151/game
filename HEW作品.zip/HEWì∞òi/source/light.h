#ifndef LIGHT_H_
#define LIGHT_H_

#include"texture.h"
//void Light_Initilize(void);
//void Light_Finalize(void);
void Light_SetLight(void);
//void Light_Draw(void);

#endif // !LIGHT_H_

