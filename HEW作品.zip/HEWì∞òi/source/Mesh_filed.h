/*==============================================================================

���b�V���t�B�[���h�`�� [mesh_filed.h]

==============================================================================*/
/*================================================================

�|���S��[blender.h]
Author : Akihiro Makino
Date   : 2018/10/19
------------------------------------------------------------------
================================================================*/
#ifndef MESH_FILED_H_
#define MESH_FILED_H_
#define MeshFiled_X (5)
#define MeshFiled_Z (5)
#define MeshWall_X  (150.0f)
#define MeshWall_Z  (150.0f)
void Mesh_Field_Initialize(float meshW, int meshXnum, int meshZnum);
void Mesh_Cylinder_Initialize(float meshH, float radius, int meshXnum, int meshYnum);
void Mesh_Skydome_Initialize(float meshH, float radius, int meshXnum, int meshYnum);
void Mesh_Wall_Initialize1(float gridsizex, float gridsizez, int gridcntx, int gridcntz);
void Mesh_Wall_Initialize2(float gridsizex, float gridsizez, int gridcntx, int gridcntz);
void Mesh_Wall_Initialize3(float gridsizex, float gridsizez, int gridcntx, int gridcntz);
void Mesh_Wall_Initialize4(float gridsizex, float gridsizez, int gridcntx, int gridcntz);
void Mesh_Field_Finalize(void);
void Mesh_Field_Draw(int index);
float Mesh_Pos(int n);
#endif // !MESH_FILED_H_