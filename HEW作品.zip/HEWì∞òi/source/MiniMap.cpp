#include "MiniMap.h"
#include "Mesh_filed.h"
#include "sprite.h"
#include "Player.h"
#include "enemy.h"
#include "common.h"
#include <d3dx9.h>

// �͈͂́}��2�{
static  float g_stageWidth = MeshWall_X * 2.0f;
static  float g_stageHeight = MeshWall_Z * 2.0f;

// �O���[�o���ϐ�(�̂���private�����o)
static int g_MiniMapWidth;
static int g_MiniMapHeight;
static D3DXVECTOR2 PlayerPos;
static D3DXVECTOR2 *EnemyPos = NULL;

void Minimap_Initialize()
{
	g_MiniMapWidth = g_stageWidth;
	g_MiniMapHeight = g_stageHeight;
	ENEMY* enemy = Enemy_GetData();
	EnemyPos = new D3DXVECTOR2[ENEMY_MAX];
	for (int i = 0; i < ENEMY_MAX; i++)
	{
		EnemyPos[i].x = enemy[i].EnemyPos.x + MeshWall_X;
		EnemyPos[i].y = -(enemy[i].EnemyPos.z - MeshWall_Z);
	}
}

// �������
void Minimap_Finalize()
{
	if (EnemyPos) {
		delete[] EnemyPos;
		EnemyPos = NULL;
	}
}

// �X�V����
void Minimap_Update()
{
	// ���[��ϊ��ς�
	PlayerPos = D3DXVECTOR2(Player_Pos().x + MeshWall_X, -(Player_Pos().z - MeshWall_Z));
	// MiniMap�`��p�ɍĕϊ�realall:mapall=realpos:mappos     mapall*realpos=realall*mappos  mapall*realpos/realall=mappos
	PlayerPos.x *= 250 / g_stageWidth;
	PlayerPos.y *= 250 / g_stageHeight;

	// �G�l�~�[����
	ENEMY* enemy = Enemy_GetData();
	if (EnemyPos) {
		delete[] EnemyPos;
		EnemyPos = NULL;
	}
	EnemyPos = new D3DXVECTOR2[ENEMY_MAX];
	for (int i = 0; i < ENEMY_MAX; i++)
	{
		EnemyPos[i].x = enemy[i].EnemyPos.x + MeshWall_X;
		EnemyPos[i].y = -(enemy[i].EnemyPos.z - MeshWall_Z);
		EnemyPos[i].x *= 250 / g_stageWidth;
		EnemyPos[i].y *= 250 / g_stageHeight;
	}

}

// �`�揈��
void Minimap_Draw()
{
	// �~�j�}�b�v�̕`��J�n�n�_�̐ݒ�
	float EntryPointX = SCREEN_WIDTH - g_stageWidth;
	float EntryPointY = 0;

	// �~�j�}�b�v�̖{��
	Sprite_Draw(RADER, EntryPointX, EntryPointY);

	// �v���C���[�̕`��
	Sprite_Draw(PCURSOL, PlayerPos.x + EntryPointX - 12.5f, PlayerPos.y + EntryPointY - 12.5f, 0, 0, 25.0f, 25.0f, 12.5f, 12.5f, 1.0f, 1.0f, Player_2DRot() / 180 * 3.14);

	// ���ǂ��̕`��
	for (int i = 0; i < ENEMY_MAX; i++)
	{
		Sprite_Draw(FISH, EnemyPos[i].x + EntryPointX - 12.5f, EnemyPos[i].y + EntryPointY - 12.5f);
	}
}
