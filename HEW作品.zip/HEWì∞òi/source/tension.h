#ifndef TENSION_H
#define TENSION_H

void Tension_Init();
void Tension_Update();
void Tension_Draw(float currentPoint);
void Tension_Uninit();

#endif // !TENSION_H
