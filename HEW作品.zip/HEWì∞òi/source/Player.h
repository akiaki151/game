//=============================================================================
//
// �v���C���[���� [player.h]
//
//=============================================================================
#ifndef PLAYER_H_
#define PLAYER_H_
#include<d3dx9.h>
#include "collision.h"
//------------------------------------
//		�}�N��
//------------------------------------
#define PLAYER_FRONT_SPEED (0.003f)
#define PLAYER_BACK_SPEED (0.0002f)
#define PLAYER_JUMP_SPEED (0.30f)

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Player_Initialize(void);
void Player_Update(void);
void Player_Update2(void);
void Player_Move(void);
D3DXVECTOR3 MTXR_FROANT(void);
D3DXVECTOR3 Player_Pos(void);
D3DXMATRIX Player_Rot(void);
void Player_Draw(void);
void Player_Draw2(void);
int Sakana_Get(void);
D3DXMATRIX Model_Rot(void);
void Player_Wave_Y(void);
float Player_2DRot(void);
bool Turi_State(void);
bool Turi_Batlle(void);
D3DXMATRIX Uki_pos(void);
const SphreCollision*Player_GetCircleCollision();//���ł̓����蔻��
int Damage(void);
#endif //PLAYER_H_