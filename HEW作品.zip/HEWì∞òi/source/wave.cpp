#include"wave.h"
#define FVF_MESHFIELD_VERTEX3D (D3DFVF_XYZ|D3DFVF_DIFFUSE|D3DFVF_TEX1)	//	�\���̂̂������ɏ���

LPDIRECT3DVERTEXBUFFER9 g_vb = NULL;
LPDIRECT3DINDEXBUFFER9 pD3DIBuffer;
DWORD *pIndex;

int index_number[20000];

Wave::Wave(int TATE, int YOKO) {

	wave_channel = 0;
	//1���
	for (int i = 0; i < YOKO; i++) {
		index_number[i * 2] = YOKO + i;
	}
	for (int i = 0; i < YOKO; i++) {
		index_number[i * 2 + 1] = i;
	}
	index_number[YOKO * 2] = YOKO - 1;

	//�Q��ڈȍ~
	for (int i = 0; i < TATE; i++) {
		index_number[YOKO * 2 * (i + 1) + 1 + i * 2] = YOKO * (2 + i);
		for (int j = 0; j < YOKO; j++) {
			index_number[j * 2 + YOKO * 2 * (1 + i) + 2 * (1 + i)] = YOKO * (i + 2) + j;
		}
		index_number[YOKO * (4 + 2 * i) + 2 * (1 + i)] = YOKO * (2 + i) - 1;
	}

	for (int i = 0; i < TATE - 1; i++) {
		for (int j = 0; j < YOKO; j++) {
			index_number[j * 2 + YOKO * 2 * (1 + i) + 3 + (2 * i)] = YOKO * (1 + i) + j;
		}
	}

	//�f�o�C�X
	LPDIRECT3DDEVICE9 g_pD3DDevice = MyDirect3D_GetDevice();
	//���_�o�b�t�@
	g_pD3DDevice->CreateVertexBuffer(
		30000 * sizeof(MeshfieldVertex3D),
		D3DUSAGE_WRITEONLY,
		FVF_MESHFIELD_VERTEX3D,
		D3DPOOL_MANAGED,
		&g_vb,
		NULL);

	g_vb->Lock(0, 0, (void**)&v, 0);

	for (int i = 0; i <= TATE; i++) {
		for (int j = 0; j <= YOKO; j++) {
			v[i*TATE + j].pos = D3DXVECTOR3(j - (YOKO * 0.5f), 0, -i + 45.0f) * 3.0f;
			if (i % 3 == 0) {
				v[i*TATE + j].color = 0x0000ffff;
			}
			if (i % 3 == 1) {
				v[i*TATE + j].color = 0x0090ffff;
			}
			if (i % 3 == 2) {
				v[i*TATE + j].color = 0x00ffffff;
			}
		}
	}
	g_TATE = TATE;
	g_YOKO = YOKO;
	g_vb->Unlock();
	g_pD3DDevice->SetStreamSource(0, g_vb, 0, sizeof(MeshfieldVertex3D));

	WORD *pIndex;
	g_pD3DDevice->CreateIndexBuffer(
		30000 * sizeof(WORD),
		D3DUSAGE_WRITEONLY,
		D3DFMT_INDEX16,
		D3DPOOL_MANAGED,
		&pD3DIBuffer,
		NULL);

	pD3DIBuffer->Lock(0, 0, (LPVOID*)&pIndex, 0);
	for (int i = 0; i < 30000; i++)
	{
		pIndex[i] = index_number[i];
	}
	pD3DIBuffer->Unlock();
}

Wave::~Wave() {
	g_vb->Release();
	g_vb = NULL;
	pD3DIBuffer->Release();
	pD3DIBuffer = NULL;
}

void Wave::Water_Update(void) {
	//���_�o�b�t�@
	g_vb->Lock(0, 0, (void**)&v, 0);
	for (int i = 0; i <= g_TATE; i++) {
		for (int j = 0; j <= g_YOKO; j++) {
			for (int k = 0; k < MAX_WAVE; k++) {
				v[i*g_TATE + j].WaveDelay[k] -= 0.06f;
				if (v[i*g_TATE + j].WaveDelay[k] <= 0) {
					//v[i*g_TATE + j].pos.y = WaveSize*v[i*g_TATE + j].WaveDecay*sin(v[i*g_TATE + j].WaveDelay);
					v[i*g_TATE + j].WaveHeight[k] = WaveSize[k] * v[i*g_TATE + j].WaveDecay[k] * cos(v[i*g_TATE + j].WaveDelay[k]);
				}
				if (WaveSize[k] == 0.0f) {
					if (v[i*g_TATE + j].pos.y > 0.00001f) {
						v[i*g_TATE + j].pos.y -= 0.00001f;
					}
					if (v[i*g_TATE + j].pos.y < 0.00001f) {
						v[i*g_TATE + j].pos.y += 0.00001f;
					}
				}
			}
		}
	}
	for (int i = 0; i <= g_TATE; i++) {
		for (int j = 0; j <= g_YOKO; j++) {
			for (int k = 0; k < MAX_WAVE; k++) {
				v[i*g_TATE + j].pos.y += v[i*g_TATE + j].WaveHeight[k];
			}
		}
	}
	g_vb->Unlock();
	for (int k = 0; k < MAX_WAVE; k++) {
		if (WaveSize[k] > 0) {
			if (g_Infinite[k] == 0) {
				WaveSize[k] -= 0.00001f;
			}
		}
		else if (WaveSize[k] < 0) {
			WaveSize[k] = 0.0f;
		}
	}
}

void Wave::Water_Draw(void) {	/* ���C�g�̐ݒ� */
	LPDIRECT3DDEVICE9 g_pD3DDevice = MyDirect3D_GetDevice();
	g_pD3DDevice->SetRenderState(D3DRS_LIGHTING, FALSE);

	D3DXMATRIX mtxWorld_Mesh[MAX_MESH];		// 4*4�s��@d3dx9.h�K�v

	for (int i = 0; i < MAX_MESH; i++)
	{
		D3DXMatrixIdentity(&mtxWorld_Mesh[i]);
	}
	//	���[���h�ϊ��s��ݒ�
	g_pD3DDevice->SetTransform(D3DTS_WORLD, &mtxWorld_Mesh[0]);

	g_pD3DDevice->SetStreamSource(0, g_vb, 0, sizeof(MeshfieldVertex3D));
	g_pD3DDevice->SetIndices(pD3DIBuffer);
	g_pD3DDevice->SetFVF(FVF_MESHFIELD_VERTEX3D);		//	FVF���f�o�C�X�ɐݒ�
	g_pD3DDevice->DrawIndexedPrimitive(D3DPT_TRIANGLESTRIP, 0, 0, 40000, 0, 18000);
}

void Wave::Water_Begin(int x, int z, float wavesize, int infinite) {
	if (wave_channel < MAX_WAVE) {
		wave_channel += 1;
	}
	if (g_Infinite[wave_channel] == 1) {
		wave_channel += 1;
	}
	if (wave_channel == MAX_WAVE) {
		wave_channel = 0;
	}
	WaveSize[wave_channel] = wavesize;
	g_vb->Lock(0, 0, (void**)&v, 0);
	for (int i = 0; i <= g_TATE; i++) {
		for (int j = 0; j <= g_YOKO; j++) {
			v[i*g_TATE + j].WaveDelay[wave_channel] = sqrt((v[i*g_TATE + j].pos.x - x)*(v[i*g_TATE + j].pos.x - x) + (v[i*g_TATE + j].pos.z - z)*(v[i*g_TATE + j].pos.z - z));
			v[i*g_TATE + j].WaveDecay[wave_channel] = 8.0f - v[i*g_TATE + j].WaveDelay[wave_channel] * 0.03;
			if (v[i*g_TATE + j].WaveDecay[wave_channel] <= 0.0f) {
				v[i*g_TATE + j].WaveDecay[wave_channel] = 0.0f;
			}
		}
	}
	g_vb->Unlock();
}