#ifndef ENEMY_H_
#define ENEMY_H_
//=============================================================================
//
// �v���C���[���� [enemy.h]
//
//=============================================================================
#include "collision.h"
#include<d3dx9.h>
enum
{
	SAKANA_MAGURO,
	SAKANA_SAME=8,
	SAKANA_MANTA=9,
	SAKANA_MAX,
};
#define ENEMY_MAX (13) //1��ނɑ΂��鋛�̐�
typedef struct enemy
{
	D3DXVECTOR3 EnemySpeed;
	D3DXVECTOR3 EnemyPos;
	D3DXVECTOR3 front;
	D3DXVECTOR3 side;
	D3DXVECTOR3 height;
	D3DXMATRIX Trans;
	D3DXMATRIX mtxR;
	D3DXMATRIX mtxR2;
	D3DXMATRIX Rot;
	D3DXMATRIX mtxR_Enemy;
	D3DXMATRIX WARLD;
	SphreCollision Enemy_collision;
}ENEMY;

void Enemy_Initialize(void);
void Enemy_Initialize2(void);
void Enemy_Updata(void);
void Enemy_Updata2(void);
void Enemy_Draw(void);
void Enemy_Draw2(void);
void Same_Anime(void);
void Maguro_Anime(void);
void Manta_Anime(void);
void Same_Anime2(void);
void Maguro_Anime2(void);
void Manta_Anime2(void);
const SphreCollision*Enemy_GetCircleCollision(int index);
ENEMY* Enemy_GetData();
void Enemy_GetNum();
int Get_Score2(void);
#endif //Enemy_H_