//=============================================================================
//
// �Q�[������ [game.cpp]
//
//=============================================================================
/*------------------------------------------------------------------------------
   �֐���`
------------------------------------------------------------------------------*/
#include"camera.h"
#include"model.h"
#include"light.h"
#include"Mesh_filed.h"
#include"billborad.h"
#include"Player.h"
#include"wave.h"
#include"MiniMap.h"
#include"enemy.h"
#include"scene.h"
Wave *wave;
// �Q�[���̏�����
void Game_Initialize(void)
{
	Enemy_Initialize();
	Camera_Initilize();
	Light_SetLight();
	Mesh_Skydome_Initialize(10.0f, 350.0f, 20, 20);
	Mesh_Cylinder_Initialize(10.0f, 200.0f, 5, 2);
	Mesh_Field_Initialize(50.0f, MeshFiled_X, MeshFiled_Z);
	wave =new Wave(100, 100);
	wave->Water_Begin(-10,0,0.006,1);
	Player_Initialize();
	Minimap_Initialize();
	for (int i = 0; i < MODEL_MAX; i++)
	{
		Model_XFile(i);
	}
	Bilboard_Initialize();
}
// �Q�[���̏I������
void Game_Finalize(void)
{
	Mesh_Field_Finalize();
	for (int i = 0; i < MODEL_MAX; i++)
	{
		Model_Finalize(i);
	}
	Bilboard_Finalize();
	Minimap_Finalize();
}
// �Q�[���̍X�V
void Game_Update(void)
{
	Enemy_Updata();
	Camera_Updata();
	Player_Update();
	wave->Water_Update();
	Bilboard_Update();
	Minimap_Update();
}
// �Q�[���̕`��
void Game_Draw(void)
{
	Mesh_Field_Draw(0);
	Mesh_Field_Draw(1);
	Mesh_Field_Draw(2);
	Draw_Camera();
	Player_Draw();
	Enemy_Draw();
	wave->Water_Draw();
	Minimap_Draw();
}