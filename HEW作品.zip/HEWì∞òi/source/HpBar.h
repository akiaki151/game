#ifndef BAR_H
#define BAR_H

void HpBar_Init(float startPoint);
void HpBar_Update();
void HpBar_Draw(float currentPoint);
void HpBar_Uninit();


#endif // !BAR_H
