//=============================================================================
//
// ���U���g�\������ [result.h]
//
//=============================================================================

#ifndef RESULT_H_
#define RESULT_H_

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Ranking(void);
void Result_Initialize(void);
void Result_Finalize(void);
void Result_Update(void);
void Result_Draw(void);
#endif //!RESULT_H_

