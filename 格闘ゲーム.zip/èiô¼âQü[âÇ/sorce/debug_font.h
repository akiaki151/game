//=============================================================================
//
// �f�o�b�N���� [debug_font.h]
//
//=============================================================================
#ifndef DEBUG_H
#define DEBUG_H

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void DebugFont_Initialize(void);
void DebugFont_Finalize(void);
void DebugFont_Draw(void);
void DebugFont_Draw2(void);
#endif	//DEBUG_H