//=============================================================================
//
// �v���C���[���� [enemy.h]
//
//=============================================================================
#ifndef ENEMY_H_
#define ENEMY_H_

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"collision.h"
#define _USE_MATH_DEFINES
#include <math.h>

//------------------------------------
//		�}�N��
//------------------------------------
#define ENEMY_MOVE_SPEED (0.6f)
#define ENEMY_GRAVITY (10.0f)

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Enemy_Initialize(void);
void Enemy_Update(void);
void Enemy_Draw(void);

void Enemy_Back_texture(void);

void Enemy_panchi(void);
void Enemy_Jump(void);
void Enemy_vector(void);
void Enemy_Guard(void);
void Enemy_Right_Chara(void);
void Enemy_Left_Chara(void);
void Enemy_waza(void);

void Enemy_Destroy(int index);

const Circle*Enemy_GetCircleCollision(void);

int e_move_x(void);
int e_move_y(void);
int E_Motionpattern(void);
int Enemy_Judge(void);
int Enemy_deth(void);
int Enemy_Hp_End(void);
int Enemy_Hp(void);
int Enemy_Waza_Number(void);
int END_Enemy(void);
int Trance_Enemy(void);
int ENEMY_ORIENT(void);
#endif //ENEMY_H_