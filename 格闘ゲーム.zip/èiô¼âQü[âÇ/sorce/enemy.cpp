//=============================================================================
//
// �v���C���[���� [player.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include "texture.h"
#include "sprite.h"
#include "enemy.h"
#include "input.h"
#include "common.h"
#include "collision.h"
#include "debug_primitive.h"
#include "title.h"
#include "bullet.h"
#include "motion.h"
#include "judgement.h"
#include "Score.h"
#include "sound.h"
#include "effect.h"
#include "name.h"
#include "player.h"

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------

//�G�l�~�[�̈ړ����W
static float g_EnemyX;
static float g_EnemyY;
static float g_EnemyWidth;
static float g_EnemyHeight;
D3DXVECTOR2 g_EnemySpeed(0.0f, 0.0f);


//�G�l�~�[�̗̑�
static int enemy_life = 2;
static bool e_deth_my;
static bool e_hp_e_end;
static float hp_enemy = 0;

//����
static int e_orientation = 0;
//�L�����ړ��t���[��
static int enemy_e_frame = 0;
//�ړ��t���[����
static int e_frame = 0;

//�L�����K�[�h�t���[��
static int enemy_e_frame_g = 0;
//�L�����K�[�h�t���[����
static int e_frame_g = 0;
//�K�[�h����
static bool G_e_motion = false;
//�w�i�X�N���[��
static float scroll_x = 0.0f;
//�W�����v����
static int e_cnt_jump = 0;
//�W�����v����]
static float e_cnt_j = 0.0f;
//�W�����v�̍����t���[��
static int e_jump_up = 0;
//�W�����v�J�E���g
static int e_scroll_j = 0;
//�Z���
static int e_pattern = 0;
//�Z�̃��X�^�C��
static bool e_motion = false;

static bool e_judge = false;

//��
static int scroll = 0;
//����
static float scroll_D = 0.0f;

Circle g_enemy;       //�o���b�g�̓����蔻��R���W����

static int e_waza_number;
static bool e_end = false;

//�t������������
static int motion_chara;
static int scroll_chara;
static int waza_hantei = 0;
static float muteki = 0;
static int life = 0;
static int i = 0;
static bool end = false;

static bool trans_player = false;
static int c = 0;
static int d = 0;

static bool e_trans = false;
static bool enemy_end_waza = false;
static bool enemy_waza_end = false;

static bool e_trans_judge = false;

static bool e_panchi_judge = false;
static bool e_panchi_S_judge = false;
static bool dark_judge = false;
static bool e_jump_judge = false;

static bool e_huttobi = false;
static bool e_judge_huttobi;

static int enemy_AI = 0;
static bool enemy_AI_Judge = false;
static int AI_count = 0;
static int AI_frame = 0;
//------------------------------------
//		����������
//------------------------------------
void Enemy_Initialize(void) {
	g_EnemySpeed = D3DXVECTOR2(0.0f, 0.0f);
	g_EnemyX = 1200;
	g_EnemyY = 650;
	g_EnemyWidth = Texture_GetWidth(kTEXTURE_INDEX_MY2);
	g_EnemyHeight = Texture_GetHeight(kTEXTURE_INDEX_MY2);
	e_orientation = 1;
	enemy_e_frame = 0;
	g_enemy.Centerx = 0.0f;
	g_enemy.Centery = 0.0f;
	g_enemy.Radious = 50;
	scroll_x = 0.0f;
	e_frame = 0;
	e_cnt_jump = 2;
	e_cnt_j = 0.0f;
	G_e_motion = false;
	scroll = 0;
	e_pattern = 0;
	e_motion = false;
	e_judge = false;
	e_deth_my = false;
	e_frame_g = 0;
	enemy_e_frame_g = 0;
	scroll_D = 0.0f;
	enemy_life = 2;
	e_hp_e_end = false;
	e_waza_number = 0;
	e_jump_up = 0;
	e_scroll_j = 0;
	//�t������������
	motion_chara = 0;
	scroll_chara = 0;
	waza_hantei = 0;
	muteki = 0;
	life = 0;
	i = 0;
	end = false;
	hp_enemy = 0;
	trans_player = false;
	c = 0;
	d = 0;
	e_trans = false;
	enemy_end_waza = false;
	enemy_waza_end = false;
	e_trans_judge = false;
	e_panchi_judge = false;
	e_panchi_S_judge = false;
	dark_judge = false;
	e_jump_judge = false;
	e_huttobi = false;
	e_judge_huttobi=false;
	enemy_AI = 0;
	enemy_AI_Judge = false;
	AI_count = 0;
	AI_frame = 0;
}

//------------------------------------
//		�X�V����
//------------------------------------
void Enemy_Update(void) {


	//�d��
	if (g_EnemyX < 330.f || g_EnemyX > 1320.f || g_EnemyY != 650.f)
	{
		g_EnemyY += ENEMY_GRAVITY;
	}
	else
	{
		e_cnt_jump = 2;
	}
	//�G�l�~�[��AI������������
	if (!Mode_Select())
	{

		if (g_EnemyX > 1100)
		{
			enemy_AI_Judge = false;
		}
		if (g_EnemyX < 500)
		{
			enemy_AI_Judge = true;
		}

		if (g_EnemyY > 650)
		{
			enemy_AI = 5;//�W�����v
		}

		if (enemy_AI_Judge&&enemy_AI ==0)
		{
			enemy_AI = 4;//�ړ�
		}
		if (!enemy_AI_Judge&&enemy_AI != 1 && enemy_AI != 2 && Waza_hantei() != 2 && enemy_AI == 0)
		{
			enemy_AI = 3;//�ړ�
		}

		if (g_EnemyX > move_x())
		{
			e_orientation = 1;
			if (g_EnemyX - move_x() >= 600 && g_EnemyY == 650 && Waza_hantei() != 2)
			{
				enemy_AI = 1;//�����Z
				Enemy_waza();
			}
			else if (g_EnemyX - move_x() <= 100 && Waza_hantei() != 2)
			{
				if (AI_frame % 2 == 0)
					enemy_AI = 2;//�p���`
				else
					enemy_AI = 7;//�p���`
				Enemy_panchi();
				AI_frame++;
			}
		}
		else if (g_EnemyX < move_x())
		{
			e_orientation = 0;
			if (move_x() - g_EnemyX >= 600 && g_EnemyY == 650 && Waza_hantei() != 2)
			{
				enemy_AI = 1;//�����Z
				Enemy_waza();
			}
			else if (move_x() - g_EnemyX <= 100 && Waza_hantei() != 2)
			{
				if(AI_frame%5==0)
				enemy_AI = 7;//�p���`
				else
				enemy_AI = 2;//�p���`
				Enemy_panchi();
				AI_frame++;
			}
		}
		
		if (AI_count > 5)
		{
			AI_count = 0;
		}

		if (AI_count > 3)
		{
			e_trans = true;
		}
		else 
		{
			e_trans = false;
		}
	}



	//��������2P
	XINPUT_STATE state;
	XInputGetState(1, &state);
	
	//�w�i�X�N���[��
	scroll_x += 1.0f;
	if (e_orientation)
		scroll_D -= 0.05f;
	else
		scroll_D += 0.05f;
	scroll = (int)(scroll_x / 16) % 3;


	scroll_chara++;
	motion_chara = (scroll_chara / 16);

	trans_player=Trance_Player();

	//�_���[�W���󂯂ĂȂ��Ȃ��
	if (waza_hantei == 0)
	{
		//�ړ�
		Enemy_vector();

		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_X)
		{
			//�p���`
			Enemy_panchi();
		}

		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y)
		{
			//���U��
			Enemy_waza();
		}
		if (!(state.Gamepad.wButtons & XINPUT_GAMEPAD_X) && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_Y))
		{
			e_panchi_judge = false;
			e_panchi_S_judge = false;
			dark_judge = false;
			e_jump_judge = false;
		}
		//�W�����v
		Enemy_Jump();
		//�K�[�h
		Enemy_Guard();
	}
	else if(waza_hantei == 1)
	{
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT || state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT||state.Gamepad.wButtons & state.Gamepad.wButtons & XINPUT_GAMEPAD_A&&waza_hantei != 4)
		{
			waza_hantei = 0;
		}

	} 


	e_motion = E_Motion_End();

	if (!e_motion)
	{
		e_pattern = 0;
		e_waza_number = 0;
		enemy_AI = 0;
	}

	if (g_EnemyY>1300.f || g_EnemyY<-800.f || g_EnemyX>2500.f || g_EnemyX<-1100.f && !e_deth_my)
	{
		e_waza_number = 0;
		if (e_orientation == 0)
			e_orientation = 1;

		if (enemy_life == 2)
		{
			enemy_life = 1;
			e_deth_my = true;
			E_Effect_Create(1480, 160);
			hp_enemy = 0;
			e_waza_number = 0;
			E_Deth_chara(e_deth_my);
		}
		else if (enemy_life == 1)
		{
			e_deth_my = true;
			E_Effect_Create(1440, 160);
			enemy_life = 0;
			hp_enemy = 0;
			e_waza_number = 0;
			E_Deth_chara(e_deth_my);
		}
		else if (enemy_life == 0)
		{
			end = true;
		}
	}
	if (e_deth_my)
	{
		g_EnemyX = 1200.f;
		g_EnemyY = 650.f;
		e_deth_my = false;
	}


	//�t������������
	if (motion_chara > 3)
	{
		waza_hantei = 0;
	}
	if ((int)muteki >= 10)
	{
		if (motion_chara < 8)
			waza_hantei = 2;
		else
		{
			waza_hantei = 0;
			muteki = 0.0f;
		}
	}
	if (waza_hantei >= 3)
	{
		if (motion_chara < 1 * (hp_enemy / 10))
			waza_hantei = 4;
		else
		{
			waza_hantei = 0;
			muteki = 0.0f;
		}
	}

	if (waza_hantei == 4)
	{
		Name_SetEffect(g_EnemyX, g_EnemyY + 30, 64.0f, 100, D3DCOLOR_RGBA(30, 30, 30, 1));
		if (!e_judge_huttobi)
		{
			if (Player_ORIENT() == 0)
			{
				e_huttobi = true;
			}
			else
			{
				e_huttobi = false;
			}
			e_judge_huttobi = true;
		}

		if (hp_enemy <= 100)
		{
			if (e_huttobi)
			{
				g_EnemyX += 10;
			}
			else
			{
				g_EnemyX -= 10;
			}
			g_EnemyY -= 20;
		}
		else
		{
			if (e_huttobi)
			{
				g_EnemyX += 20;
			}
			else
			{
				g_EnemyX -= 20;
			}
			g_EnemyY -= 40;
		}
	}
	else
	{
		e_judge_huttobi = false;
	}

	if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB) && !e_trans_judge)
	{
		e_trans_judge = true;
		if (!e_trans)
		{
			e_trans = true;
		}
		else
		{
			e_trans = false;
		}
	}
	else if (!(state.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB))
	{
		e_trans_judge = false;
	}
	if (e_trans)
	{
		Name_SetEffect(g_EnemyX, g_EnemyY, 128.0f, 100, D3DCOLOR_RGBA(255, 1, 255, 1));
	}
	if (e_trans)
	{
		c = 2;
	}
	else
	{
		c = 1;
	}
	if (trans_player)
	{
		d = 2;
	}
	else
	{
		d = 1;
	}
	if ((int)muteki < 10)
	{
		if (Ice_Fild() && g_EnemyY >= 550)
		{
			hp_enemy += 2.0f*d*c;
		}
	}

}

//------------------------------------
//		�`�揈��
//------------------------------------
void Enemy_Draw(void)
{

	Enemy_Back_texture();


	//�_���[�W���󂯂ĂȂ��Ȃ��
	if (waza_hantei == 0)
	{
		if (e_orientation == 0)
		{
			Enemy_Right_Chara();
		}

		if (e_orientation == 1)
		{
			Enemy_Left_Chara();
		}
	}

	if (e_waza_number == 0)
	{
		//�_���[�W�H�����
		if (waza_hantei == 1)
		{
			if (e_orientation == 1)
			{
				Sprite_Draw(kTEXTURE_INDEX_ENEMY1, g_EnemyX - 50, g_EnemyY - 50, 0, 200, 100, 100);
			}
			else
				Sprite_Draw(kTEXTURE_INDEX_ENEMY1_R, g_EnemyX - 50, g_EnemyY - 50, 0, 200, 100, 100);
		}
		//���G���
		else if (waza_hantei == 2)
		{
			if (motion_chara % 2 == 0)
			{
				if (e_orientation == 1)
				{
					Sprite_Draw(kTEXTURE_INDEX_ENEMY1, g_EnemyX - 50, g_EnemyY - 50, 0, 100, 100, 100);
				}
				else
					Sprite_Draw(kTEXTURE_INDEX_ENEMY1_R, g_EnemyX - 50, g_EnemyY - 50, 0, 100, 100, 100);
			}
			else if (motion_chara % 2 == 1)
			{
				if (e_orientation == 1)
				{
					Sprite_Draw_RED(kTEXTURE_INDEX_ENEMY1, g_EnemyX - 50, g_EnemyY - 50, 0, 100, 100, 100);
				}
				else
					Sprite_Draw_RED(kTEXTURE_INDEX_ENEMY1_R, g_EnemyX - 50, g_EnemyY - 50, 0, 100, 100, 100);
			}
		}
		//������΂�
		else if (waza_hantei == 4 || waza_hantei == 3)
		{
			if (e_orientation == 1)
			{
				Sprite_Draw(kTEXTURE_INDEX_ENEMY1, g_EnemyX - 50, g_EnemyY - 50, 0, 0, 100, 100);
			}
			else
				Sprite_Draw(kTEXTURE_INDEX_ENEMY1_R, g_EnemyX - 50, g_EnemyY - 50, 0, 0, 100, 100);
		}

	}

	if (!enemy_waza_end && !enemy_end_waza)
	{
		enemy_end_waza = Enemy_End_waza();
	}

	if (enemy_end_waza)
	{
		Name_SetEffect(g_EnemyX, g_EnemyY, 256.0f, 100, D3DCOLOR_RGBA(100, 0, 100, 100));
		Sprite_Draw_A(kTEXTURE_INDEX_DARK_TITLE, 600, 150);
	}
}

void Enemy_Back_texture(void)
{

	//�����̃A�C�R��
	Sprite_Draw(kTEXTURE_INDEX_CHARA2_P, 1200.f, 0);

	if (enemy_life >= 2)
	{
		Sprite_Draw(kTEXTURE_INDEX_LIFE_BULE, SCREEN_WIDTH - 140, 160, scroll * 40, 0, 40, 40);
		Sprite_Draw(kTEXTURE_INDEX_LIFE_BULE, SCREEN_WIDTH - 100, 160, scroll * 40, 0, 40, 40);
	}
	else if (enemy_life <= 1 && !enemy_life<1)
	{
		Sprite_Draw(kTEXTURE_INDEX_LIFE_BULE, SCREEN_WIDTH - 140, 160, scroll * 40, 0, 40, 40);
	}


	if (hp_enemy >= 100.0f)
	{
		Score_draw(1400.0f, 50.0f, (int)hp_enemy, 3, false, true);
	}
	else if (hp_enemy >= 10.0f)
	{
		Score_draw(1400.0f, 50.0f, (int)hp_enemy, 2, false, true);
	}
	else
	{
		Score_draw(1450.0f, 50.0f, (int)hp_enemy, 1, false, true);
	}

}

//�_���[�W�H�������
void Enemy_Destroy(int index)
{

	if ((int)muteki<10)
	{
		if (index == 10)
		{
			//PlaySound(SOUND_LABEL_SE_BULLET);
			if (G_e_motion)
			{
				hp_enemy += 5.5f* d*c;
			}
			else
				hp_enemy += 10.5f*d*c;
			if (!G_e_motion)
			{
				waza_hantei = 1;
			}
			motion_chara = 0;
			scroll_chara = 0;
			muteki += 2.0f;

		}
		else if (index == 1)
		{
			if (i == 0)
			{
				i++;
				PlaySound(SOUND_PANCHI);
			}
			if (G_e_motion)
			{
				hp_enemy += 0.15f*d*c;
			}
			else
				hp_enemy += 0.25f*d*c;
			if (!G_e_motion)
			{
				waza_hantei = 1;
			}
			motion_chara = 0;
			scroll_chara = 0;
			muteki += 0.1;
		}
		else if (index == 2)
		{
			PlaySound(SOUND_PANCHI_STRONG);
			if (G_e_motion)
			{
				hp_enemy += 0.15f*d*c;
			}
			else
				hp_enemy += 0.25f*d*c;
			if (!G_e_motion)
			{
				waza_hantei = 3;
			}
			motion_chara = 0;
			scroll_chara = 0;
			muteki += 0.1;

		}
		else if (index == 0)
		{
			i = 0;
		}
	}
}


//------------------------------------
//�����̕����ϗp
//------------------------------------
//�G�l�~�[�̃p���`��
void Enemy_panchi(void)
{

	XINPUT_STATE state;
	XInputGetState(1, &state);

	if (!e_motion && !G_e_motion)
	{

		//�ʏ�A�p���`
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_X && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && !e_panchi_judge|| enemy_AI == 2)
		{
			AI_count++;
			e_waza_number = 1;
			if (e_orientation == 0)
			{
				e_pattern = 5;
			}
			else if (e_orientation == 1)
			{
				e_pattern = 1;
			}
			E_Motion_Create(g_EnemyX - 50.f, g_EnemyY - 50.f);
			e_motion = true;
			enemy_waza_end = true;
			enemy_end_waza = false;
			e_panchi_judge = true;

		}

		//��A�p���`
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_X&&state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP && !e_panchi_S_judge||enemy_AI == 7)
		{
			e_waza_number = 2;
			if (e_orientation == 0)
			{
				e_pattern = 7;
			}
			else if (e_orientation == 1)
			{
				e_pattern = 3;
			}
			E_Motion_Create(g_EnemyX - 50.f, g_EnemyY - 50.f);
			e_motion = true;
			e_panchi_S_judge = true;
		}
	}

}

//�G�l�~�[�̋Z����
void Enemy_waza(void)
{
	XINPUT_STATE state;
	XInputGetState(1, &state);

	if (!e_motion && !G_e_motion)
	{
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && !dark_judge|| enemy_AI == 1)
		{
			e_waza_number = 3;
			if (e_orientation == 0)
			{
				e_pattern = 6;
				e_judge = false;
			}
			else if (e_orientation == 1)
			{
				e_pattern = 2;
				e_judge = true;
			}
			E_Motion_Create(g_EnemyX - 50.f, g_EnemyY - 50.f);
			E_Bullet_Create(g_EnemyX - 50.f, g_EnemyY - 50.f);
			e_motion = true;
			dark_judge = true;
		}

		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y && (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && !dark_judge)
		{
			e_waza_number = 4;
			if (e_orientation == 0)
			{
				e_pattern = 8;
			}
			else if (e_orientation == 1)
			{
				e_pattern = 4;
			}
			E_Motion_Create(g_EnemyX - 50.f, g_EnemyY - 50.f);
			e_motion = true;
		}
	}
}

//�G�l�~�[�̃W�����v����
void Enemy_Jump(void)
{
	//�W�����v
	XINPUT_STATE state;
	XInputGetState(1, &state);

	if (state.Gamepad.wButtons & XINPUT_GAMEPAD_A&& e_cnt_jump != 0 && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_B) && !e_motion && !e_jump_judge|| enemy_AI == 5)
	{
		PlaySound(SOUND_JUMP);
		e_jump_judge = true;
		e_cnt_jump -= 1;
		if (e_cnt_jump == 1)
			e_scroll_j = 24;
	}
	if (e_cnt_jump == 0 && e_cnt_j <= 6.3f)
	{
		e_cnt_j += 0.3f;
	}
	else if (e_cnt_jump != 0)
	{
		e_cnt_j = 0;
	}

	if (e_cnt_jump <= 1)
	{
		e_jump_up = (int)(e_scroll_j / 24) % 2;
		e_scroll_j++;
	}

	if (e_jump_up == 1)
	{
		if(g_EnemyY>400)
		g_EnemyY -= 20.0f;
		else
		{
			e_jump_up = 2;
		}
	}
	else
	{
		e_scroll_j = 0;
	}
}

//�G�l�~�[�̈ړ�
void Enemy_vector(void)
{
	D3DXVECTOR2 e_vecDir(0.0f, 0.0f);

	XINPUT_STATE state;
	XInputGetState(1, &state);
	//�ړ��t���[��
	e_frame = (enemy_e_frame / 8) % 10;

	//�E�ړ�
	if (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_B) && !e_motion|| enemy_AI == 4) {
		e_vecDir.x += ENEMY_MOVE_SPEED;
		e_orientation = 0;
		enemy_e_frame += 1;
	}

	//���ړ�
	if (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_B) && !e_motion|| enemy_AI == 3) {
		e_vecDir.x -= ENEMY_MOVE_SPEED;
		e_orientation = 1;
		enemy_e_frame += 1;
	}


	//�����P�ɐ��K�����邱�Ƃ��m�[�}���C�Y�ƌ���
	D3DXVec2Normalize(&e_vecDir, &e_vecDir);
	g_EnemySpeed += e_vecDir * ENEMY_MOVE_SPEED;
	g_EnemyX += g_EnemySpeed.x;
	g_EnemySpeed *= 0.94f;
	g_EnemyX = max(g_EnemyX, 0);
	g_EnemyX = min(g_EnemyX, 1505.f);
	g_EnemyY = max(g_EnemyY, -300.0f);
	g_EnemyY = min(g_EnemyY, 1400.f);

	g_enemy.Centerx = g_EnemyX;
	g_enemy.Centery = g_EnemyY;
}

//�G�l�~�[�̃K�[�h
void Enemy_Guard(void)
{
	XINPUT_STATE state;
	XInputGetState(1, &state);

	if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_B)) {
		PlaySound(SOUND_BARRIER);
		G_e_motion = true;
		enemy_e_frame_g += 1;
	}
	else if (!(state.Gamepad.wButtons & XINPUT_GAMEPAD_B)) {
		G_e_motion = false;
		e_frame_g = 0;
		enemy_e_frame_g = 0;
	}

	e_frame_g = (enemy_e_frame_g / 8) % 31;

	if (e_frame_g >= 30)
	{
		e_motion = true;
		if (e_orientation == 0)
		{
			e_pattern = 10;
		}
		else if (e_orientation == 1)
		{
			e_pattern = 11;
		}
		E_Motion_Create(g_EnemyX - 50.f, g_EnemyY - 50.f);
		e_frame_g = 0;
		enemy_e_frame_g = 0;
	}

}

//�G�l�~�[�̉E�����L����
void Enemy_Right_Chara(void)
{
	int select_c = 1;

	if (!e_motion)
	{
		Sprite_Draw(select_c, g_EnemyX - 50.f, g_EnemyY - 50.f, e_frame * 100.f, 100.f * 2, 100.f, 100.f, 50.f, 50.f, 1.0f, 1.0f, e_cnt_j);
		if (e_cnt_jump == 2)//�n��Ȃ�Ήe�\��
			Sprite_Draw(kTEXTURE_INDEX_MY1_SHADOW, g_EnemyX - 50.f, g_EnemyY - 40.f);
		//DebugPrimitive_DrawBatchCircle(g_EnemyX, g_EnemyY, g_enemy.Radious);
		if (G_e_motion)
		{
			if (e_frame_g <= 15)
			{
				Sprite_Draw(kTEXTURE_INDEX_G, g_EnemyX - 50.f, g_EnemyY - 100.f, e_frame_g * 100.f, 0, 100.f, 200.f);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_G_B, g_EnemyX - 50.f, g_EnemyY - 100.f, e_frame_g * 100.f, 0, 100.f, 200.f);
			}
		}
	}

}

//�G�l�~�[�̍������L����
void Enemy_Left_Chara(void)
{

	int select_c = 1;

	if (!e_motion)
	{
		Sprite_Draw(select_c, g_EnemyX - 50.f, g_EnemyY - 50.f, e_frame * 100.f, 100.f, 100.f, 100.f, 50.f, 50.f, 1.0f, 1.0f, e_cnt_j);
		if (e_cnt_jump == 2)//�n��Ȃ�Ήe�\��
			Sprite_Draw(kTEXTURE_INDEX_MY1_SHADOW, g_EnemyX - 50.f, g_EnemyY - 40.f);
		//DebugPrimitive_DrawBatchCircle(g_EnemyX, g_EnemyY, g_enemy.Radious);
		if (G_e_motion)
		{
			if (e_frame_g <= 15)
			{
				Sprite_Draw(kTEXTURE_INDEX_G, g_EnemyX - 50.f, g_EnemyY - 100.f, e_frame_g * 100.f, 0, 100.f, 200.f);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_G_B, g_EnemyX - 50.f, g_EnemyY - 100.f, e_frame_g * 100.f, 0, 100.f, 200.f);
			}
		}
	}

}



//------------------------------------
//�����̕��͂�����Ȃ�
//------------------------------------
//�G�Ǝ����̓����蔻��@�R���W����
const Circle*Enemy_GetCircleCollision(void)
{
	return &g_enemy;
}
//���ݒn��X���W��Ԃ�
int e_move_x(void)
{
	return g_EnemyX;
}

//���ݒn��X���W��Ԃ�
int e_move_y(void)
{
	return g_EnemyY;
}

int E_Motionpattern(void)
{
	return e_pattern;
}

int Enemy_Judge(void)
{
	return e_judge;
}

int Enemy_deth(void)
{
	return e_deth_my;
}

int Enemy_Hp_End(void)
{
	return e_hp_e_end;
}

int Enemy_Hp(void)
{
	return enemy_life;
}

int Enemy_Waza_Number(void)
{
	return e_waza_number;
}

int END_Enemy(void)
{
	return end;
}

int Trance_Enemy(void)
{
	return e_trans;
}

int ENEMY_ORIENT(void)
{
	return e_orientation;
}