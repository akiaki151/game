//=============================================================================
//
// �T�E���h���� [sound.h]
//
//=============================================================================
#ifndef _SOUND_H_
#define _SOUND_H_

#include <windows.h>
#include "xaudio2.h"						// �T�E���h�����ŕK�v

//*****************************************************************************
// �T�E���h�t�@�C��
//*****************************************************************************
typedef enum
{
	SOUND_BARRIER,
	SOUND_BATTLE_BGM,
	SOUND_DOWN,
	SOUND_PANCHI,
	SOUND_ICE_SLASH,
	SOUND_JUMP,
	SOUND_PANCHI_STRONG,
	SOUND_SPACE_BOTTON,
	SOUND_DARK_SLASH,
	SOUND_SELECT,
	SOUND_BGM_SELECT,
	SOUND_BGM_RESULT,
	SOUND_LABEL_MAX,
} SOUND_LABEL;

//*****************************************************************************
// �v���g�^�C�v�錾
//*****************************************************************************
bool InitSound(HWND hWnd);
void UninitSound(void);
void PlaySound(SOUND_LABEL label);
void StopSound(SOUND_LABEL label);
void StopSound(void);

#endif
