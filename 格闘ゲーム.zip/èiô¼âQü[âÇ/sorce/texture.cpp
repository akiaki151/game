//=============================================================================
//
// �e�N�X�`���`�揈�� [texture.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include<d3dx9.h>
#include <windows.h>
#include"texture.h"
#include"mydirect.h"

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static const TextureFileData TEXTURE_FILES[] = {
    { "chara/char1_type3.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_FOUR },
	{ "chara/char2_type3.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_FOUR },
	{ "chara/char3_type3.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_FOUR },
	{ "chara/char4_type3.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_FOUR },
	{ "chara/char1_type2.png",TEXTURE_SIZE_CHAR_MOVE,TEXTURE_SIZE_CHAR_MOVE },
	{ "chara/char2_type2.png",TEXTURE_SIZE_CHAR_MOVE,TEXTURE_SIZE_CHAR_MOVE },
	{ "chara/char3_type2.png",TEXTURE_SIZE_CHAR_MOVE,TEXTURE_SIZE_CHAR_MOVE },
	{ "chara/char4_type2.png",TEXTURE_SIZE_CHAR_MOVE,TEXTURE_SIZE_CHAR_MOVE },
	{ "chara/char1_type1.png",TEXTURE_SIZE_CHAR,TEXTURE_SIZE_CHAR },
	{ "chara/char2_type1.png",TEXTURE_SIZE_CHAR,TEXTURE_SIZE_CHAR },
	{ "chara/char3_type1.png",TEXTURE_SIZE_CHAR,TEXTURE_SIZE_CHAR },
	{ "chara/char4_type1.png",TEXTURE_SIZE_CHAR,TEXTURE_SIZE_CHAR },
	{ "asset/title.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "asset/number.tga",TEXTURE_NUMBER_SIZE_W,TEXTURE_NUMBER_SIZE_H },
	{ "asset/chara_select.tga",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "asset/select.png",TEXTURE_SIZE_CHAR_MOVE,TEXTURE_SIZE_CHAR_MOVE },
	{ "asset/select_cpu.png",TEXTURE_SIZE_CHAR_MOVE,TEXTURE_SIZE_CHAR_MOVE },
	{ "asset/Loading.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "asset/status.png",TEXTURE_FIVE,TEXTURE_FOUR },
	{ "asset/attack.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "asset/guard.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "asset/fast.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "asset/no_status.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "asset/lamp.png",TEXTURE_GAZOU,TEXTURE_SIX_2 },
	{ "asset/ice.png",TEXTURE_FOUR,TEXTURE_FOUR },
	{ "asset/dark.png",TEXTURE_FOUR,TEXTURE_FOUR },
	{ "asset/fire.png",TEXTURE_FOUR,TEXTURE_FOUR },
	{ "asset/light.png",TEXTURE_FOUR,TEXTURE_FOUR },
	{ "asset/Ice5.png",TEXTURE_THOUSAND,TEXTURE_THOUSAND },
	{ "asset/Darkness5.png",TEXTURE_THOUSAND,TEXTURE_THOUSAND },
	{ "asset/Fire3.png",TEXTURE_THOUSAND,TEXTURE_THOUSAND },
	{ "asset/Holy5.png",TEXTURE_THOUSAND,TEXTURE_THOUSAND },
	{ "asset/StateDeath.png",TEXTURE_ANIME_X,TEXTURE_ANIME_Y },
	{ "asset/select_chara.png",TEXTURE_FOUR,TEXTURE_FOUR },
	{ "asset/result.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "asset/Gates.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/stage1.png",SCREEN_WIDTH*3,SCREEN_HEIGHT },
	{ "enemy/enemy.png",TEXTURE_THREE,TEXTURE_THREE },
	{ "enemy/enemy_r.png",TEXTURE_THREE,TEXTURE_THREE },
	{ "enemy/player.png",TEXTURE_THREE,TEXTURE_THREE },
	{ "enemy/player_r.png",TEXTURE_THREE,TEXTURE_THREE },
	{ "stage/1.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/2.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/3.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/stage1_1.png",SCREEN_WIDTH - 600,TEXTURE_THREE },
	{ "stage/chara1.png",TEXTURE_FOUR,TEXTURE_TWO },
	{ "stage/chara2.png",TEXTURE_FOUR,TEXTURE_TWO },
	{ "stage/tori.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "stage/cat.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "stage/takibi.png",TEXTURE_GAZOU,TEXTURE_SIX },
	{ "stage/Floral.png",TEXTURE_EIGHT/3,TEXTURE_TWO },
	{ "stage/fire_life_r.png",TEXTURE_SIX_2,TEXTURE_FOUR_MINI },
	{ "stage/fire_life_b.png",TEXTURE_SIX_2,TEXTURE_FOUR_MINI },
	{ "stage/fire.png",TEXTURE_SIX_2,TEXTURE_FOUR_MINI },
	{ "stage/hukkatu.png",TEXTURE_THOUSAND,TEXTURE_TWO },
	{ "stage/hukkatu_e.png",TEXTURE_THOUSAND,TEXTURE_TWO },
	{ "stage/fune.png",900,TEXTURE_THREE },
	{ "stage/hi_score.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "chara/G.png",TEXTURE_THREE,TEXTURE_SIZE_CHAR1_Y/2 },
	{ "chara/G_B.png",TEXTURE_THREE,TEXTURE_SIZE_CHAR1_Y / 2 },
	{ "chara/char1_type4.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_SIZE_CHAR1_Y },
	{ "chara/char1_type4_r.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_SIZE_CHAR1_Y },
	{ "chara/char2_type4.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_SIZE_CHAR1_Y },
	{ "chara/char2_type4_r.png",TEXTURE_SIZE_CHAR1_X,TEXTURE_SIZE_CHAR1_Y },
	{ "waza/SlashIce.png",TEXTURE_THOUSAND,TEXTURE_SIZE_CHAR1_W_Y},
	{ "waza/Darkness1.png",TEXTURE_THOUSAND,TEXTURE_SIZE_CHAR1_W_Y },
    { "waza/bullet.png",TEXTURE_SIZE_CHAR1_X/3,TEXTURE_SIZE_CHAR1_X/3 },
	{ "waza/bullet_enemy.png",TEXTURE_SIZE_CHAR1_X / 3,TEXTURE_SIZE_CHAR1_X / 3 },
	{ "chara/Shadow1.png",TEXTURE_ONE,TEXTURE_ONE},
	{ "chara/mahi.png",TEXTURE_EIGHT,TEXTURE_ONE},
	{ "chara/mahi_R.png",TEXTURE_EIGHT,TEXTURE_ONE },
	{ "chara/Ice_P.png",TEXTURE_THREE,TEXTURE_ONE },
	{ "chara/Dark_P.png",TEXTURE_THREE,TEXTURE_ONE },
	{ "chara/P.png",TEXTURE_THREE,TEXTURE_ONE },
	{ "chara/Ice_P3.png",TEXTURE_THREE,TEXTURE_ONE },
	{ "waza/mahou.png",TEXTURE_THOUSAND,TEXTURE_TWO},
	{ "waza/ice_fild.png",TEXTURE_THREE*2,TEXTURE_ONE*2 },
	{ "waza/StateDown3.png",2500,2000 },
	{ "asset/end_waza.tga",TEXTURE_SIZE_CHAR1_W_Y,TEXTURE_TWO },
	{ "asset/result2.png",SCREEN_WIDTH,SCREEN_HEIGHT},
	{ "asset/321.png",4800,900 },
	{ "asset/finish.png",400,300 },
	{ "stage/cnt_3.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/cnt_2.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/cnt_1.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "stage/cnt_1.png",SCREEN_WIDTH,SCREEN_HEIGHT },
	{ "char/buttobi.png",300,100 },
	
};
static const int TEXTURE_MAX = sizeof(TEXTURE_FILES) / sizeof(TEXTURE_FILES[0]);
//static const int TEXTURE_MAX = ARRYSIZE(TEXTURE_FILES);
static LPDIRECT3DTEXTURE9 g_ptextures[TEXTURE_MAX];

//------------------------------------
//		�e�N�X�`���ǂݍ���
//------------------------------------
int Texture_Load(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	HRESULT hr;
	int failed_count = 0;

	for (int i = 0; i < TEXTURE_MAX; i++)
	{
		hr = D3DXCreateTextureFromFile(pDevice, TEXTURE_FILES[i].filename, &g_ptextures[i]);
		if (FAILED(hr)) {
			failed_count++;
		}
	}
	return failed_count;
}

//------------------------------------
//		�e�N�X�`�����
//------------------------------------
void Texture_Release(void)
{
	for (int i = 0; i < TEXTURE_MAX; i++)
	{
		if (g_ptextures[i]) {
			g_ptextures[i]->Release();
			g_ptextures[i] = NULL;
		}
	}
}

//------------------------------------
//		�e�N�X�`���ԍ���n��
//------------------------------------
LPDIRECT3DTEXTURE9 Texture_GetTexture(int index)
{
	return g_ptextures[index];
}

//------------------------------------
//		�e�N�X�`����X���W�𔲂����
//------------------------------------
int Texture_GetWidth(int index)
{

	return TEXTURE_FILES[index].width;

}

//------------------------------------
//		�e�N�X�`����Y���W�𔲂����
//------------------------------------
int Texture_GetHeight(int index)
{

	return TEXTURE_FILES[index].height;

}