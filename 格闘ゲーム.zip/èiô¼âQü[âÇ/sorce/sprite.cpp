//=============================================================================
//
// �X�v���C�g�\������ [sprite.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include<d3dx9.h>
#include"sprite.h"
#include"texture.h"
#include"mydirect.h"
#include<string.h>

//------------------------------------
//		�}�N��
//------------------------------------
#define FVF_VERTEXPORIGON (D3DFVF_XYZRHW|D3DFVF_DIFFUSE)//FVF�쐬
#define FVF_VERTEX2D (D3DFVF_XYZRHW|D3DFVF_DIFFUSE|D3DFVF_TEX1) 

//------------------------------------
//		�\����
//------------------------------------
typedef struct Vertex2D_tag
{
	D3DXVECTOR4 position;//float�ɂ���4��1.0f(RHW)���W�ϊ��ςݒ��_
	D3DCOLOR color;
	D3DXVECTOR2 texcoord;
}Vertex2D;

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static D3DCOLOR g_Color = 0xffffffff;
static LPDIRECT3DVERTEXBUFFER9 g_pVertexBuffer = NULL;
static LPDIRECT3DINDEXBUFFER9 g_pIndexBuffer = NULL;

//------------------------------------
//		����������
//------------------------------------
void Sprite_Initialize(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	//���_�o�b�t�@�̊m��
	pDevice->CreateVertexBuffer(sizeof(Vertex2D) * 4, D3DUSAGE_WRITEONLY, FVF_VERTEX2D, D3DPOOL_MANAGED, &g_pVertexBuffer, NULL);
}

//------------------------------------
//		�I������
//------------------------------------
void Sprite_Finalize(void)
{
	if (g_pVertexBuffer)
	{
		g_pVertexBuffer->Release();
		g_pVertexBuffer = NULL;
	}

}

//------------------------------------
//		�J���[����
//------------------------------------
void Sprite_SetColor(D3DCOLOR color)
{
	g_Color = color;
}

//------------------------------------
//		�`�揈��(�ړ����W�̂�)
//------------------------------------
void Sprite_Draw(int texture_index, float dx, float dy)
{

	float w = (float)Texture_GetWidth(texture_index);
	float h = (float)Texture_GetHeight(texture_index);

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	if (!pDevice)
	{
		return;
	}

	Vertex2D v[] = {
		{ D3DXVECTOR4(dx - 0.5f,dy - 0.5f,1.0f,1.0f) ,g_Color,D3DXVECTOR2(0.0f,0.0f) },
		{ D3DXVECTOR4(dx + w - 0.5f,dy - 0.5f,1.0f,1.0f) ,g_Color,D3DXVECTOR2(1.0f,0.0f) },
		{ D3DXVECTOR4(dx - 0.5f,dy + h - 0.5f,1.0f,1.0f) ,g_Color,D3DXVECTOR2(0.0f,1.0f) },
		{ D3DXVECTOR4(dx + w - 0.5f,dy + h - 0.5f,1.0f,1.0f) ,g_Color,D3DXVECTOR2(1.0f,1.0f) }
	};

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	pDevice->SetSamplerState(0, D3DSAMP_BORDERCOLOR, D3DCOLOR_RGBA(0, 0, 0, 255));
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	//�A���t�@�u�����h��ON�ɂ���
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

	//�w�i(���ɕ`���ꂽ���)DEST�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	//������`���|���S��SRC�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, &v[0], sizeof(Vertex2D));
	pDevice->SetTexture(0, NULL);

	pDevice->SetFVF(FVF_VERTEXPORIGON);
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

}

void Sprite_Draw_A(int texture_index, float dx, float dy)
{

	float w = (float)Texture_GetWidth(texture_index);
	float h = (float)Texture_GetHeight(texture_index);

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	if (!pDevice)
	{
		return;
	}

	Vertex2D v[] = {
		{ D3DXVECTOR4(dx - 0.5f,dy - 0.5f,1.0f,1.0f) ,D3DCOLOR_RGBA(1, 1, 1, 100),D3DXVECTOR2(0.0f,0.0f) },
	{ D3DXVECTOR4(dx + w - 0.5f,dy - 0.5f,1.0f,1.0f) ,D3DCOLOR_RGBA(1, 1, 1, 100),D3DXVECTOR2(1.0f,0.0f) },
	{ D3DXVECTOR4(dx - 0.5f,dy + h - 0.5f,1.0f,1.0f) ,D3DCOLOR_RGBA(1, 1, 1, 100),D3DXVECTOR2(0.0f,1.0f) },
	{ D3DXVECTOR4(dx + w - 0.5f,dy + h - 0.5f,1.0f,1.0f),D3DCOLOR_RGBA(1, 1, 1, 100),D3DXVECTOR2(1.0f,1.0f) }
	};

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	pDevice->SetSamplerState(0, D3DSAMP_BORDERCOLOR, D3DCOLOR_RGBA(0, 0, 0, 255));
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	//�A���t�@�u�����h��ON�ɂ���
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

	//�w�i(���ɕ`���ꂽ���)DEST�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	//������`���|���S��SRC�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, &v[0], sizeof(Vertex2D));
	pDevice->SetTexture(0, NULL);

	pDevice->SetFVF(FVF_VERTEXPORIGON);
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

}

//-------------------------------------------------
//		�`�揈���i�ړ��{�e�N�X�`���A�j���[�V�����p�j
//-------------------------------------------------
void Sprite_Draw(int texture_index, float dx, float dy, int tx, int ty, int tw, int th)
{

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	if (!pDevice)
	{
		return;
	}

	float w = (float)Texture_GetWidth(texture_index);
	float h = (float)Texture_GetHeight(texture_index);

	float u0 = (float)tx / w;
	float v0 = (float)ty / h;
	float u1 = (float)(tw+tx) / w;
	float v1 = (float)(th + ty) / h;

	Vertex2D v[] = {
		{ D3DXVECTOR4(dx,dy,1.0f,1.0f),g_Color,D3DXVECTOR2(u0,v0) },
		{ D3DXVECTOR4(dx + tw,dy,1.0f,1.0f),g_Color,D3DXVECTOR2(u1,v0) },
		{ D3DXVECTOR4(dx,dy + th,1.0f,1.0f), g_Color,D3DXVECTOR2(u0,v1) },
		{ D3DXVECTOR4(dx + tw,dy + th,1.0f,1.0f),g_Color,D3DXVECTOR2(u1,v1) },
	};

	/* �������v���~�e�B�u���i�O�p�`�̕\����*/
	//pDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(100, 255, 255, 255), 1.0f, 0);		//0����Ԏ�O�A�P����ԉ�

	/*�A���t�@�u�����h��ON�ɂ���*/
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	/*�w�i�i���łɕ`���ꂽ��ԁjDEST�̃u�����h�ݒ�*/
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	/*������`���|���S��SRC�̃u�����h�ݒ�*/
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	//���ꂢ��
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);

	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vertex2D));
}
void Sprite_Draw_RED(int texture_index, float dx, float dy, int tx, int ty, int tw, int th)
{

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	if (!pDevice)
	{
		return;
	}

	float w = (float)Texture_GetWidth(texture_index);
	float h = (float)Texture_GetHeight(texture_index);

	float u0 = (float)tx / w;
	float v0 = (float)ty / h;
	float u1 = (float)(tw + tx) / w;
	float v1 = (float)(th + ty) / h;

	Vertex2D v[] = {
		{ D3DXVECTOR4(dx,dy,1.0f,1.0f),D3DCOLOR_RGBA(255, 1, 1, 100),D3DXVECTOR2(u0,v0) },
	{ D3DXVECTOR4(dx + tw,dy,1.0f,1.0f),D3DCOLOR_RGBA(255, 1, 1, 100),D3DXVECTOR2(u1,v0) },
	{ D3DXVECTOR4(dx,dy + th,1.0f,1.0f),D3DCOLOR_RGBA(255, 1, 1, 100),D3DXVECTOR2(u0,v1) },
	{ D3DXVECTOR4(dx + tw,dy + th,1.0f,1.0f),D3DCOLOR_RGBA(255, 1, 1, 100),D3DXVECTOR2(u1,v1) },
	};

	/* �������v���~�e�B�u���i�O�p�`�̕\����*/
	//pDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(100, 255, 255, 255), 1.0f, 0);		//0����Ԏ�O�A�P����ԉ�

	/*�A���t�@�u�����h��ON�ɂ���*/
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	/*�w�i�i���łɕ`���ꂽ��ԁjDEST�̃u�����h�ݒ�*/
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	/*������`���|���S��SRC�̃u�����h�ݒ�*/
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	//���ꂢ��
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);

	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vertex2D));
}
void Sprite_Draw_R(int texture_index, float dx, float dy, int tx, int ty, int tw, int th)
{

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	if (!pDevice)
	{
		return;
	}

	float w = (float)Texture_GetWidth(texture_index);
	float h = (float)Texture_GetHeight(texture_index);

	float u0 = (float)tx / w;
	float v0 = (float)ty / h;
	float u1 = (float)(tw + tx) / w;
	float v1 = (float)(th + ty) / h;

	Vertex2D v[] = {
		{ D3DXVECTOR4(dx,dy,1.0f,1.0f),g_Color,D3DXVECTOR2(u0,v0) },
	{ D3DXVECTOR4(dx + tw,dy,1.0f,1.0f),g_Color,D3DXVECTOR2(u1,v0) },
	{ D3DXVECTOR4(dx,dy + th,1.0f,1.0f), g_Color,D3DXVECTOR2(u0,v1) },
	{ D3DXVECTOR4(dx + tw,dy + th,1.0f,1.0f),g_Color,D3DXVECTOR2(u1,v1) },
	};

	/* �������v���~�e�B�u���i�O�p�`�̕\����*/
	//pDevice->Clear(0, NULL, D3DCLEAR_TARGET | D3DCLEAR_ZBUFFER, D3DCOLOR_RGBA(100, 255, 255, 255), 1.0f, 0);		//0����Ԏ�O�A�P����ԉ�

	/*�A���t�@�u�����h��ON�ɂ���*/
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
	/*�w�i�i���łɕ`���ꂽ��ԁjDEST�̃u�����h�ݒ�*/
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);
	/*������`���|���S��SRC�̃u�����h�ݒ�*/
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	//���ꂢ��
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_MIRROR);

	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, v, sizeof(Vertex2D));
}

//-------------------------------------------------------
//		�`�揈���i�ړ��{�e�N�X�`���A�j���[�V�����{��]�p�j
//-------------------------------------------------------
void Sprite_Draw(int texture_index, float dx, float dy, int tx, int ty, int tw, int th, float cx, float cy, float sx, float sy, float rotation)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	float w = Texture_GetWidth(texture_index);
	float h = Texture_GetHeight(texture_index);

	float u0 = (float)tx / w;
	float v0 = (float)ty / h;
	float u1 = (float)(tx + tw) / w;
	float v1 = (float)(ty + th) / h;

	float px[4], py[4];

	px[0] = (-cx) * sx * cos(rotation) - (-cy) * sy * sin(rotation);
	py[0] = (-cx) * sx * sin(rotation) + (-cy) * sy * cos(rotation);
	px[1] = (-cx + tw) * sx * cos(rotation) - (-cy) * sy * sin(rotation);
	py[1] = (-cx + tw) * sx * sin(rotation) + (-cy) * sy * cos(rotation);
	px[2] = (-cx) * sx * cos(rotation) - (-cy + th) * sy * sin(rotation);
	py[2] = (-cx) * sx * sin(rotation) + (-cy + th) * sy * cos(rotation);
	px[3] = (-cx + tw) * sx * cos(rotation) - (-cy + th) * sy * sin(rotation);
	py[3] = (-cx + tw) * sx * sin(rotation) + (-cy + th) * sy * cos(rotation);

	Vertex2D v[] = {
		{ D3DXVECTOR4(px[0] + dx + cx - 0.5f,py[0] + dy + cy - 0.5f,1.0f,1.0f),g_Color,D3DXVECTOR2(u0 ,v0) },
		{ D3DXVECTOR4(px[1] + dx + cx - 0.5f,py[1] + dy + cy - 0.5f,1.0f,1.0f),g_Color,D3DXVECTOR2(u1 ,v0) },
		{ D3DXVECTOR4(px[2] + dx + cx - 0.5f,py[2] + dy + cy - 0.5f,1.0f,1.0f),g_Color,D3DXVECTOR2(u0 ,v1) },
		{ D3DXVECTOR4(px[3] + dx + cx - 0.5f,py[3] + dy + cy - 0.5f,1.0f,1.0f),g_Color,D3DXVECTOR2(u1 ,v1) }
	};

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	pDevice->SetSamplerState(0, D3DSAMP_BORDERCOLOR, D3DCOLOR_RGBA(0, 0, 0, 255));
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	//�A���t�@�u�����h��ON�ɂ���
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

	//�w�i(���ɕ`���ꂽ���)DEST�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	//������`���|���S��SRC�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, &v[0], sizeof(Vertex2D));
	pDevice->SetTexture(0, NULL);

	pDevice->SetFVF(FVF_VERTEXPORIGON);
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);
}



void Sprite_Draw2(int texture_index, float dx, float dy)
{

	float w = (float)Texture_GetWidth(texture_index);
	float h = (float)Texture_GetHeight(texture_index);

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	if (!pDevice)
	{
		return;
	}

	Vertex2D v[] = {
		{ D3DXVECTOR4(dx - 0.5f,dy - 0.5f,1.0f,1.0f) ,D3DCOLOR_RGBA(255, 255, 255, 100),D3DXVECTOR2(0.0f,0.0f) },
	{ D3DXVECTOR4(dx + w - 0.5f,dy - 0.5f,1.0f,1.0f) ,D3DCOLOR_RGBA(255, 255, 255, 100),D3DXVECTOR2(1.0f,0.0f) },
	{ D3DXVECTOR4(dx - 0.5f,dy + h - 0.5f,1.0f,1.0f) ,D3DCOLOR_RGBA(255, 255, 255, 100),D3DXVECTOR2(0.0f,1.0f) },
	{ D3DXVECTOR4(dx + w - 0.5f,dy + h - 0.5f,1.0f,1.0f),D3DCOLOR_RGBA(255, 255, 255, 100),D3DXVECTOR2(1.0f,1.0f) }
	};

	pDevice->SetFVF(FVF_VERTEX2D);
	pDevice->SetTexture(0, Texture_GetTexture(texture_index));

	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG1, D3DTA_TEXTURE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAARG2, D3DTA_DIFFUSE);
	pDevice->SetTextureStageState(0, D3DTSS_ALPHAOP, D3DTOP_MODULATE);

	pDevice->SetSamplerState(0, D3DSAMP_BORDERCOLOR, D3DCOLOR_RGBA(0, 0, 0, 10));
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSU, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_ADDRESSV, D3DTADDRESS_WRAP);
	pDevice->SetSamplerState(0, D3DSAMP_MAGFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MINFILTER, D3DTEXF_LINEAR);
	pDevice->SetSamplerState(0, D3DSAMP_MIPFILTER, D3DTEXF_LINEAR);

	//�A���t�@�u�����h��ON�ɂ���
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

	//�w�i(���ɕ`���ꂽ���)DEST�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA);

	//������`���|���S��SRC�̃u�����h�ݒ�
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);
	pDevice->DrawPrimitiveUP(D3DPT_TRIANGLESTRIP, 2, &v[0], sizeof(Vertex2D));
	pDevice->SetTexture(0, NULL);

	pDevice->SetFVF(FVF_VERTEXPORIGON);
	pDevice->SetRenderState(D3DRS_ALPHABLENDENABLE, TRUE);

}


