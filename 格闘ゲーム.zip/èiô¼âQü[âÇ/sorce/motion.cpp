//=============================================================================
//
// �G�t�F�N�g�\������ [motion.cpp]
//
//=============================================================================
#include"motion.h"
#include"bullet.h"
#include"sprite.h"
#include"texture.h"
#include"judgement.h"
#include"animetion.h"
#include"input.h"
#include"player.h"
#include"enemy.h"
#include"common.h"

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
//����
static int frame_counter[MOTION_MAX];
static int animation[MOTION_MAX];
static int MotionCreateFrame[MOTION_MAX];
static int PtternMotion[MOTION_MAX];

MOTION motion[MOTION_MAX];

static int pattern;
static int panchi_cnt = 0;
static bool deth_chara = false;

//�G�l�~�[
static int e_frame_counter[MOTION_MAX];
static int e_animation[MOTION_MAX];
static int e_MotionCreateFrame[MOTION_MAX];
static int e_PtternMotion[MOTION_MAX];

EMOTION e_motion[MOTION_MAX];

static int e_pattern;
static int e_panchi_cnt = 0;
static bool e_deth_chara = false;

static int cnt = 0;
static int frame = 0;
static bool ice_fild = false;
static int frame_S = 0;
static int b = 0;
static bool deth_fild = false;
//------------------------------------
//		�G�t�F�N�g����������
//------------------------------------
void Motion_Initialize(void)
{
	for (int i = 0; i < MOTION_MAX; i++)
	{
		//����������
		motion[i].motion_flag = false;
		frame_counter[i] = 0;
		animation[i] = 0;
		MotionCreateFrame[i] = 0;
		motion[i].motion_x = 0;
		motion[i].motion_y = 0;
		PtternMotion[i] = 0;
		motion[i].texcutX = 0;
		motion[i].texcutY = 0;
		//�G�l�~�[������
		e_motion[i].e_motion_flag = false;
		e_frame_counter[i] = 0;
		e_animation[i] = 0;
		e_MotionCreateFrame[i] = 0;
		e_motion[i].e_motion_x = 0;
		e_motion[i].e_motion_y = 0;
		e_PtternMotion[i] = 0;
		e_motion[i].e_texcutX = 0;
		e_motion[i].e_texcutY = 0;
	}
	pattern = 0;
	panchi_cnt = 0;
	deth_chara = false;

	e_pattern = 0;
	e_panchi_cnt = 0;
	e_deth_chara = false;

	cnt = 0;
	frame = 0;
	ice_fild = false;
	frame_S = 0;
	b = 0;
	deth_fild = false;
}

//------------------------------------
//		�G�t�F�N�g�I������
//------------------------------------
void Motion_Finalize(void)
{

}

//------------------------------------
//		�G�t�F�N�g�X�V����
//------------------------------------
void Motion_Update(void)
{

	motion[0].motion_x = move_x() - 50;
	motion[0].motion_y = move_y() - 50;


	e_motion[0].e_motion_x = e_move_x() - 50;
	e_motion[0].e_motion_y = e_move_y() - 50;
	

	//����
	if (motion[0].motion_flag|| motion[1].motion_flag)
	{
		for (int i = 0; i < MOTION_MAX; i++)
		{
			frame_counter[i]++;

			if (pattern == 1|| pattern == 5)
			{
				animation[i] = texanimetions(frame_counter[i], PANCHI_FRAME);
			}
			else if (pattern == 3||pattern == 7)
			{
				animation[i] = texanimetions(frame_counter[i], PANCHI_S_FRAME);
			}
			else if (pattern == 2 || pattern == 6)
			{
				animation[i] = texanimetions(frame_counter[i], SPECIAL_FRAME);
			}
			else if (pattern == 4 || pattern == 8)
			{
				animation[i] = texanimetions(frame_counter[i], SPECIAL_S_FRAME);
			}
			else if (pattern == 10 || pattern == 11)
			{
				animation[i] = texanimetions(frame_counter[i], GUARD_FRAME);
			}
			else if (deth_chara)
			{
				animation[i] = texanimetions(frame_counter[i], 12);
			}
			if (pattern < 10&&!(pattern == 4 || pattern == 8))
			{
				motion[0].texcutX = cutx(PTTERN_TW, animation[i], 3);

				motion[0].texcutY = cuty(PTTERN_TH, animation[i], 3);
			}
			else if (pattern <= 11 &&pattern >= 10)
			{
				motion[0].texcutX = cutx(PTTERN_TW, animation[i], 8);
				motion[0].texcutY = cuty(PTTERN_TH, animation[i], 8);
			}
			else if (pattern == 4 || pattern == 8)
			{
				motion[0].texcutX = cutx(PTTERN_TW*2, animation[i], 5);
				motion[0].texcutY = cuty(PTTERN_TH*2, animation[i], 5);
				frame = (cnt / 550) % 2;
				cnt++;
			}

			if (deth_chara)
			{
				motion[1].texcutX = cutx(PTTERN_TW*2 , animation[i], 5);
				motion[1].texcutY = cuty(PTTERN_TH*2 , animation[i], 5);
			}

			if (animation[i] > MAX_PTTERN)
			{
				motion[0].motion_flag = false;
				motion[1].motion_flag = false;
				frame_counter[i] = 0;
				deth_chara = false;
				cnt = 0;
				frame = 0;
				ice_fild=0;
			}

		}
	}


	//�G�l�~�[
	if (e_motion[0].e_motion_flag|| e_motion[1].e_motion_flag)
	{
		for (int i = 0; i < MOTION_MAX; i++)
		{
			e_frame_counter[i]++;

			if (e_pattern == 1 || e_pattern == 5)
			{
				e_animation[i] = texanimetions(e_frame_counter[i], PANCHI_FRAME);
			}
			else if (e_pattern == 3 || e_pattern == 7)
			{
				e_animation[i] = texanimetions(e_frame_counter[i], PANCHI_S_FRAME);
			}
			else if (e_pattern == 2 || e_pattern == 6)
			{
				e_animation[i] = texanimetions(e_frame_counter[i], SPECIAL_FRAME);
			}
			else if (e_pattern == 4 || e_pattern == 8)
			{
				e_animation[i] = texanimetions(e_frame_counter[i], GUARD_FRAME);
			}
			else if (e_pattern == 10 || e_pattern == 11)
			{
				e_animation[i] = texanimetions(e_frame_counter[i], GUARD_FRAME);
			}
			else if (e_deth_chara)
			{
				e_animation[i] = texanimetions(e_frame_counter[i], 12);
			}

			if (e_pattern < 10 && !(e_pattern == 4 || e_pattern == 8))
			{
				e_motion[0].e_texcutX = cutx(PTTERN_TW, e_animation[i], 3);

				e_motion[0].e_texcutY = cuty(PTTERN_TH, e_animation[i], 3);
			}
			else if (e_pattern <= 11 && e_pattern >= 10)
			{
				e_motion[0].e_texcutX = cutx(PTTERN_TW, e_animation[i], 8);
				e_motion[0].e_texcutY = cuty(PTTERN_TH, e_animation[i], 8);
			}
			else if (e_pattern == 4 || e_pattern == 8)
			{
				e_motion[0].e_texcutX = cutx(PTTERN_TW * 2, e_animation[i], 5);
				e_motion[0].e_texcutY = cuty(PTTERN_TH * 2, e_animation[i], 5);
				b++;
				frame_S = (b / 30) % 20;
				if(frame_S>=11)
				deth_fild = true;
			}

			if (e_deth_chara)
			{
				e_motion[1].e_texcutX = cutx(PTTERN_TW * 2, e_animation[i], 5);
				e_motion[1].e_texcutY = cuty(PTTERN_TH * 2, e_animation[i], 5);
			}

			if (e_animation[i] > MAX_PTTERN)
			{
				e_motion[0].e_motion_flag = false;
				e_motion[1].e_motion_flag = false;
				e_frame_counter[i] = 0;
				e_deth_chara = false;
				frame_S = 0;
				b = 0;
				deth_fild = false;
			}

		}
	}

}

//------------------------------------
//		�G�t�F�N�g�`�揈��
//------------------------------------
void Motion_Draw(void)
{
	//����
	if (motion[0].motion_flag)
	{
		if (pattern <= 2&&pattern!=0)
		{
			if (panchi_cnt >= 2)
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_P3, motion[0].motion_x - 60, motion[0].motion_y, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY1_HIT, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_P, motion[0].motion_x - 60, motion[0].motion_y, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY1_HIT, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
		}
		else if (pattern == 3)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_P, motion[0].motion_x - 50, motion[0].motion_y, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
			Sprite_Draw(kTEXTURE_INDEX_MY1_HIT, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
		}
		else if (pattern == 4)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHOU, motion[0].motion_x - 50, motion[0].motion_y - 50, motion[0].texcutX, 0, PTTERN_TW * 2, PTTERN_TH * 2);
			Sprite_Draw(kTEXTURE_INDEX_MY1_HIT, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
			if (frame == 1)
			{
				ice_fild = true;
				for (int i = 0; i <= 9; i++)
				{
					Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_FILD, 300 + i * 100, 550, motion[0].texcutX, 0, PTTERN_TW*2, PTTERN_TH*2);
				}
			}
			
		}
		else if (pattern < 7 && pattern > 4)
		{
			if (panchi_cnt >= 2)
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_P3, motion[0].motion_x + 60, motion[0].motion_y, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY1_HIT_R, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, (pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_P, motion[0].motion_x + 60, motion[0].motion_y, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY1_HIT_R, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, (pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
		}
		else if (pattern == 7)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_P, motion[0].motion_x + 50, motion[0].motion_y, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
			Sprite_Draw(kTEXTURE_INDEX_MY1_HIT_R, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, (pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
		}
		else if (pattern == 8)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHOU, motion[0].motion_x - 50, motion[0].motion_y - 50, motion[0].texcutX, 0, PTTERN_TW * 2, PTTERN_TH * 2);
			Sprite_Draw(kTEXTURE_INDEX_MY1_HIT_R, motion[0].motion_x, motion[0].motion_y, motion[0].texcutX, (pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
			if (frame == 1)
			{
				ice_fild = true;
				for (int i = 0; i <= 9; i++)
				{
					Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_FILD, 300 + i * 100, 550, motion[0].texcutX, 0, PTTERN_TW*2, PTTERN_TH*2);
				}
			}
		}
		if (pattern == 10)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHI_R, motion[0].motion_x, motion[0].motion_y + 10, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
		}
		else if (pattern == 11)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHI, motion[0].motion_x, motion[0].motion_y + 10, motion[0].texcutX, 0, PTTERN_TW, PTTERN_TH);
		}
	}
	else if (motion[1].motion_flag)
	{
		if (deth_chara)
		{
			Sprite_Draw(kTEXTURE_INDEX_HUKKATU, 250, SCREEN_HEIGHT - SCREEN_HEIGHT / 3 - 100, motion[1].texcutX, 0, PTTERN_TW * 2, PTTERN_TH * 2);
		}
	}

	//�G�l�~�[
	if (e_motion[0].e_motion_flag)
	{
		if (e_pattern <= 2 && e_pattern != 0)
		{
			if (e_panchi_cnt >= 2)
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_P3, e_motion[0].e_motion_x - 60, e_motion[0].e_motion_y, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY2_HIT, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, e_pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_P, e_motion[0].e_motion_x - 60, e_motion[0].e_motion_y, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY2_HIT, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, e_pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
		}
		else if (e_pattern == 3)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_DARK_P, e_motion[0].e_motion_x - 50, e_motion[0].e_motion_y, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
			Sprite_Draw(kTEXTURE_INDEX_MY2_HIT, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, e_pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
		}
		else if (e_pattern == 4)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHOU, e_motion[0].e_motion_x - 50, e_motion[0].e_motion_y - 50, e_motion[0].e_texcutX, 0, PTTERN_TW * 2, PTTERN_TH * 2);
			Sprite_Draw(kTEXTURE_INDEX_MY2_HIT, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, e_pattern * 100 - 100, PTTERN_TW, PTTERN_TH);
			Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_DARK, SCREEN_WIDTH / 2 - 250, SCREEN_HEIGHT / 2 - 250, (frame_S + 4) % 4 * 500, frame_S / 4 * 500, 500, 500);
		}
		else if (e_pattern < 7 && e_pattern > 4)
		{
			if (e_panchi_cnt >= 2)
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_P3, e_motion[0].e_motion_x + 60, e_motion[0].e_motion_y, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY2_HIT_R, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, (e_pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_MY1_P, e_motion[0].e_motion_x + 60, e_motion[0].e_motion_y, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
				Sprite_Draw(kTEXTURE_INDEX_MY2_HIT_R, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, (e_pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
			}
		}
		else if (e_pattern == 7)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_DARK_P, e_motion[0].e_motion_x + 50, e_motion[0].e_motion_y, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
			Sprite_Draw(kTEXTURE_INDEX_MY2_HIT_R, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, (e_pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
		}
		else if (e_pattern == 8)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHOU, e_motion[0].e_motion_x - 50, e_motion[0].e_motion_y - 50, e_motion[0].e_texcutX, 0, PTTERN_TW * 2, PTTERN_TH * 2);
			Sprite_Draw(kTEXTURE_INDEX_MY2_HIT_R, e_motion[0].e_motion_x, e_motion[0].e_motion_y, e_motion[0].e_texcutX, (e_pattern - 4) * 100 - 100, PTTERN_TW, PTTERN_TH);
			Sprite_Draw(kTEXTURE_INDEX_MY1_ICE_DARK, SCREEN_WIDTH / 2 - 250, SCREEN_HEIGHT / 2 - 250, (frame_S + 4) % 4 * 500, frame_S / 4 * 500, 500, 500);
		}
		if (e_pattern == 10)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHI_R, e_motion[0].e_motion_x, e_motion[0].e_motion_y + 10, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
		}
		else if (e_pattern == 11)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_MAHI, e_motion[0].e_motion_x, e_motion[0].e_motion_y + 10, e_motion[0].e_texcutX, 0, PTTERN_TW, PTTERN_TH);
		}
	}
	else if (e_motion[1].e_motion_flag)
	{
		if (e_deth_chara)
		{
			Sprite_Draw(kTEXTURE_INDEX_HUKKATU_E, 1100.f, 550.f, e_motion[1].e_texcutX, 0, PTTERN_TW * 2, PTTERN_TH * 2);
		}
	}
}

//------------------------------------
//		�G�t�F�N�g���쏈��
//------------------------------------
void Motion_Create(float x, float y)
{
	pattern = MotionTech_Pattern();
	if (pattern == 1 || pattern == 5)
	{
		panchi_cnt += 1;
	}
	else if (!(pattern == 1 || pattern == 5))
	{
		panchi_cnt = 0;
	}
	if (panchi_cnt > 2)
	{
		panchi_cnt = 0;
	}

	motion[0].motion_x = x;
	motion[0].motion_y = y;
	motion[0].motion_flag = true;
}


void E_Motion_Create(float x, float y)
{
	e_pattern = E_Motionpattern();
	if (e_pattern == 1 || e_pattern == 5)
	{
		e_panchi_cnt += 1;
	}
	else if (!(e_pattern == 1 || e_pattern == 5))
	{
		e_panchi_cnt = 0;
	}
	if (e_panchi_cnt > 2)
	{
		e_panchi_cnt = 0;
	}

	e_motion[0].e_motion_x = x;
	e_motion[0].e_motion_y = y;
	e_motion[0].e_motion_flag = true;
}


int Motion_End(void)
{
	
	return motion[0].motion_flag;
	
}

int E_Motion_End(void)
{

	return e_motion[0].e_motion_flag;

}

int Deth_chara(bool judge)
{
	deth_chara = judge;
	motion[1].motion_flag = true;
	return false;
}

int E_Deth_chara(bool e_judge)
{
	e_deth_chara = e_judge;
	e_motion[1].e_motion_flag = true;
	return false;
}

int Ice_Fild(void)
{
	return ice_fild;
}

int Deth_Fild(void)
{
	return deth_fild;
}
