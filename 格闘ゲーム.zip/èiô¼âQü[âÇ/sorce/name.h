//=============================================================================
//
// ���U���g�\������ [name.h]
//
//=============================================================================

#ifndef NAME_H_
#define NAME_H_

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include<d3dx9.h>

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Name_Initialize(void);
void Name_Finalize(void);
void Name_Update(void);
void Name_Draw(void);

void Name_SetEffect(float x, float y, float radius, int life, D3DCOLOR color);

#endif //NAME_H_
