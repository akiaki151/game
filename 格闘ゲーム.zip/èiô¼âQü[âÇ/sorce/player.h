//=============================================================================
//
// �v���C���[���� [player.h]
//
//=============================================================================
#ifndef PLAYER_H_
#define PLAYER_H_

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"collision.h"
#define _USE_MATH_DEFINES
#include <math.h>

//------------------------------------
//		�}�N��
//------------------------------------
#define PLAYER_MOVE_SPEED (0.5f)
#define PLAYER_GRAVITY (10.0f)

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Player_Initialize(void);
void Player_Update(void);
void Player_Draw(void);

void Back_texture(void);

void panchi(void);
void Jump(void);
void vector(void);
void Guard(void);
void Right_Chara(void);
void Left_Chara(void);
void waza(void);

const Circle*g_player_a(void);
void Player_Destroy(int index);
int move_x(void);
int move_y(void);
int MotionTech_Pattern(void);
int Judge(void);
int deth(void);
int Hp_End(void);
int Hp(void);
int Waza_Number(void);
int Trance_Player(void);
int Enemy_End_waza(void);
int Player_ORIENT(void);
int Waza_hantei(void);
#endif //PLAYER_H_