//=============================================================================
//
// �Q�[������ [game.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"game.h"
#include"texture.h"
#include"player.h"
#include"enemy.h"
#include"judgement.h"
#include"number.h"
#include"Score.h"
#include"input.h"
#include"debug_font.h"
#include"fade.h"
#include"sprite.h"
#include"effect.h"
#include"bullet.h"
#include"motion.h"
#include"common.h"
#include"name.h"

typedef enum PHASE_INDEX
{
	PHASE_INDEX_FADE,
	PHASE_INDEX_PLAYER_IN,
	PHASE_INDEX_PLAYER_MUTEKI,
	PHASE_INDEX_PLAYER_NORMAL,
	PHASE_INDEX_MAX
};

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static PHASE_INDEX g_Phase;
static int FrameCount = 0;
static bool final;

//------------------------------------
//		�Q�[������������
//------------------------------------
void Game_Initialize(void)
{
	g_Phase = PHASE_INDEX_FADE;
	Effect_Initialize();
	Motion_Initialize;
	Player_Initialize();
	Enemy_Initialize();
	//DebugFont_Initialize();
	judgement_Initialize();
	//return true;
	Bullet_Init();
	Name_Initialize();
}

//------------------------------------
//		�Q�[���I������
//------------------------------------
void Game_Finalize(void)
{
	DebugFont_Finalize();
}

//------------------------------------
//		�Q�[���X�V����
//------------------------------------
void Game_Update(void)
{
	int time = Time();
	final = End();

	if (g_Phase== PHASE_INDEX_FADE)
	{
		switch (g_Phase)
		{
		case PHASE_INDEX_FADE:
			if (!Fade_IsFade())
			{
				g_Phase = PHASE_INDEX_PLAYER_IN;
				Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			}
			break;
		case PHASE_INDEX_PLAYER_IN:
			break;
		case PHASE_INDEX_PLAYER_MUTEKI:
			break;
		case PHASE_INDEX_PLAYER_NORMAL:
			break;
		}
	}
	if (g_Phase == PHASE_INDEX_PLAYER_IN&&final==false)
	{
		if (time <= 180)
		{
			Name_Update();
			Player_Update();
			Enemy_Update();
		}
	}
	if (time <= 180)
	{
		Effect_Update();
		Motion_Update();
		Bullet_Update();
	}
	Judgement_Update();
}

//------------------------------------
//		�Q�[���`�揈��
//------------------------------------
void Game_Draw(void)
{
	Player_Draw();
	Bullet_Draw();
	Enemy_Draw();
	Effect_Draw();
	Motion_Draw();
	Bullet_Draw();
	Name_Draw();
	int time = Time();
	if(time>=100)
	Score_draw(SCREEN_WIDTH/2-64*1.5f, 70.0f, time, 3, false, true);
	else if(time>=10)
	Score_draw(SCREEN_WIDTH / 2 - 64*1.5f+32, 70.0f, time, 2, false, true);
	else 
	Score_draw(SCREEN_WIDTH / 2 - 64*1.5f+64, 70.0f, time, 1, false, true);

	if (time <= 5)
		Sprite_Draw(kTEXTURE_INDEX_END_FINISH, 610.f, 150.f + (5-time) * 80);

	if (time == 183)
	{
		Sprite_Draw(kTEXTURE_INDEX_CNT_3, 0, 0);
		Sprite_Draw(kTEXTURE_INDEX_START_CNT, 0, -200,0.0f,0.0f,1200.f,900.f);
	}
	if (time == 182)
	{
		Sprite_Draw(kTEXTURE_INDEX_CNT_2, 0, 0);
		Sprite_Draw(kTEXTURE_INDEX_START_CNT, 0, -200, 1200.f, 0.0f, 1200.f, 900.f);
	}
	if (time == 181)
	{
		Sprite_Draw(kTEXTURE_INDEX_CNT_1, 0, 0);
		Sprite_Draw(kTEXTURE_INDEX_START_CNT, 200, 100, 2400.f, 0.0f, 1200.f, 900.f);
	}
	if (time == 180)
	{
		Sprite_Draw(kTEXTURE_INDEX_START_CNT, 200, 20, 3600.f, 0.0f, 1200.f, 900.f);
	}
}