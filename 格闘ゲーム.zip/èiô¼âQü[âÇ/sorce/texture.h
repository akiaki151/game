//=============================================================================
//
// �e�N�X�`���`�揈�� [texture.h]
//
//=============================================================================
#ifndef TEXTURE_H
#define TEXTURE_H

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include <windows.h>
#include <d3dx9.h>

//------------------------------------
//		�}�N��
//------------------------------------
#define TEXTURE_FILENAME_MAX (40)

//�ړ��L����
#define TEXTURE_SIZE_CHAR1_X (300)
#define TEXTURE_SIZE_CHAR1_Y (400)

#define TEXTURE_SIZE_CHAR1_W_X (1000)
#define TEXTURE_SIZE_CHAR1_W_Y (600)

//�t�F�C�X�L����
#define TEXTURE_SIZE_CHAR_MOVE (144)
#define TEXTURE_SIZE_CHAR (200)

//�X�^�[�g��ʂ̃����X�^�[�̉摜
#define TEXTURE_SIZE_START_MONSTER (1000)

//�X�R�A�̉摜�c��
#define TEXTURE_NUMBER_SIZE_W (640)
#define TEXTURE_NUMBER_SIZE_H (64)

//�Z�A�j���[�V�����T�C�Y
#define TEXTURE_SIZE_WAZA (400)

//�G�L�����_�E��
#define TEXTURE_ENEMY_DOWN (300)

//�T�C�Y40
#define TEXTURE_FOUR_MINI (40)

//�T�C�Y60
#define TEXTURE_SIX (60)

//�T�C�Y100
#define TEXTURE_ONE (100)

//�T�C�Y120
#define TEXTURE_SIX_2 (120)

//�T�C�Y180
#define TEXTURE_GAZOU (180)

//�T�C�Y200
#define TEXTURE_TWO (200)

//�T�C�Y300
#define TEXTURE_THREE (300)

//�T�C�Y400
#define TEXTURE_FOUR (400)

//�T�C�Y500
#define TEXTURE_FIVE (500)

//�T�C�Y800
#define TEXTURE_EIGHT (800)

//�T�C�Y1000
#define TEXTURE_THOUSAND (1000)

//�X�^�[�g�̃A�j���[�V����
#define TEXTURE_ANIME_X (4000)
#define TEXTURE_ANIME_Y (3200)

//------------------------------------
//		�\����
//------------------------------------
typedef struct TextureFileData_tag
{
	char filename[TEXTURE_FILENAME_MAX];
	int width;
	int height;
}TextureFileData;

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
int Texture_Load(void);
void Texture_Release(void);
LPDIRECT3DTEXTURE9 Texture_GetTexture(int index);
int Texture_GetWidth(int index);
int Texture_GetHeight(int index);

enum {
	kTEXTURE_INDEX_MY1,        //�����̃L�����N�^�[
	kTEXTURE_INDEX_MY2,        //�����̃L�����N�^�[
	kTEXTURE_INDEX_MY3,        //�����̃L�����N�^�[
	kTEXTURE_INDEX_MY4,        //�����̃L�����N�^�[
	kTEXTURE_INDEX_CHAR1,
	kTEXTURE_INDEX_CHAR2,
	kTEXTURE_INDEX_CHAR3,
	kTEXTURE_INDEX_CHAR4,
	kTEXTURE_INDEX_CHAR1_M,
	kTEXTURE_INDEX_CHAR2_M,
	kTEXTURE_INDEX_CHAR3_M,
	kTEXTURE_INDEX_CHAR4_M,
	kTEXTURE_INDEX_TITLE,
	kTEXTURE_INDEX_SCORE,
	kTEXTURE_INDEX_CHARA_SELECT,
	kTEXTURE_INDEX_CPU_SELECT,
	kTEXTURE_INDEX_SELECT,
	kTEXTURE_INDEX_LOAD,
	kTEXTURE_INDEX_STATUS,
	kTEXTURE_INDEX_ATTACK,
	kTEXTURE_INDEX_DIFENCE,
	kTEXTURE_INDEX_FAST,
	kTEXTURE_INDEX_NO_STATUS,
	kTEXTURE_INDEX_NO_LAMP,
	kTEXTURE_INDEX_ICE_TITLE,
	kTEXTURE_INDEX_DARK_TITLE,
	kTEXTURE_INDEX_FIRE_TITLE,
	kTEXTURE_INDEX_LIGHT_TITLE,
	kTEXTURE_INDEX_ICE_S,
	kTEXTURE_INDEX_DARK_S,
	kTEXTURE_INDEX_FIRE_S,
	kTEXTURE_INDEX_LIGHT_S,
	kTEXTURE_INDEX_LIGHT_ANIME,
	kTEXTURE_INDEX_SELECT_BACK,
	kTEXTURE_INDEX_RESULT,
	kTEXTURE_INDEX_TITLE_START,
	kTEXTURE_INDEX_STAGE1,
	kTEXTURE_INDEX_ENEMY1,
	kTEXTURE_INDEX_ENEMY1_R,
	kTEXTURE_INDEX_PLAYER1,
	kTEXTURE_INDEX_PLAYER1_R,
	kTEXTURE_INDEX_GAME1,
	kTEXTURE_INDEX_GAME2,
	kTEXTURE_INDEX_GAME3,
	kTEXTURE_INDEX_ASHIBA,
	kTEXTURE_INDEX_CHARA1_P,
	kTEXTURE_INDEX_CHARA2_P,
	kTEXTURE_INDEX_TORI,
	kTEXTURE_INDEX_CAT,
	kTEXTURE_INDEX_TAKIBI,
	kTEXTURE_INDEX_GAKU,
	kTEXTURE_INDEX_LIFE_RED,
	kTEXTURE_INDEX_LIFE_BULE,
	kTEXTURE_INDEX_FIRE,
	kTEXTURE_INDEX_HUKKATU,
	kTEXTURE_INDEX_HUKKATU_E,
	kTEXTURE_INDEX_FUNE,
	kTEXTURE_INDEX_HISCORE,
	kTEXTURE_INDEX_G,
	kTEXTURE_INDEX_G_B,
	kTEXTURE_INDEX_MY1_HIT,
	kTEXTURE_INDEX_MY1_HIT_R,
	kTEXTURE_INDEX_MY2_HIT,
	kTEXTURE_INDEX_MY2_HIT_R,
	kTEXTURE_INDEX_MY1_WAZA1,
	kTEXTURE_INDEX_ENEMY_WAZA1,
	kTEXTURE_INDEX_MY1_WAZA1_S,
	kTEXTURE_INDEX_ENEMY_WAZA1_S,
	kTEXTURE_INDEX_MY1_SHADOW,
	kTEXTURE_INDEX_MY1_MAHI,
	kTEXTURE_INDEX_MY1_MAHI_R,
	kTEXTURE_INDEX_MY1_ICE_P,
	kTEXTURE_INDEX_MY1_DARK_P,
	kTEXTURE_INDEX_MY1_P,
	kTEXTURE_INDEX_MY1_ICE_P3,
	kTEXTURE_INDEX_MY1_MAHOU,
	kTEXTURE_INDEX_MY1_ICE_FILD,
	kTEXTURE_INDEX_MY1_ICE_DARK,
	kTEXTURE_INDEX_END_WAZA,
	kTEXTURE_INDEX_END_RESULT2,
	kTEXTURE_INDEX_START_CNT,
	kTEXTURE_INDEX_END_FINISH,
	kTEXTURE_INDEX_CNT_3,
	kTEXTURE_INDEX_CNT_2,
	kTEXTURE_INDEX_CNT_1,
	kTEXTURE_INDEX_BUTTOBI,
};

#endif // !TEXTURE_H

