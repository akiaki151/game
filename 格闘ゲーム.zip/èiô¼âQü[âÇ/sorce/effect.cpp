//=============================================================================
//
// �G�t�F�N�g�\������ [effect.cpp]
//
//=============================================================================
#include"effect.h"
#include"bullet.h"
#include"sprite.h"
#include"texture.h"
#include"judgement.h"
#include"animetion.h"
#include"input.h"
#include"player.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static int frame_counter[EFFECT_MAX];
static int animation[EFFECT_MAX];
static int EffectCreateFrame[EFFECT_MAX];
static int PtternEffect[EFFECT_MAX];
EFFECT effect[EFFECT_MAX];
static int index;

//------------------------------------
//		�G�t�F�N�g����������
//------------------------------------
void Effect_Initialize(void)
{
	for (int i = 0; i < EFFECT_MAX; i++)
	{
		effect[i].Effect_flag = false;
		effect[i].E_Effect_flag = false;
		frame_counter[i] = 0;
		animation[i] = 0;
		EffectCreateFrame[i] = 0;
		effect[i].effect_x = 0;
		effect[i].effect_y = 0;
		PtternEffect[i] = 0;
		effect[i].texcutX = 0;
		effect[i].texcutY = 0;
	}
}

//------------------------------------
//		�G�t�F�N�g�I������
//------------------------------------
void Effect_Finalize(void)
{

}

//------------------------------------
//		�G�t�F�N�g�X�V����
//------------------------------------
void Effect_Update(void)
{
	for (int i = 0; i < EFFECT_MAX; i++)
	{
		if (effect[i].Effect_flag)
		{
			frame_counter[i]++;
			animation[i] = texanimetions(frame_counter[i], WAIT_FRAME);
			effect[i].texcutX = cutx(PTTERN_TW, animation[i], 5);
			effect[i].texcutY = cuty(PTTERN_TH, animation[i], 5);
			if (animation[i] > MAX_PTTERN)
			{
				effect[i].Effect_flag = false;
				frame_counter[i] = 0;
			}
		}
	}

	for (int i = 0; i < EFFECT_MAX; i++)
	{
		if (effect[i].E_Effect_flag)
		{
			frame_counter[i]++;
			animation[i] = texanimetions(frame_counter[i], WAIT_FRAME);
			effect[i].texcutX = cutx(PTTERN_TW, animation[i], 5);
			effect[i].texcutY = cuty(PTTERN_TH, animation[i], 5);
			if (animation[i] > MAX_PTTERN)
			{
				effect[i].E_Effect_flag = false;
				frame_counter[i] = 0;
			}
		}
	}
	
}

//------------------------------------
//		�G�t�F�N�g�`�揈��
//------------------------------------
void Effect_Draw(void)
{
	for (int i = 0; i < EFFECT_MAX; i++)
	{
		if (effect[i].Effect_flag)
		{
			Sprite_Draw(kTEXTURE_INDEX_MY1_WAZA1, effect[i].effect_x-100, effect[i].effect_y-100, effect[i].texcutX, effect[i].texcutY, PTTERN_TW, PTTERN_TH);
		}
		if (effect[i].E_Effect_flag)
		{
			Sprite_Draw(kTEXTURE_INDEX_ENEMY_WAZA1, effect[i].effect_x - 100, effect[i].effect_y - 100, effect[i].texcutX, effect[i].texcutY, PTTERN_TW, PTTERN_TH);
		}
	}
}

//------------------------------------
//		�G�t�F�N�g���쏈��
//------------------------------------
void Effect_Create(float x, float y)
{ 
	index++;
	effect[index].effect_x = x; 
	effect[index].effect_y = y;
	effect[index].Effect_flag = true;
	if (index >= EFFECT_MAX-1)
	{
		index = 0;
	}
}

void E_Effect_Create(float x, float y)
{
	index++;
	effect[index].effect_x = x;
	effect[index].effect_y = y;
	effect[index].E_Effect_flag = true;
	if (index >= EFFECT_MAX - 1)
	{
		index = 0;
	}
}


