//=============================================================================
//
// �����蔻�菈�� [judgement.h]
//
//=============================================================================
#ifndef JUDGEMENT_H
#define JUDGEMENT_H

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Judgement_Update(void);
int GetScore(void);
void judgement_Initialize(void);
int Time(void);
int End(void);
int GetHp(void);
#endif	//JUDGEMENT_H