//=============================================================================
//
// ���U���g�\������ [name.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"mydirect.h"
#include<d3dx9.h>
#include"name.h"
#include"texture.h"

//------------------------------------
//	�}�N��
//------------------------------------
#define EFFECT_COUNT_MAX (1000)

//------------------------------------
//		�\����
//------------------------------------
typedef struct Effect_tag
{
	float x, y;
	float radius;
	D3DCOLOR color;
	float alpha;
	int life;
	int birth;
}Effect;

typedef struct EffectVertex_tag
{
	D3DXVECTOR4 position;
	D3DCOLOR color;
	D3DXVECTOR2 texcoord;
}EffectVertex;

#define FVF_EFFECT (D3DFVF_XYZRHW| D3DFVF_DIFFUSE|D3DFVF_TEX1)

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static int g_EffectFrameCount = 0;
static Effect g_Effects[EFFECT_COUNT_MAX];
static LPDIRECT3DVERTEXBUFFER9 g_pVertexBuffer;
static LPDIRECT3DINDEXBUFFER9 g_pIndexBuffer;
static int g_EffectCount = 0;

//------------------------------------
//		����������
//------------------------------------
void Name_Initialize(void)
{
	g_EffectFrameCount = 0;
	g_EffectCount = 0;
	for (int i = 0; i < EFFECT_COUNT_MAX; i++)
	{
		g_Effects[i].life = -1;
	}

	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	pDevice->CreateVertexBuffer(sizeof(EffectVertex) * 4 * EFFECT_COUNT_MAX, D3DUSAGE_WRITEONLY, FVF_EFFECT, D3DPOOL_MANAGED, &g_pVertexBuffer, NULL);
	pDevice->CreateIndexBuffer(sizeof(WORD) * 6 * EFFECT_COUNT_MAX, D3DUSAGE_WRITEONLY, D3DFMT_INDEX16, D3DPOOL_MANAGED, &g_pIndexBuffer, NULL);
}

//------------------------------------
//		�I������
//------------------------------------
void Name_Finalize(void)
{
	
}

//------------------------------------
//		�X�V����
//------------------------------------
void Name_Update(void)
{
	g_EffectCount = 0;

	for (int i = 0; i < EFFECT_COUNT_MAX; i++)
	{
		if (g_Effects[i].life >= 0)
		{
			int age = g_EffectFrameCount - g_Effects[i].birth;

			if (age >= g_Effects[i].life)
			{
				g_Effects[i].life = -1;
				continue;
			}

			g_Effects[i].alpha = 1.0f - age / g_Effects[i].life;

			g_Effects[i].radius *= 0.9f;

			g_EffectCount++;
		}
	}

	EffectVertex* pV;
	g_pVertexBuffer->Lock(0,0,(void**)&pV,0);

	WORD* pIndex;
	g_pIndexBuffer->Lock(0, 0, (void**)&pIndex, 0);

	int n = 0;
	for (int i = 0; i < EFFECT_COUNT_MAX; i++)
	{
		if (g_Effects[i].life >= 0)
		{
			D3DXCOLOR color = g_Effects[i].color;
			color.a = g_Effects[i].alpha;

			for (int j = 0; j < 4; j++)
			{
				pV[n * 4 + j].position.x = cos(D3DXToRadian(45+90*j))*g_Effects[i].radius + g_Effects[i].x;
				pV[n * 4 + j].position.y = sin(D3DXToRadian(45+90*j))*g_Effects[i].radius + g_Effects[i].y;
				pV[n * 4 + j].position.z = 1.0f;
				pV[n * 4 + j].position.w = 1.0f;
				pV[n * 4 + j].color = color;
			}

			pV[n * 4 + 0].texcoord = D3DXVECTOR2(0.0f, 0.0f);
			pV[n * 4 + 1].texcoord = D3DXVECTOR2(1.0f, 0.0f);
			pV[n * 4 + 2].texcoord = D3DXVECTOR2(1.0f, 1.0f);
			pV[n * 4 + 3].texcoord = D3DXVECTOR2(0.0f, 1.0f);


			pIndex[n * 6 + 0] = n * 4 + 0;
			pIndex[n * 6 + 1] = n * 4 + 1;
			pIndex[n * 6 + 2] = n * 4 + 2;
			pIndex[n * 6 + 3] = n * 4 + 2;
			pIndex[n * 6 + 4] = n * 4 + 3;
			pIndex[n * 6 + 5] = n * 4 + 0;


			n++;
		}
	}
	g_pVertexBuffer->Unlock();
	g_pIndexBuffer->Unlock();

	g_EffectFrameCount++;
}

//------------------------------------
//		�`�扻����
//------------------------------------
void Name_Draw(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	pDevice->SetStreamSource(0, g_pVertexBuffer, 0, sizeof(EffectVertex));
	pDevice->SetIndices(g_pIndexBuffer);
	pDevice->SetFVF(FVF_EFFECT);
	pDevice->SetTexture(0,Texture_GetTexture(kTEXTURE_INDEX_MY1_WAZA1_S));
	

	//���Z�����@SrcRGB*Srca + DestRGB * (1.0f-Srca);
	pDevice->SetRenderState(D3DRS_DESTBLEND, D3DBLEND_ONE);

	pDevice->SetRenderState(D3DRS_ZWRITEENABLE,FALSE);
	
	pDevice->DrawIndexedPrimitive(D3DPT_TRIANGLELIST,0,0,4*g_EffectCount,0,2* g_EffectCount);

	pDevice->SetRenderState(D3DRS_ZWRITEENABLE, TRUE);

	//�������@�@SrcRGB*Srca + DestRGB *1.0f;
	pDevice->SetRenderState(D3DRS_SRCBLEND, D3DBLEND_SRCALPHA);

}

//------------------------------------
//		��������
//------------------------------------
void Name_SetEffect(float x, float y, float radius, int life, D3DCOLOR color)
{
	for (int i = 0; i < EFFECT_COUNT_MAX; i++)
	{
		if (g_Effects[i].life < 0)
		{
			g_Effects[i].alpha = 1.0f;
			g_Effects[i].birth = g_EffectFrameCount;
			g_Effects[i].color = color;
			g_Effects[i].life = life;
			g_Effects[i].radius = radius;
			g_Effects[i].x = x;
			g_Effects[i].y = y;
			break;
		}
	}
}
