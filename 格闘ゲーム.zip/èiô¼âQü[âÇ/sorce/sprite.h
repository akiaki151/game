//=============================================================================
//
// �X�v���C�g�\������ [sprite.h]
//
//=============================================================================
#ifndef SPRITE_H_
#define SPRITE_H_

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Sprite_Initialize(void);
void Sprite_Finalize(void);
void Sprite_Draw(int texture_index, float dx, float dy);
void Sprite_Draw(int texture_index, float dx, float dy, int tx, int ty, int tw, int th);
void Sprite_Draw_R(int texture_index, float dx, float dy, int tx, int ty, int tw, int th);
void Sprite_Draw(int texture_index, float dx, float dy, int tx, int ty, int tw, int th, float cx, float cy, float sx, float sy, float rotation);
void Sprite_Draw2(int texture_index, float dx, float dy);
void Sprite_Draw_A(int texture_index, float dx, float dy);
void Sprite_Draw_RED(int texture_index, float dx, float dy, int tx, int ty, int tw, int th);
#endif //!SPRITE_H_

