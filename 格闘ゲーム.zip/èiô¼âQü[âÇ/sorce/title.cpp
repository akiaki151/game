//=============================================================================
//
// �^�C�g���\������ [title.h]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"scene.h"
#include"input.h"
#include"texture.h"
#include"sprite.h"
#include"fade.h"
#include"title.h"
#include"common.h"
#include "sound.h"
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static bool g_bEnd = false;
static int count = 0;
static int select_c = 0;
static int frame = 0;
static int cnt = 0;
static float a = 0.0f;
static int b = 0;
static int frame_S = 0;
static int cnt_title = 0;
static bool mode = false;
//------------------------------------
//		����������
//------------------------------------
void Title_Initialize(void)
{
	g_bEnd = false;
	count = 0;
	select_c = 0;
	frame = 0;
	cnt = 0;
	a = 0.0f;
	b = 0;
	frame = 0;
	cnt_title = 0;
	mode = false;
}

//------------------------------------
//		�I������
//------------------------------------
void Title_Finalize(void)
{

}

//------------------------------------
//		�X�V����
//------------------------------------
void Title_Update(void)
{
	if (a <= 400)
		a += 2.0f;
	else
		b++;


	frame_S = (b / 8) % 20;

	if (!g_bEnd)
	{
		if (Keyboard_IsTrigger(DIK_SPACE))
		{
			PlaySound(SOUND_SPACE_BOTTON);
			count += 1;
			if (count == 2)
			{
				PlaySound(SOUND_BGM_SELECT);
			}
		}
		if (count==5)
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			g_bEnd = true;
			PlaySound(SOUND_BATTLE_BGM);
		}
		if (Keyboard_IsTrigger(DIK_RIGHT))
		{
			PlaySound(SOUND_SELECT);
			if (select_c == 0)
			{
				select_c = 1;
			}
			else if (select_c == 2)
			{
				select_c = 3;
			}
		}
		if (Keyboard_IsTrigger(DIK_LEFT))
		{
			PlaySound(SOUND_SELECT);
			if (select_c == 1)
			{
				select_c = 0;
			}
			else if (select_c == 3)
			{
				select_c = 2;
			}
		}
		if (Keyboard_IsTrigger(DIK_UP))
		{
			PlaySound(SOUND_SELECT);
			if (select_c == 2)
			{
				select_c = 0;
			}
			else if (select_c == 3)
			{
				select_c = 1;
			}
			if (cnt_title == 0)
			{
				cnt_title = 2;
			}
			else
			cnt_title -= 1;
		}
		if (Keyboard_IsTrigger(DIK_DOWN))
		{
			PlaySound(SOUND_SELECT);
			if (select_c == 0)
			{
				select_c = 2;
			}
			else if (select_c == 1)
			{
				select_c = 3;
			}
			if (cnt_title == 2)
			{
				cnt_title = 0;
			}
			else
				cnt_title += 1;
		}
	}

	if (g_bEnd)
	{
		if (!Fade_IsFade())
		{
			Scene_Change(SCENE_INDEX_GAME);
		}
	}
	
	frame = (cnt / 16) % 3;
	cnt++;
}

//------------------------------------
//		�`�揈��
//------------------------------------
void Title_Draw(void)
{
	if (count == 0)
	{
		Sprite_Draw(kTEXTURE_INDEX_TITLE, 0, 0);
		Sprite_Draw_A(kTEXTURE_INDEX_ICE_TITLE, 200+a, 50);
		Sprite_Draw_A(kTEXTURE_INDEX_DARK_TITLE,1000-a, 50);
		Sprite_Draw_A(kTEXTURE_INDEX_FIRE_TITLE, 200+a, 450);
		Sprite_Draw_A(kTEXTURE_INDEX_LIGHT_TITLE, 1000-a, 450);

		if (b > 0 && b <= 125)
		{
			Sprite_Draw(kTEXTURE_INDEX_LIGHT_ANIME, SCREEN_WIDTH / 2 - 400, SCREEN_HEIGHT / 2 - 400, (frame_S + 4) % 4 * 800, frame_S / 4 * 800, 800, 800);
		}
		else if (b > 125)
		{
			count = 1;
		}
	}
	else if (count == 1)
	{
		Sprite_Draw(kTEXTURE_INDEX_TITLE_START, 0, 0);
		if (cnt_title == 0)
		{
			Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 650, 335, frame * 60, 0, 60, 60);
			Sprite_Draw_A(kTEXTURE_INDEX_ICE_TITLE, SCREEN_HEIGHT / 2 + 200, SCREEN_HEIGHT / 2 - 200);

			if (Keyboard_IsTrigger(DIK_DOWN))
			{
				mode = false;
			}

		}
		else if (cnt_title == 1)
		{
			Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 620, 470, frame * 60, 0, 60, 60);
			Sprite_Draw_A(kTEXTURE_INDEX_DARK_TITLE, SCREEN_HEIGHT / 2 + 200, SCREEN_HEIGHT / 2 - 200);

			if (Keyboard_IsTrigger(DIK_DOWN))
			{
				mode = true;
			}


		}
		else
		{
			Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 600, 600, frame * 60, 0, 60, 60);
			Sprite_Draw_A(kTEXTURE_INDEX_LIGHT_TITLE, SCREEN_HEIGHT / 2 + 200, SCREEN_HEIGHT / 2 - 200);
		}

		select_c = 0;
	}


	if (count > 1)
	{
		Sprite_Draw(kTEXTURE_INDEX_CHARA_SELECT, 0, 0);
		//Sprite_Draw(kTEXTURE_INDEX_SELECT_BACK, SCREEN_WIDTH / 2-200, 0);
		Sprite_Draw(kTEXTURE_INDEX_CHAR1, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR1_X / 2, TEXTURE_SIZE_CHAR- TEXTURE_SIZE_CHAR_MOVE);
		Sprite_Draw(kTEXTURE_INDEX_CHAR2, SCREEN_WIDTH / 2, TEXTURE_SIZE_CHAR- TEXTURE_SIZE_CHAR_MOVE);
		Sprite_Draw(kTEXTURE_INDEX_CHAR3, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR1_X / 2, TEXTURE_SIZE_CHAR);
		Sprite_Draw(kTEXTURE_INDEX_CHAR4, SCREEN_WIDTH / 2, TEXTURE_SIZE_CHAR);

		Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 550, 100, frame * 60, 0, 60, 60);
		Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 10, 100, frame * 60, 60, 60, 60);
		Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 1000, 100, frame * 60, 0, 60, 60);
		Sprite_Draw(kTEXTURE_INDEX_NO_LAMP, 1550, 100, frame * 60, 60, 60, 60);


		if (count < 4)
		{
			
			if (select_c == 0)
			{
				if (count == 2)
				{
					Sprite_Draw(kTEXTURE_INDEX_CPU_SELECT, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR1_X / 2, TEXTURE_SIZE_CHAR - TEXTURE_SIZE_CHAR_MOVE);
				}
				else
				{
					Sprite_Draw(kTEXTURE_INDEX_SELECT, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR1_X / 2, TEXTURE_SIZE_CHAR - TEXTURE_SIZE_CHAR_MOVE);
				}
				Sprite_Draw(kTEXTURE_INDEX_CHAR1_M, TEXTURE_SIZE_CHAR, 500);
				Sprite_Draw(kTEXTURE_INDEX_MY1, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR / 2, 600, 100, 0, 100, 100);
				Sprite_Draw(kTEXTURE_INDEX_STATUS, SCREEN_WIDTH - 500, 500);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 425, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 365, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 550, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_DIFENCE, SCREEN_WIDTH - 425, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 365, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 640, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 425, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 365, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 740, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_ICE_S, SCREEN_WIDTH - 225, 640, (frame_S + 5) % 5 * 200, frame_S / 5 * 200, 200, 200);
			}
			if (select_c == 1)
			{
				Sprite_Draw(kTEXTURE_INDEX_CHAR2_M, TEXTURE_SIZE_CHAR, 500);
				if (count == 2)
				{
					Sprite_Draw(kTEXTURE_INDEX_CPU_SELECT, SCREEN_WIDTH / 2, TEXTURE_SIZE_CHAR - TEXTURE_SIZE_CHAR_MOVE);
				}
				else
				{
					Sprite_Draw(kTEXTURE_INDEX_SELECT, SCREEN_WIDTH / 2, TEXTURE_SIZE_CHAR - TEXTURE_SIZE_CHAR_MOVE);
				}
				Sprite_Draw(kTEXTURE_INDEX_MY2, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR / 2, 600, 100, 0, 100, 100);
				Sprite_Draw(kTEXTURE_INDEX_STATUS, SCREEN_WIDTH - 500, 500);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 425, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 365, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 550, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 425, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 365, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 640, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 425, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 365, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 305, 740, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_DARK_S, SCREEN_WIDTH - 225, 640, (frame_S + 5) % 5 * 200, frame_S / 5 * 200, 200, 200);
			}
			if (select_c == 2)
			{
				Sprite_Draw(kTEXTURE_INDEX_CHAR3_M, TEXTURE_SIZE_CHAR, 500);
				if (count == 2)
				{
					Sprite_Draw(kTEXTURE_INDEX_CPU_SELECT, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR1_X / 2, TEXTURE_SIZE_CHAR);
				}
				else
				{
					Sprite_Draw(kTEXTURE_INDEX_SELECT, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR1_X / 2, TEXTURE_SIZE_CHAR);
				}
				Sprite_Draw(kTEXTURE_INDEX_MY3, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR / 2, 600, 100, 0, 100, 100);
				Sprite_Draw(kTEXTURE_INDEX_STATUS, SCREEN_WIDTH - 500, 500);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 425, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 365, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_ATTACK, SCREEN_WIDTH - 305, 550, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 425, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 365, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 640, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 425, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 365, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 740, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_FIRE_S, SCREEN_WIDTH - 225, 640, (frame_S + 5) % 5 * 200, frame_S / 5 * 200, 200, 200);
			}
			if (select_c == 3)
			{
				Sprite_Draw(kTEXTURE_INDEX_CHAR4_M, TEXTURE_SIZE_CHAR, 500);
				if (count == 2)
				{
					Sprite_Draw(kTEXTURE_INDEX_CPU_SELECT, SCREEN_WIDTH / 2, TEXTURE_SIZE_CHAR);
				}
				else
				{
					Sprite_Draw(kTEXTURE_INDEX_SELECT, SCREEN_WIDTH / 2, TEXTURE_SIZE_CHAR);
				}
				Sprite_Draw(kTEXTURE_INDEX_STATUS, SCREEN_WIDTH - 500, 500);
				Sprite_Draw(kTEXTURE_INDEX_MY4, SCREEN_WIDTH / 2 - TEXTURE_SIZE_CHAR / 2, 600, 100, 0, 100, 100);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 425, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 365, 550, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_NO_STATUS, SCREEN_WIDTH - 305, 550, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_DIFENCE, SCREEN_WIDTH - 425, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_DIFENCE, SCREEN_WIDTH - 365, 640, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_DIFENCE, SCREEN_WIDTH - 305, 640, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 425, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 365, 740, frame * 60, 0, 60, 60);
				Sprite_Draw(kTEXTURE_INDEX_FAST, SCREEN_WIDTH - 305, 740, frame * 60, 0, 60, 60);

				Sprite_Draw(kTEXTURE_INDEX_LIGHT_S, SCREEN_WIDTH - 225, 640, (frame_S + 5) % 5 * 200, frame_S / 5 * 200, 200, 200);
			}
		}
		if (count >= 3)
			Sprite_Draw(kTEXTURE_INDEX_CHAR1_M, TEXTURE_SIZE_CHAR, 200);
		if (count >= 4)
			Sprite_Draw(kTEXTURE_INDEX_CHAR2_M, SCREEN_WIDTH - TEXTURE_SIZE_CHAR * 2, 200);
	}

}
int Chara_Select(void)
{
	StopSound(SOUND_SPACE_BOTTON);
	StopSound(SOUND_BGM_SELECT);
	return 0;
}

int Mode_Select(void)
{
	return mode;
}