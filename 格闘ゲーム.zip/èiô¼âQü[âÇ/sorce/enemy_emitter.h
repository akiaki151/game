//=============================================================================
//
// �G�l�~�[�G�~�b�^�[���� [enemy_emitter.h]
//
//=============================================================================

#ifndef ENEMY_EMITTER_H_
#define ENEMY_EMITTER_H_

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Enemy_Emitter_Initialize(void);
void Enemy_Emitter_Finalize(void);
void Enemy_Emitter_Update(void);

#endif //ENEMY_EMITTER_H_
