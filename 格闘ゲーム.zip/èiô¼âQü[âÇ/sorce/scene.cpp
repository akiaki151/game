//=============================================================================
//
// �V�[���\������ [scene.h]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"scene.h"
#include"title.h"
#include"texture.h"
#include"game.h"
#include"result.h"


//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static SCENE_INDEX g_SceneIndex;
static SCENE_INDEX g_SceneNextIndex;

//------------------------------------
//		�֐��|�C���^
//------------------------------------
typedef void (*SceneFunc)(void);

//------------------------------------
//		switch���Ɠ�������
//------------------------------------
static const SceneFunc Initialize[] = {
	Title_Initialize,
	Game_Initialize,
	Result_Initialize
};

static const SceneFunc Finalize[] = {
	Title_Finalize,
	Game_Finalize,
	Result_Finalize
};

static const SceneFunc Update[] = {
	Title_Update,
	Game_Update,
	Result_Update
};

static const SceneFunc Draw[] = {
	Title_Draw,
	Game_Draw,
	Result_Draw
};

//------------------------------------
//		����������
//------------------------------------
void Scene_Initialize(SCENE_INDEX index)
{
	if (Texture_Load() > 0)
	{
		//return false;
	}
	g_SceneNextIndex = g_SceneIndex=index;

	Initialize[g_SceneIndex]();
}

//------------------------------------
//		�I������
//------------------------------------
void Scene_Finalize(void)
{
	Finalize[g_SceneIndex]();

}

//------------------------------------
//		�X�V����
//------------------------------------
void Scene_Update(void)
{
	Update[g_SceneIndex]();
}

//------------------------------------
//		�`�揈��
//------------------------------------
void Scene_Draw(void)
{
	Draw[g_SceneIndex]();
}

//------------------------------------
//		���菈��
//------------------------------------
void Scene_Check(void)
{
	if (g_SceneIndex != g_SceneNextIndex) {
		Scene_Finalize();
		Scene_Initialize(g_SceneNextIndex);
	}
}

//------------------------------------
//		�V�[���؂�ւ�����
//------------------------------------
void Scene_Change(SCENE_INDEX index)
{
	g_SceneNextIndex = index;
}

