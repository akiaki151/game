//=============================================================================
//
// �G�l�~�[�G�~�b�^�[���� [enemy_emitter.h]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include "common.h"
#include "enemy.h"

//------------------------------------
//		�\����
//------------------------------------
typedef struct EnemyEmitter_tag
{
	float x, y;
	int frame;

}EnemyEmitter;


static const EnemyEmitter g_EE[] = {
	{ SCREEN_WIDTH,100.0f,60},
    { SCREEN_WIDTH,200.0f,60 },
    { SCREEN_WIDTH,300.0f,60 },
    { SCREEN_WIDTH,400.0f,60 },
    { SCREEN_WIDTH,500.0f,60 },
    
	{ SCREEN_WIDTH,500.0f,120 },
    { SCREEN_WIDTH,100.0f,120+30 },
    { SCREEN_WIDTH,200.0f,120+60 },
    { SCREEN_WIDTH,300.0f,120+90 },
    { SCREEN_WIDTH,400.0f,120+120},

	{0.0f,0.0f,-1}
};

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static int g_FrameCount = 0;
static int g_Index = 0;

void Enemy_Emitter_Initialize(void)
{

	g_FrameCount = 0;
	g_Index = 0;

}

void Enemy_Emitter_Finalize(void)
{

}

void Enemy_Emitter_Update(void)
{
	for (;;)
	{
		if (g_EE[g_Index].frame < 0)
		{
			break;
		}
		else if (g_EE[g_Index].frame <= g_FrameCount)
		{
			Enemy_Create(g_EE[g_Index].x, g_EE[g_Index].y);
			g_Index++;
		}
		else {
			break;
		}
	}

	g_FrameCount++;

}