
//=============================================================================
//
// �f�o�b�N���� [debug_font.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include <windows.h>
#include <d3dx9.h>
#include "common.h"
#include "debug_font.h"
#include "mydirect.h"

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static LPD3DXFONT g_pD3DXFont = NULL;

//------------------------------------
//		�Q�[������������
//------------------------------------
#if defined(_DEBUG) || defined(DEBUG)
void DebugFont_Initialize(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	D3DXCreateFont(pDevice,30,0,0,0,FALSE,SHIFTJIS_CHARSET,OUT_DEFAULT_PRECIS,DEFAULT_QUALITY,DEFAULT_PITCH,"Terminal",&g_pD3DXFont);
}
#endif	//(_DEBUG) || defined(DEBUG)

//------------------------------------
//		�Q�[���I������
//------------------------------------
#if defined(_DEBUG) || defined(DEBUG)
void DebugFont_Finalize(void)
{
	if (g_pD3DXFont)
	{
		g_pD3DXFont->Release();
		g_pD3DXFont = NULL;
	}
}
#endif	//(_DEBUG) || defined(DEBUG)

//------------------------------------
//		�`�揈��
//------------------------------------
#if defined(_DEBUG) || defined(DEBUG)
void DebugFont_Draw(void)
{
	RECT rect = {250,SCREEN_HEIGHT/2,SCREEN_WIDTH,SCREEN_HEIGHT};
	g_pD3DXFont->DrawText(NULL,"  ���Ȃ��̃X�R�A",-1,&rect,DT_LEFT,D3DCOLOR_RGBA(0,255,0,255));
}
#endif	//(_DEBUG) || defined(DEBUG)

//------------------------------------
//		�`�揈��
//------------------------------------
#if defined(_DEBUG) || defined(DEBUG)
void DebugFont_Draw2(void)
{
	RECT rect = { 650,0,SCREEN_WIDTH,SCREEN_HEIGHT };
	g_pD3DXFont->DrawText(NULL, "  �c�莞��", -1, &rect, DT_LEFT, D3DCOLOR_RGBA(0, 255, 0, 255));
}
#endif	//(_DEBUG) || defined(DEBUG)
