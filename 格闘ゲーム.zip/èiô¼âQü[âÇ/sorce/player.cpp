//=============================================================================
//
// �v���C���[���� [player.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include "texture.h"
#include "sprite.h"
#include "player.h"
#include "input.h"
#include "common.h"
#include "collision.h"
#include "debug_primitive.h"
#include "title.h"
#include "bullet.h"
#include "motion.h"
#include "judgement.h"
#include "Score.h"
#include "sound.h"
#include "effect.h"
#include "name.h"
#include "enemy.h"

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
//�v���C���[�̈ړ��Ɋւ������
static float g_PlayerX;     //X���W
static float g_PlayerY;     //Y���W
static D3DXVECTOR2 g_PlayerSpeed(0.0f, 0.0f);   //�x�N�g���̃X�s�[�h


//�����蔻��
Circle g_player;       //�o���b�g�̓����蔻��R���W����

//�e�N�X�`���T�C�Y�̐؂���
static float g_PlayerWidth;     //X�T�C�Y�̃J�b�g
static float g_PlayerHeight;    //Y�T�C�Y�̃J�b�g

//�L�����̗̑�
static int Rest_life = 2;       //�c�@
static bool Deth_player;        //�c�@�̌�������
static float Player_Hp = 0;     //�̗̓Q�[�W
static bool hp_end;             //�v���C���[���S(����)

//�L�����N�^�[�̌���
static int orientation = 0;    //����

//�L�����ړ��t���[��
static int chara_frame = 0;    //�L�����ړ��t���[��
static int frame = 0;          //�ړ��t���[����

//�L�����K�[�h
static int chara_frame_g = 0;  //�L�����K�[�h�t���[��
static int frame_g = 0;        //�L�����K�[�h�t���[����
static bool G_Motion = false;  //�K�[�h�����̔���

//�w�i�X�N���[��
static float scroll_x = 0.0f;  //�w�i��ʂ��X�N���[�����邽�߂̃J�E���g
static int scroll = 0;         //���̉��A�j���[�V����
static float scroll_D = 0.0f;  //�����̃A�j���[�V����

//�W�����v
static int Judge_Jump = 0;     //�W�����v����
static float Cnt_Jump = 0.0f;  //�W�����v����]�̃J�E���g
static int Jump_Up_frame = 0;  //�W�����v�̍����t���[���̔�
static int Jump_Up_Cnt = 0;    //�W�����v�J�E���g

//�Z
static int Tech_Pattern = 0;   //�Z�̎�ނ̔���
static bool motion = false;    //�Z�̑҂����Ԕ���
static bool judge = false;     //�e�𐶐����܂�
static int waza_number;        //�Z�̎�ނ̒l��Ԃ�
static bool trans = false;
static bool trans_judge = false;

static bool panchi_judge = false;
static bool panchi_S_judge = false;
static bool ice_judge = false;
static bool jump_judge = false;

//�t������������
static int p_motion_chara;
static int p_scroll_chara;
static int p_waza_hantei = 0;
static float p_muteki = 0;
static int p_Rest_life = 0;
static int p_i = 0;
static bool p_end = false;
static int a = 0;//��_���[�W��{
static int b = 0;//��_���[�W����ɓ�{
static bool trans_enemy = false;
static bool End_waza = false;
static bool player_end_waza = false;
static bool enemy_end_waza = false;
static bool huttobi = false;
static bool judge_huttobi;
//------------------------------------
//		����������
//------------------------------------
void Player_Initialize(void) {
	g_PlayerSpeed = D3DXVECTOR2(0.0f, 0.0f);
	g_PlayerX = 350;
	g_PlayerY = 650;
	g_PlayerWidth = Texture_GetWidth(kTEXTURE_INDEX_MY1);
	g_PlayerHeight = Texture_GetHeight(kTEXTURE_INDEX_MY1);
	orientation = 0;
	chara_frame = 0;
	g_player.Centerx = 0.0f;
	g_player.Centery = 0.0f;
	g_player.Radious = 50;
	scroll_x = 0.0f;
	frame = 0;
	Judge_Jump = 2;
	Cnt_Jump = 0.0f;
	G_Motion = false;
	scroll = 0;
	Tech_Pattern = 0;
	motion = false;
	judge = false;
	Deth_player = false;
	frame_g = 0;
	chara_frame_g = 0;
	scroll_D = 0.0f;
	Rest_life = 2;
	hp_end=false;
	waza_number = 0;
	Jump_Up_frame = 0;
	Jump_Up_Cnt = 0;


	//�t������������
	p_motion_chara = 0;
	p_scroll_chara = 0;
	p_waza_hantei = 0;
	p_muteki = 0;
	p_Rest_life = 0;
	p_i = 0;
	p_end = false;
	Player_Hp = 0;
	a = 0;
	panchi_judge = false;
	panchi_S_judge = false;
	ice_judge = false;
	jump_judge = false;

	trans = false;
	trans_judge = false;
	trans_enemy = false;

	End_waza = false;
	player_end_waza = false;
	enemy_end_waza = false;

	huttobi = false;
	judge_huttobi = false;
}

//------------------------------------
//		�X�V����
//------------------------------------
void Player_Update(void) {

	//�w�i�X�N���[��
	scroll_x +=1.0f;

	XINPUT_STATE state;
	XInputGetState(0, &state);


	//�d��
	if (g_PlayerX < 330.f || g_PlayerX > 1320.f || g_PlayerY != 650.f)
	{
		g_PlayerY += PLAYER_GRAVITY;
	}
	else
	{
		Judge_Jump = 2;
	}

	//�����̉E�������荶��������
	if (orientation)
	{
		scroll_D -= 0.05f;
	}
	else
	{
		scroll_D += 0.05f;
	}

	
	scroll= (int)(scroll_x / 16) % 3;
	

	p_scroll_chara++;
	p_motion_chara = (p_scroll_chara / 16);


	//�_���[�W���󂯂ĂȂ��Ȃ��
	if (p_waza_hantei == 0)
	{
		//�ړ�
		vector();

		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_X)
		{
			panchi();
		}

		
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y)
		{
			waza();
		}

		if (!(state.Gamepad.wButtons & XINPUT_GAMEPAD_X )&& !(state.Gamepad.wButtons & XINPUT_GAMEPAD_Y))
		{
			panchi_judge = false;
			panchi_S_judge = false;
			ice_judge = false;
			jump_judge = false;
		}
		//�W�����v
		Jump();
		//�K�[�h
		Guard();
	}
	else if(p_waza_hantei == 1)
	{
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT || state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT|| state.Gamepad.wButtons & XINPUT_GAMEPAD_A&&p_waza_hantei != 4)
		{
			p_waza_hantei = 0;
		}

	}
	motion = Motion_End();

	if (!motion)
	{
		Tech_Pattern = 0;
		waza_number = 0;
	}

	if (g_PlayerY>1300.f||g_PlayerY<-800.f || g_PlayerX>2500.f||g_PlayerX<-1100.f &&!Deth_player)
	{
		if (orientation == 1)
			orientation = 0;

		if (Rest_life == 2)
		{
			Rest_life = 1;
			Deth_player = true;
			Effect_Create(280, 160);
			Player_Hp = 0;
			Deth_chara(Deth_player);			
		}
		else if (Rest_life == 1)
		{
			Deth_player = true;
			Effect_Create(240, 160);
			Rest_life = 0;
			Player_Hp = 0;
			Deth_chara(Deth_player);
		}
		else if (Rest_life == 0)
		{
			hp_end = true;
		}
	}
	if (Deth_player)
	{
		g_PlayerX = 350.f;
		g_PlayerY = 650.f;
		Deth_player = false;
	}


	//�t������������
	if (p_motion_chara > 3)
	{
		p_waza_hantei = 0;
	}

	
	if ((int)p_muteki >= 10)
	{
		if (p_motion_chara < 8)
			p_waza_hantei = 2;
		else
		{
			p_waza_hantei = 0;
			p_muteki = 0.0f;
		}
	}
	if (p_waza_hantei >= 3)
	{
		if (p_motion_chara < 1*(Player_Hp /10))
			p_waza_hantei = 4;
		else
		{
			p_waza_hantei = 0;
			p_muteki = 0.0f;
		}
	}
	if (p_waza_hantei == 4)
	{
		Name_SetEffect(g_PlayerX, g_PlayerY+30, 64.0f, 100, D3DCOLOR_RGBA(30, 30, 30, 1));
		if (!judge_huttobi)
		{
			if (ENEMY_ORIENT() == 0)
			{
				huttobi = true;
			}
			else
			{
				huttobi = false;
			}
			judge_huttobi = true;
		}

		if (Player_Hp <= 100)
		{
			if (huttobi)
			{
				g_PlayerX += 10;
			}
			else 
			{
				g_PlayerX -= 10;
			}
			g_PlayerY -= 20;
		}
		else
		{
			if (huttobi)
			{
				g_PlayerX += 20;
			}
			else 
			{
				g_PlayerX -= 20;
			}
			g_PlayerY -= 40;
		}
	}
	else
	{
		judge_huttobi = false;
	}
	if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB)&&!trans_judge)
	{
		
	    trans_judge = true;
		if (!trans)
		{
			trans = true;
		}
		else
		{
			trans = false;
		}
	}
	else if(!(state.Gamepad.wButtons & XINPUT_GAMEPAD_LEFT_THUMB))
	{
		trans_judge = false;
	}
	if (trans)
	{
		Name_SetEffect(g_PlayerX, g_PlayerY, 128.0f, 100, D3DCOLOR_RGBA(1, 1, 255, 1));
	}


	trans_enemy = Trance_Player();

	if (trans_enemy)
	{
		b = 2;
	}
	else
	{
		b = 1;
	}

	if (trans)
	{
		a = 2;
	}
	else
	{
		a = 1;
	}
	if ((int)p_muteki < 10)
	{
		if (Deth_Fild() && !(g_PlayerX <= 650 || g_PlayerX >= 950))
		{
			Player_Hp += 1 * a*b;
		}
	}
}

//------------------------------------
//		�`�揈��
//------------------------------------
void Player_Draw(void)
{

	Back_texture();
	// �_���[�W���󂯂ĂȂ��Ȃ��
	if (p_waza_hantei == 0)
	{

		if (orientation == 0)
		{
			Right_Chara();
		}

		if (orientation == 1)
		{
			Left_Chara();
		}
	}

	if (waza_number == 0)
	{
		//�_���[�W�H�����
		if (p_waza_hantei == 1)
		{
			if (orientation == 1)
			{
				Sprite_Draw(kTEXTURE_INDEX_PLAYER1, g_PlayerX - 50, g_PlayerY - 50, 0, 200, 100, 100);
			}
			else
				Sprite_Draw(kTEXTURE_INDEX_PLAYER1_R, g_PlayerX - 50, g_PlayerY - 50, 0, 200, 100, 100);


		}
		//���G���
		else if (p_waza_hantei == 2)
		{
			if (p_motion_chara % 2 == 0)
			{
				if (orientation == 1)
				{
					Sprite_Draw(kTEXTURE_INDEX_PLAYER1, g_PlayerX - 50, g_PlayerY - 50, 0, 100, 100, 100);
				}
				else
					Sprite_Draw(kTEXTURE_INDEX_PLAYER1_R, g_PlayerX - 50, g_PlayerY - 50, 0, 100, 100, 100);
			}
			else if (p_motion_chara % 2 == 1)
			{
				if (orientation == 1)
				{
					Sprite_Draw_RED(kTEXTURE_INDEX_PLAYER1, g_PlayerX - 50, g_PlayerY - 50, 0, 100, 100, 100);
				}
				else
					Sprite_Draw_RED(kTEXTURE_INDEX_PLAYER1_R, g_PlayerX - 50, g_PlayerY - 50, 0, 100, 100, 100);
			}
		}
		//������΂�
		else if (p_waza_hantei == 4 || p_waza_hantei == 3)
		{
			Sprite_Draw(kTEXTURE_INDEX_PLAYER1, g_PlayerX - 50, g_PlayerY - 50, 0, 0, 100, 100);
		}

	}


	if (Time()==0&& !(player_end_waza|| enemy_end_waza))
	{
		End_waza = true;
	}
	if (g_PlayerX>=700&& g_PlayerX <= 740&& End_waza)
	{
		End_waza = false;
		player_end_waza = true;

	}
	if (e_move_x() >= 760 && e_move_x() <= 800&& End_waza)
	{
		End_waza = false;
		enemy_end_waza = true;
	}

	if(End_waza)
	Sprite_Draw(kTEXTURE_INDEX_END_WAZA, 720, 500, scroll * 200, 0, 200, 200);

	if (player_end_waza)
	{
		Name_SetEffect(g_PlayerX, g_PlayerY, 256.0f, 100, D3DCOLOR_RGBA(100, 100, 100, 100));
		Sprite_Draw_A(kTEXTURE_INDEX_ICE_TITLE, 600, 150);
	}

}

void Back_texture(void)
{

	int time = Time();

	//��ʃX�N���[���̔w�i
	Sprite_Draw(kTEXTURE_INDEX_STAGE1, 0, 0, scroll_x / 2.0f, 0, SCREEN_WIDTH, SCREEN_HEIGHT);

	//�n�ʂ̊�̃e�N�X�`��
	Sprite_Draw(kTEXTURE_INDEX_ASHIBA, 300.f, SCREEN_HEIGHT - SCREEN_HEIGHT / 3, 0, 0, 1000.f, 300.f);

	//�^�C�}�[�̂Ƃ���̊z��
	Sprite_Draw(kTEXTURE_INDEX_GAKU, 670.f, 0);

	//�{�̃e�N�X�`��
	Sprite_Draw(kTEXTURE_INDEX_TORI, 700.f + scroll_D, 640.f, (float)scroll * 60.f, (float)orientation * 30.f, 60.f, 30.f);
	//�L�̃e�N�X�`��
	Sprite_Draw(kTEXTURE_INDEX_CAT, 1000.f - scroll_D, 730.f, (float)scroll * 60.f, (float)orientation * 30.f, 60.f, 30.f);
	//���΂̃e�N�X�`��
	Sprite_Draw(kTEXTURE_INDEX_TAKIBI, 500.f, 640.f, (float)scroll * 60.f, 0, 60.f, 60.f);


	//�����̃A�C�R��
	Sprite_Draw(kTEXTURE_INDEX_CHARA1_P, 0, 0);

	//���C�t�̏�������
	if (Rest_life >= 2)//�c��̗͂��Q
	{
		Sprite_Draw(kTEXTURE_INDEX_LIFE_RED, 240.f, 160.f, (float)scroll * 40.f, 0, 40.f, 40.f);
		Sprite_Draw(kTEXTURE_INDEX_LIFE_RED, 280.f, 160.f, (float)scroll * 40.f, 0, 40.f, 40.f);

	}
	else if (Rest_life <= 1&&!Rest_life<1)//�c��̗͂�1
	{
		Sprite_Draw(kTEXTURE_INDEX_LIFE_RED, 240, 160, (float)scroll * 40, 0, 40, 40);
	}


	//�̗͂̕\��
	if (Player_Hp >= 100.0f)
	{
		Score_draw(250.0f, 50.0f, (int)Player_Hp, 3, false, true);
	}
	else if (Player_Hp >= 10.0f)
	{
		Score_draw(250.0f, 50.0f, (int)Player_Hp, 2, false, true);
	}
	else
	{
		Score_draw(250.0f, 50.0f, (int)Player_Hp, 1, false, true);
	}


	//�c��^�C���̏����̕`������Ă��܂�
	if (time >= 100)
		Sprite_Draw(kTEXTURE_INDEX_FIRE, 875.f, 150.f, (float)scroll * 40.f, 0, 40.f, 40.f);
	if (time >= 75)
		Sprite_Draw(kTEXTURE_INDEX_FIRE, 825.f, 150.f, (float)scroll * 40.f, 0, 40.f, 40.f);
	if (time >= 50)
		Sprite_Draw(kTEXTURE_INDEX_FIRE, 775.f, 150.f, (float)scroll * 40.f, 0, 40.f, 40.f);
	if (time >= 25)
		Sprite_Draw(kTEXTURE_INDEX_FIRE, 725.f, 150.f, (float)scroll * 40.f, 0, 40.f, 40.f);

}

void Player_Destroy(int index)
{
	if ((int)p_muteki<10)
	{
		if (index == 10)
		{
			if (G_Motion)
			{
				Player_Hp += 5*a*b;
			}
			else
			Player_Hp += 10*a*b;
			if (!G_Motion)
			{
				p_waza_hantei = 1;
			}
			p_motion_chara = 0;
			p_scroll_chara = 0;
			p_muteki += 2.0f;

		}
		else if (index == 1)
		{
			if (p_i == 0)
			{
				p_i++;
				PlaySound(SOUND_PANCHI);
			}
			if (G_Motion)
			{
				Player_Hp += 0.1f*a*b;
			}
			else
			Player_Hp += 0.2f*a*b;
			if (!G_Motion)
			{
				p_waza_hantei = 1;
			}
			p_motion_chara = 0;
			p_scroll_chara = 0;
			p_muteki += 0.1;
		}
		else if (index == 2)
		{
			PlaySound(SOUND_PANCHI_STRONG);
			if (G_Motion)
			{
				Player_Hp += 0.1f*a*b;
			}
			else
			Player_Hp += 0.2f*a*b;
			if (!G_Motion)
			{
				p_waza_hantei = 3;
			}
			p_motion_chara = 0;
			p_scroll_chara = 0;
			p_muteki += 0.1;

		}
		else if (index == 0)
		{
			p_i = 0;
		}
	}
}

//------------------------------------
//�����蔻��
//------------------------------------
const Circle*g_player_a(void)
{
	return &g_player;//�o���b�g�R���W�����̃A�h���X	
}

int move_x(void)
{
	return g_PlayerX;
}

int move_y(void)
{
	return g_PlayerY;
}

void panchi(void)
{
	XINPUT_STATE state;
	XInputGetState(0, &state);

	if (!motion&&!G_Motion)
	{

		//�ʏ�A�p���`
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_X&&!(state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)&& !panchi_judge)
		{
			waza_number = 1;
			if (orientation == 0)
			{
				Tech_Pattern = 5;
			}
			else if (orientation == 1)
			{
				Tech_Pattern = 1;
			}
			Motion_Create(g_PlayerX - 50.f, g_PlayerY - 50.f);
			motion = true;
			panchi_judge = true;
			player_end_waza = false;
			
		}

		//��A�p���`
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_X&&state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP&&!panchi_S_judge)
		{
			waza_number = 2;
			if (orientation == 0)
			{
				Tech_Pattern = 7;
			}
			else if (orientation == 1)
			{
				Tech_Pattern = 3;
			}
			Motion_Create(g_PlayerX - 50.f, g_PlayerY - 50.f);
			motion = true;
			panchi_S_judge = true;
		}
	}

}

void waza(void)
{
	XINPUT_STATE state;
	XInputGetState(0, &state);

	if (!motion && !G_Motion)
	{
		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y&&!(state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP)&&!ice_judge)
		{
			waza_number = 3;
			if (orientation == 0)
			{
				Tech_Pattern = 6;
				judge = false;
			}
			else if (orientation == 1)
			{
				Tech_Pattern = 2;
				judge = true;
			}
			Motion_Create(g_PlayerX - 50.f, g_PlayerY - 50.f);
			Bullet_Create(g_PlayerX - 50.f, g_PlayerY - 50.f);
			motion = true;
			ice_judge = true;
		}

		if (state.Gamepad.wButtons & XINPUT_GAMEPAD_Y && (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_UP) && !ice_judge)
		{
			waza_number = 4;
			if (orientation == 0)
			{
				Tech_Pattern = 8;
			}
			else if (orientation == 1)
			{
				Tech_Pattern = 4;
			}
			Motion_Create(g_PlayerX - 50.f, g_PlayerY - 50.f);
			motion = true;
		}
	}
}

void Jump(void)
{
	//�W�����v
	XINPUT_STATE state;
	XInputGetState(0, &state);

	if (state.Gamepad.wButtons & XINPUT_GAMEPAD_A&& Judge_Jump != 0 && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_B) && !motion&&!jump_judge)
	{
		PlaySound(SOUND_JUMP);
		jump_judge = true;
		Judge_Jump -= 1;
		if(Judge_Jump==1)
		Jump_Up_Cnt = 24;
	}
	if (Judge_Jump == 0 && Cnt_Jump<=6.3f)
	{
		Cnt_Jump += 0.3f;
	}
	else if (Judge_Jump != 0)
	{
		Cnt_Jump = 0;
	}

	if (Judge_Jump <= 1)
	{
		Jump_Up_frame =(int)(Jump_Up_Cnt / 24) % 2;
		Jump_Up_Cnt++;
	}

	if(Jump_Up_frame==1)
	{
		g_PlayerY -= 20.0f;
	}
	else
	{
		Jump_Up_Cnt = 0;
	}
	
}

void vector(void)
{
	D3DXVECTOR2 vecDir(0.0f, 0.0f);

	XINPUT_STATE state;
	XInputGetState(0, &state);

	//�ړ��t���[��
	frame = (chara_frame / 8) % 10;

	//�E�ړ�
	if (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_RIGHT && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_B) && !motion) {
		vecDir.x += PLAYER_MOVE_SPEED;
		orientation = 0;
		chara_frame += 1;
	}
	
	//���ړ�
	if (state.Gamepad.wButtons & XINPUT_GAMEPAD_DPAD_LEFT && !(state.Gamepad.wButtons & XINPUT_GAMEPAD_B) && !motion) {
		vecDir.x -= PLAYER_MOVE_SPEED;
		orientation = 1;
		chara_frame += 1;
	}


	//�����P�ɐ��K�����邱�Ƃ��m�[�}���C�Y�ƌ���
	D3DXVec2Normalize(&vecDir, &vecDir);
	g_PlayerSpeed += vecDir * PLAYER_MOVE_SPEED;
	g_PlayerX += g_PlayerSpeed.x;
	g_PlayerSpeed *= 0.94f;
	g_PlayerX = max(g_PlayerX, -1100.f);
	g_PlayerX = min(g_PlayerX, 2500.f);
	g_PlayerY = max(g_PlayerY, -800.0f);
	g_PlayerY = min(g_PlayerY, 1400.f);

	g_player.Centerx = g_PlayerX;
	g_player.Centery = g_PlayerY;
}

void Guard(void)
{

	XINPUT_STATE state;
	XInputGetState(0, &state);

	if ((state.Gamepad.wButtons & XINPUT_GAMEPAD_B)){
		PlaySound(SOUND_BARRIER);
		G_Motion = true;
		chara_frame_g += 1;
	}
	else if (!(state.Gamepad.wButtons & XINPUT_GAMEPAD_B)) {
		G_Motion = false;
		frame_g = 0;
		chara_frame_g = 0;
	}

	frame_g = (chara_frame_g / 8) % 31;

	if (frame_g >= 30)
	{
		motion = true;
		if (orientation == 0)
		{
			Tech_Pattern = 10;
		}
		else if (orientation == 1)
		{
			Tech_Pattern = 11;
		}
		Motion_Create(g_PlayerX - 50.f, g_PlayerY - 50.f);  
		frame_g = 0;
		chara_frame_g = 0;
	}

}

void Right_Chara(void)
{
	int select_c = Chara_Select();

	if (!motion)
	{
		Sprite_Draw(select_c, g_PlayerX - 50.f, g_PlayerY - 50.f, frame * 100.f, 100.f* 2, 100.f, 100.f, 50.f, 50.f, 1.0f, 1.0f, Cnt_Jump);
		if(Judge_Jump==2)//�n��Ȃ�Ήe�\��
		Sprite_Draw(kTEXTURE_INDEX_MY1_SHADOW, g_PlayerX - 50.f, g_PlayerY - 40.f);
		//DebugPrimitive_DrawBatchCircle(g_PlayerX , g_PlayerY, g_player.Radious);
		if (G_Motion)
		{
			if (frame_g <= 15)
			{
				Sprite_Draw(kTEXTURE_INDEX_G, g_PlayerX - 50.f, g_PlayerY - 100.f, frame_g * 100.f, 0, 100.f, 200.f);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_G_B, g_PlayerX - 50.f, g_PlayerY - 100.f, frame_g * 100.f, 0, 100.f, 200.f);
			}
		}
	}
	
}

void Left_Chara(void)
{

	int select_c = Chara_Select();

	if (!motion)
	{
		Sprite_Draw(select_c, g_PlayerX - 50.f, g_PlayerY - 50.f, frame * 100.f, 100.f, 100.f, 100.f, 50.f, 50.f, 1.0f, 1.0f, Cnt_Jump);
		if (Judge_Jump == 2)//�n��Ȃ�Ήe�\��
		Sprite_Draw(kTEXTURE_INDEX_MY1_SHADOW, g_PlayerX - 50.f, g_PlayerY - 40.f);
		//DebugPrimitive_DrawBatchCircle(g_PlayerX, g_PlayerY , g_player.Radious);
		if (G_Motion)
		{
			if (frame_g <= 15)
			{
				Sprite_Draw(kTEXTURE_INDEX_G, g_PlayerX - 50.f, g_PlayerY - 100.f, frame_g * 100.f, 0, 100.f, 200.f);
			}
			else
			{
				Sprite_Draw(kTEXTURE_INDEX_G_B, g_PlayerX - 50.f, g_PlayerY - 100.f, frame_g * 100.f, 0, 100.f, 200.f);
			}
		}
	}
	
}

int MotionTech_Pattern(void)
{
	return Tech_Pattern;
}

int Judge(void)
{
	return judge;
}

int deth(void)
{
	return Deth_player;
}

int Hp_End(void)
{
	return hp_end;
}

int Hp(void)
{
	return Rest_life;
}

int Waza_Number(void)
{
	return waza_number;
}

int Trance_Player(void)
{
	return trans;
}

int Enemy_End_waza(void)
{
	return enemy_end_waza;
}

int Player_ORIENT(void)
{
	return orientation;
}

int Waza_hantei(void)
{
	return p_waza_hantei;
}