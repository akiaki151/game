//=============================================================================
//
// �A�j���[�V�����\������ [animetion.h]
//
//=============================================================================
#ifndef ANIMETION_H_
#define ANIMETION_H_

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
float cutx(int tw, int hpttern, int maxxpattern);
float cuty(int th, int hpttern, int maxxpattern);
int texanimetion(int fcounter, int waitframe, int maxpattern);
int texanimetions(int fcounter, int waitframe);

#endif //ANIMETION_H_