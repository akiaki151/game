//=============================================================================
//
// �L�[�{�[�h���͏��� [input.h]
//
//=============================================================================
#ifndef INPUT_H_
#define INPUT_H_

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include <Windows.h>
#define DIRECTINPUT_VERSION (0x0800)
#include <dinput.h>
#include <Xinput.h>
#pragma comment (lib, "xinput.lib")

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
bool Keyboard_Initialize(HINSTANCE hInstance, HWND hWnd);
void Keyboard_Finalize(void);
void Keyboard_Update(void);
bool Keyboard_IsPress(int nKey);
bool Keyboard_IsTrigger(int nKey);
bool Keyboard_IsRelease(int nKey);

#endif //!INPUT_H_