//=============================================================================
//
// ���U���g�\������ [result.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include"result.h"
#include"common.h"
#include"scene.h"
#include"input.h"
#include"texture.h"
#include"sprite.h"
#include"fade.h"
#include"Score.h"
#include"judgement.h"
#include "debug_font.h"
#include "title.h"
#include "Sound.h"
#define	FILENAME "score.bin"	
#define KAZU (5)
//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static bool g_bEnd = false;
static int score_R[KAZU];
static int hako = 0;
FILE *rank_pt;
static int score = 0;
static int g_ranking[6] = { 0 };
static bool a = false;
//------------------------------------
//		����������
//------------------------------------
void Result_Initialize(void)
{
	DebugFont_Initialize();
	g_bEnd = false;
	score_R[KAZU] = { 0 };
	hako = 0;
	score = 0;
	a = false;
}

//------------------------------------
//		�I������
//------------------------------------
void Result_Finalize(void)
{
	DebugFont_Finalize();
}

//------------------------------------
//		�X�V����
//------------------------------------
void Result_Update(void)
{

	if (!g_bEnd)
	{

		//��
		if (Keyboard_IsTrigger(DIK_SPACE))
		{
			Fade_Start(true, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			g_bEnd = true;
		}

	}

	if (g_bEnd)
	{
		if (!Fade_IsFade())
		{
			Fade_Start(false, 60, D3DCOLOR_RGBA(0, 0, 0, 255));
			StopSound(SOUND_BGM_RESULT);
			Scene_Change(SCENE_INDEX_TITLE);
		}
	}

	

}

//------------------------------------
//		�`�揈��
//------------------------------------
void Result_Draw(void)
{
	int time = Time();
	int hp = GetHp();
	score = time * 10 + hp * 1000;
	

	if (!Mode_Select())
	{
		if (Keyboard_IsTrigger(DIK_Y) && !a)
		{
			Ranking();
			a = true;
		}

		if (a)
		{
			Sprite_Draw(kTEXTURE_INDEX_HISCORE, 0, 0);
			for (int i = 0; i <= 4; i++)
			{
				if (g_ranking[i] >= 1000)
				{
					Score_draw(SCREEN_WIDTH / 2, 150 * i + 150, g_ranking[i], 4, false, true);
				}
				else if (g_ranking[i] >= 100)
				{
					Score_draw(SCREEN_WIDTH / 2, 150 * i + 150, g_ranking[i], 3, false, true);
				}
				else if (g_ranking[i] >= 10)
				{
					Score_draw(SCREEN_WIDTH / 2, 150 * i + 150, g_ranking[i], 2, false, true);
				}
				else
				{
					Score_draw(SCREEN_WIDTH / 2, 150 * i + 150, g_ranking[i], 1, false, true);
				}
			}
		}
		else
		{
			Sprite_Draw(kTEXTURE_INDEX_RESULT, 0, 0);
			if (time >= 100)
			{
				Score_draw(SCREEN_WIDTH / 2 - 250, SCREEN_HEIGHT / 2 - 220, time, 3, false, true);
			}
			else if (time >= 10)
			{
				Score_draw(SCREEN_WIDTH / 2 - 250, SCREEN_HEIGHT / 2 - 220, time, 2, false, true);
			}
			else
			{
				Score_draw(SCREEN_WIDTH / 2 - 250, SCREEN_HEIGHT / 2 - 220, time, 1, false, true);
			}

			Score_draw(SCREEN_WIDTH / 2 - 150, SCREEN_HEIGHT / 2 - 30, hp, 1, false, true);

			if (score >= 1000)
			{
				Score_draw(SCREEN_WIDTH / 2, SCREEN_HEIGHT - 200, score, 4, false, true);
			}
			else if (score >= 100)
			{
				Score_draw(SCREEN_WIDTH / 2, SCREEN_HEIGHT - 200, score, 3, false, true);
			}
			else if (score >= 10)
			{
				Score_draw(SCREEN_WIDTH / 2, SCREEN_HEIGHT - 200, score, 2, false, true);
			}
			else
			{
				Score_draw(SCREEN_WIDTH / 2, SCREEN_HEIGHT - 200, score, 1, false, true);
			}
		}
	}
	else
	{
		Sprite_Draw(kTEXTURE_INDEX_END_RESULT2, 0, 0);
		if (!Hp_End())
		{
			Sprite_Draw(kTEXTURE_INDEX_CHAR1_M, 300, 450);
			Sprite_Draw(kTEXTURE_INDEX_CHAR2_M, 1000, 450);
		}
		else
		{
			Sprite_Draw(kTEXTURE_INDEX_CHAR2_M, 300, 450);
			Sprite_Draw(kTEXTURE_INDEX_CHAR1_M, 1000, 450);
		}
	}
		
}

void Ranking(void)
{
	rank_pt = fopen("ranking.txt", "a");
	fprintf(rank_pt, "\n%d\n", score);
	fclose(rank_pt);

	rank_pt = fopen("ranking.txt", "r");
	while (fscanf(rank_pt, "%d", &g_ranking[5]) != EOF)
	{
		for (int i = 0; i < 5; i++)
		{
			if (g_ranking[5] >= g_ranking[i])
			{
				for (int k = 4; k >= i; k--)
				{
					if (k > i)
					{
						g_ranking[k] = g_ranking[k - 1];
					}
					else
					{
						g_ranking[k] = g_ranking[5];
					}
				}
				break;
			}
		}
	}
	fclose(rank_pt);
}