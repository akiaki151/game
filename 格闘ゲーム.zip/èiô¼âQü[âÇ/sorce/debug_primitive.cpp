//=============================================================================
//
// �f�o�b�O�v���~�e�B�u�\������ [sprite.cpp]
//
//=============================================================================

//------------------------------------
//		�C���N���[�h
//------------------------------------
#include<d3d9.h>
#include<d3dx9.h>
#include<math.h>
#include"mydirect.h"
#include"debug_primitive.h"

//------------------------------------
//		�}�N��
//------------------------------------
#define CIRCLE_DRAW_MAX	(2048)		//�ۂ��Q�O�S�W������
#define CIRCLE_VERTEX_COUNT (8)	//8�p�`
#define FVF_DEGUB_VERTEX	(D3DFVF_XYZRHW| D3DFVF_DIFFUSE)
typedef struct DebugVertex_tag
{
	D3DXVECTOR4 position;
	D3DCOLOR color;
}DebugVertex;

//------------------------------------
//		�O���[�o���ϐ�
//------------------------------------
static LPDIRECT3DVERTEXBUFFER9 g_pVertexBuffer = NULL;
static LPDIRECT3DINDEXBUFFER9 g_pIndexBuffer = NULL;

static int g_CircleDrawCount = 0;
static DebugVertex*g_pVertex;
static WORD* g_pIndex;


//------------------------------------
//		������
//------------------------------------

void DebugPrimitive_Initialize(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();

	pDevice->CreateVertexBuffer(
		sizeof(DebugVertex)*CIRCLE_VERTEX_COUNT*CIRCLE_DRAW_MAX,
		D3DUSAGE_WRITEONLY, FVF_DEGUB_VERTEX,
		D3DPOOL_MANAGED, &g_pVertexBuffer, NULL);

	pDevice->CreateIndexBuffer(
		sizeof(WORD)*CIRCLE_VERTEX_COUNT * 2 * CIRCLE_DRAW_MAX,
		D3DUSAGE_WRITEONLY, D3DFMT_INDEX16,
		D3DPOOL_MANAGED, &g_pIndexBuffer, NULL);

}

//------------------------------------
//		�I��
//------------------------------------
void DebugPrimitive_Finalize(void)
{

}

//------------------------------------
//		�`��
//------------------------------------
void DebugPrimitive_DrawBatchCircle(float x, float y, float radious)
{
	int n = g_CircleDrawCount * CIRCLE_VERTEX_COUNT;			//�ۂ̌������_��
	float a = D3DX_PI * 2 / CIRCLE_VERTEX_COUNT;
	for (int i = 0; i < CIRCLE_VERTEX_COUNT; i++)
	{
		g_pVertex[i + n].position.x = cos(a * i) * radious + x;
		g_pVertex[i + n].position.y = sin(a * i) * radious + y;
		g_pVertex[i + n].position.z = 1.0f;
		g_pVertex[i + n].position.w = 1.0f;

		g_pVertex[i + n].color = D3DCOLOR_RGBA(0, 255, 0, 255);
	}
	n = g_CircleDrawCount * CIRCLE_VERTEX_COUNT;
	for (int i = 0; i < CIRCLE_VERTEX_COUNT; i++)			//01,12,23,34,45,56,67,70�̏��Ԃɂ���
	{
		g_pIndex[n * 2 + i * 2] = n + i;
		g_pIndex[n * 2 + i * 2 + 1] = n + ((i + 1) % CIRCLE_VERTEX_COUNT);
	}
	g_CircleDrawCount++;				//��1������yo!
}

//------------------------------------
//		
//------------------------------------
void DebugPrimitive_BatchBegin(void)
{
	g_CircleDrawCount = 0;

	g_pVertexBuffer->Lock(0, 0, (void**)&g_pVertex, 0);
	g_pIndexBuffer->Lock(0, 0, (void**)&g_pIndex, 0);

}


void DebugPrimitive_BatchEnd(void)
{
	LPDIRECT3DDEVICE9 pDevice = MyDirect3D_GetDevice();
	g_pVertexBuffer->Unlock();
	g_pIndexBuffer->Unlock();

	pDevice->SetStreamSource(
		0, g_pVertexBuffer,
		0, sizeof(DebugVertex)
	);

	pDevice->SetIndices(g_pIndexBuffer);

	pDevice->SetFVF(FVF_DEGUB_VERTEX);
	pDevice->SetTexture(0, NULL);

	pDevice->DrawIndexedPrimitive(
		D3DPT_LINELIST,
		0, 0,
		g_CircleDrawCount*CIRCLE_VERTEX_COUNT,
		0, g_CircleDrawCount*CIRCLE_VERTEX_COUNT
	);
}
//------------------------------------
//		
//------------------------------------
void Debug_PrimitiveRun(void)
{

}