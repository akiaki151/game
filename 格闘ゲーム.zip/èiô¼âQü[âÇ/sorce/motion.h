//=============================================================================
//
// �L�������[�V�������� [motion.h]
//
//=============================================================================
#ifndef MOTION_H_
#define MOTION_H_

//------------------------------------
//		�}�N��
//------------------------------------
#define PANCHI_FRAME    (4)
#define PANCHI_S_FRAME  (8)
#define SPECIAL_FRAME   (24)
#define SPECIAL_S_FRAME (64)
#define GUARD_FRAME     (48)


#define PTTERN_TW  (100)  
#define PTTERN_TH  (100)

#define MAX_PTTERN (2)
#define MOTION_MAX (3)       //�G�t�F�N�g

//------------------------------------
//		�\����
//------------------------------------
typedef struct motion
{
	float motion_x;
	float motion_y;
	float texcutX;
	float texcutY;
	bool motion_flag;
}MOTION;

typedef struct e_motion
{
	float e_motion_x;
	float e_motion_y;
	float e_texcutX;
	float e_texcutY;
	bool e_motion_flag;
}EMOTION;


//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Motion_Initialize(void);
void Motion_Finalize(void);
void Motion_Update(void);
void Motion_Draw(void);
void Motion_Create(float x, float y);
void E_Motion_Create(float x, float y);
int Motion_End(void);
int Deth_chara(bool judge);

int E_Motion_End(void);
int E_Deth_chara(bool e_judge);
int Ice_Fild(void);
int Deth_Fild(void);
#endif//!MOTION_H_