//=============================================================================
//
// �G�t�F�N�g�\������ [effect.h]
//
//=============================================================================
#ifndef EFFECT_H_
#define EFFECT_H_

//------------------------------------
//		�}�N��
//------------------------------------
#define WAIT_FRAME (4)
#define PTTERN_TW (200)
#define PTTERN_TH (200)
#define MAX_PTTERN (14)
#define EFFECT_MAX	(15)       //�G�t�F�N�g

//------------------------------------
//		�\����
//------------------------------------
typedef struct effect
{
	float effect_x;
	float effect_y;
	float texcutX;
	float texcutY;
	bool Effect_flag;
	bool E_Effect_flag;
}EFFECT;

//------------------------------------
//		�v���g�^�C�v�錾
//------------------------------------
void Effect_Initialize(void);
void Effect_Finalize(void);
void Effect_Update(void);
void Effect_Draw(void);
void Effect_Create(float x, float y);
void E_Effect_Create(float x, float y);
#endif//!EFFECT_H_