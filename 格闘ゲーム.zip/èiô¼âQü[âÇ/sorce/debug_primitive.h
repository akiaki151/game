//=============================================================================
//
// �e���� [debug_primitive.h]
//
//=============================================================================

#ifndef DEBUG_PRIMITIVE
#define DEBUG_PRIMITIVE

//------------------------------------
//	�v���g�^�C�v�錾
//------------------------------------
void DebugPrimitive_Initialize(void);					//������
void DebugPrimitive_Finalize(void);					//�I��
void DebugPrimitive_DrawBatchCircle(float x, float y, float radious);		//�`��
void Debug_PrimitiveRun(void);						//
void DebugPrimitive_BatchBegin(void);
void DebugPrimitive_BatchEnd(void);

#endif // !DEBUG_PRIMITIVE
